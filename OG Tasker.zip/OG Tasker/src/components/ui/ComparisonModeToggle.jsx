import React from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const ComparisonModeToggle = ({ 
  isComparisonMode = false, 
  onToggle = () => {}, 
  planCount = 2,
  className = '' 
}) => {
  const handleToggle = () => {
    onToggle(!isComparisonMode);
  };

  const handleExitComparison = () => {
    onToggle(false);
  };

  if (isComparisonMode) {
    return (
      <div className={`bg-accent/10 border border-accent/20 rounded-lg ${className}`}>
        <div className="flex items-center justify-between p-3">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-accent rounded-md flex items-center justify-center">
              <Icon name="GitCompare" size={16} color="white" />
            </div>
            <div>
              <div className="text-sm font-medium text-foreground">
                Comparison Mode Active
              </div>
              <div className="text-xs text-muted-foreground">
                Comparing {planCount} plans side by side
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExitComparison}
              iconName="X"
              iconPosition="left"
              className="text-accent hover:text-accent-foreground hover:bg-accent"
            >
              <span className="hidden sm:inline">Exit Comparison</span>
              <span className="sm:hidden">Exit</span>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-muted rounded-md flex items-center justify-center">
            <Icon name="Eye" size={16} className="text-muted-foreground" />
          </div>
          <div>
            <div className="text-sm font-medium text-foreground">
              Single Plan View
            </div>
            <div className="text-xs text-muted-foreground">
              Viewing one plan at a time
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleToggle}
            iconName="GitCompare"
            iconPosition="left"
            className="border-accent text-accent hover:bg-accent hover:text-accent-foreground"
          >
            <span className="hidden sm:inline">Compare Plans</span>
            <span className="sm:hidden">Compare</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ComparisonModeToggle;