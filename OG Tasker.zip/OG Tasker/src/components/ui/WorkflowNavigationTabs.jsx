import React, { useState } from 'react';
import Icon from '../AppIcon';

const WorkflowNavigationTabs = ({ 
  activeView = 'timeline', 
  onViewChange = () => {}, 
  availableViews = ['timeline', 'cards', 'list'],
  className = '' 
}) => {
  const [focusedTab, setFocusedTab] = useState(null);

  const viewConfigs = {
    timeline: {
      id: 'timeline',
      label: 'Timeline View',
      icon: 'Calendar',
      description: 'Chronological plan visualization'
    },
    cards: {
      id: 'cards',
      label: 'Card View',
      icon: 'LayoutGrid',
      description: 'Task cards with details'
    },
    list: {
      id: 'list',
      label: 'List View',
      icon: 'List',
      description: 'Detailed task listing'
    },
    kanban: {
      id: 'kanban',
      label: 'Kanban Board',
      icon: 'Columns',
      description: 'Status-based task board'
    },
    calendar: {
      id: 'calendar',
      label: 'Calendar',
      icon: 'CalendarDays',
      description: 'Calendar-based planning'
    },
    gantt: {
      id: 'gantt',
      label: 'Gantt Chart',
      icon: 'BarChart3',
      description: 'Project timeline chart'
    }
  };

  const handleTabClick = (viewId) => {
    onViewChange(viewId);
  };

  const handleKeyDown = (event, viewId) => {
    if (event?.key === 'Enter' || event?.key === ' ') {
      event?.preventDefault();
      handleTabClick(viewId);
    } else if (event?.key === 'ArrowLeft' || event?.key === 'ArrowRight') {
      event?.preventDefault();
      const currentIndex = availableViews?.indexOf(viewId);
      const nextIndex = event?.key === 'ArrowRight' 
        ? (currentIndex + 1) % availableViews?.length
        : (currentIndex - 1 + availableViews?.length) % availableViews?.length;
      const nextViewId = availableViews?.[nextIndex];
      setFocusedTab(nextViewId);
      document.querySelector(`[data-tab="${nextViewId}"]`)?.focus();
    }
  };

  const TabButton = ({ view, isActive }) => (
    <button
      data-tab={view?.id}
      onClick={() => handleTabClick(view?.id)}
      onKeyDown={(e) => handleKeyDown(e, view?.id)}
      onFocus={() => setFocusedTab(view?.id)}
      onBlur={() => setFocusedTab(null)}
      className={`
        flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-md transition-all duration-200
        focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2
        ${isActive 
          ? 'bg-primary text-primary-foreground shadow-sm' 
          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
        }
        ${focusedTab === view?.id ? 'ring-2 ring-ring ring-offset-2' : ''}
      `}
      role="tab"
      aria-selected={isActive}
      aria-controls={`${view?.id}-panel`}
      title={view?.description}
    >
      <Icon name={view?.icon} size={16} />
      <span className="hidden sm:inline">{view?.label}</span>
      <span className="sm:hidden">{view?.label?.split(' ')?.[0]}</span>
    </button>
  );

  const MobileScrollableTabs = () => (
    <div className="sm:hidden">
      <div className="flex space-x-1 overflow-x-auto scrollbar-hide pb-2">
        {availableViews?.map((viewId) => {
          const view = viewConfigs?.[viewId];
          const isActive = activeView === viewId;
          return (
            <div key={viewId} className="flex-shrink-0">
              <TabButton view={view} isActive={isActive} />
            </div>
          );
        })}
      </div>
    </div>
  );

  const DesktopTabs = () => (
    <div className="hidden sm:flex items-center space-x-1">
      {availableViews?.map((viewId) => {
        const view = viewConfigs?.[viewId];
        const isActive = activeView === viewId;
        return (
          <TabButton key={viewId} view={view} isActive={isActive} />
        );
      })}
    </div>
  );

  return (
    <div className={`bg-card border-b border-border ${className}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-3">
          <div 
            role="tablist" 
            aria-label="Plan view options"
            className="flex items-center justify-between"
          >
            <div className="flex-1">
              <DesktopTabs />
              <MobileScrollableTabs />
            </div>
            
            {/* View Options */}
            <div className="flex items-center space-x-2 ml-4">
              <button
                className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors duration-200"
                title="View options"
              >
                <Icon name="Settings2" size={16} />
              </button>
              <button
                className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors duration-200"
                title="Fullscreen view"
              >
                <Icon name="Maximize2" size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkflowNavigationTabs;