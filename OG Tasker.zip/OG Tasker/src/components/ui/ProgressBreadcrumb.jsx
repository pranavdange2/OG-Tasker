import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const ProgressBreadcrumb = ({ 
  currentPhase = 'input', 
  completedPhases = [], 
  planTitle = null,
  className = '' 
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const phases = [
    {
      id: 'input',
      label: 'Task Input',
      path: '/task-input-form',
      icon: 'Edit3',
      description: 'Define your planning requirements'
    },
    {
      id: 'execution',
      label: 'AI Processing',
      path: '/agent-execution-dashboard',
      icon: 'Brain',
      description: 'AI agents creating your plan'
    },
    {
      id: 'results',
      label: 'Plan Results',
      path: '/plan-results-timeline',
      icon: 'CheckCircle',
      description: 'Review and refine your plan'
    },
    {
      id: 'comparison',
      label: 'Plan Comparison',
      path: '/plan-comparison-re-planning',
      icon: 'GitCompare',
      description: 'Compare and optimize plans'
    }
  ];

  const handlePhaseClick = (phase) => {
    if (completedPhases?.includes(phase?.id) || phase?.id === currentPhase) {
      navigate(phase?.path);
    }
  };

  const getPhaseStatus = (phase) => {
    if (completedPhases?.includes(phase?.id)) return 'completed';
    if (phase?.id === currentPhase) return 'current';
    return 'upcoming';
  };

  const PhaseItem = ({ phase, index, isLast }) => {
    const status = getPhaseStatus(phase);
    const isClickable = status === 'completed' || status === 'current';

    return (
      <div className="flex items-center">
        <div className="flex items-center">
          <button
            onClick={() => handlePhaseClick(phase)}
            disabled={!isClickable}
            className={`
              flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200
              ${status === 'completed' 
                ? 'text-success bg-success/10 hover:bg-success/20 cursor-pointer' 
                : status === 'current' ?'text-primary bg-primary/10 cursor-pointer' :'text-muted-foreground cursor-not-allowed'
              }
              ${isClickable ? 'hover:scale-105' : ''}
            `}
            title={phase?.description}
          >
            <div className={`
              w-6 h-6 rounded-full flex items-center justify-center text-xs
              ${status === 'completed' 
                ? 'bg-success text-success-foreground' 
                : status === 'current' ?'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground'
              }
            `}>
              {status === 'completed' ? (
                <Icon name="Check" size={12} />
              ) : (
                <Icon name={phase?.icon} size={12} />
              )}
            </div>
            <span className="hidden sm:inline">{phase?.label}</span>
          </button>
        </div>
        {!isLast && (
          <div className={`
            mx-2 w-8 h-0.5 transition-colors duration-200
            ${completedPhases?.includes(phase?.id) ? 'bg-success' : 'bg-border'}
          `} />
        )}
      </div>
    );
  };

  const MobileBreadcrumb = () => {
    const currentPhaseIndex = phases?.findIndex(p => p?.id === currentPhase);
    const currentPhaseData = phases?.[currentPhaseIndex];
    const previousPhase = currentPhaseIndex > 0 ? phases?.[currentPhaseIndex - 1] : null;
    const nextPhase = currentPhaseIndex < phases?.length - 1 ? phases?.[currentPhaseIndex + 1] : null;

    return (
      <div className="flex items-center justify-between w-full">
        {previousPhase && completedPhases?.includes(previousPhase?.id) ? (
          <button
            onClick={() => handlePhaseClick(previousPhase)}
            className="flex items-center space-x-1 text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
          >
            <Icon name="ChevronLeft" size={16} />
            <span>{previousPhase?.label}</span>
          </button>
        ) : (
          <div />
        )}
        <div className="flex items-center space-x-2">
          <div className={`
            w-8 h-8 rounded-full flex items-center justify-center
            ${getPhaseStatus(currentPhaseData) === 'completed' 
              ? 'bg-success text-success-foreground' :'bg-primary text-primary-foreground'
            }
          `}>
            <Icon name={currentPhaseData?.icon} size={16} />
          </div>
          <div className="text-center">
            <div className="text-sm font-medium text-foreground">{currentPhaseData?.label}</div>
            <div className="text-xs text-muted-foreground">
              Step {currentPhaseIndex + 1} of {phases?.length}
            </div>
          </div>
        </div>
        {nextPhase ? (
          <button
            disabled
            className="flex items-center space-x-1 text-sm text-muted-foreground"
          >
            <span>{nextPhase?.label}</span>
            <Icon name="ChevronRight" size={16} />
          </button>
        ) : (
          <div />
        )}
      </div>
    );
  };

  return (
    <div className={`bg-card border-b border-border ${className}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        {planTitle && (
          <div className="mb-3">
            <h1 className="text-lg font-semibold text-foreground truncate">{planTitle}</h1>
          </div>
        )}
        
        {/* Desktop Breadcrumb */}
        <div className="hidden sm:flex items-center">
          {phases?.map((phase, index) => (
            <PhaseItem
              key={phase?.id}
              phase={phase}
              index={index}
              isLast={index === phases?.length - 1}
            />
          ))}
        </div>

        {/* Mobile Breadcrumb */}
        <div className="sm:hidden">
          <MobileBreadcrumb />
        </div>
      </div>
    </div>
  );
};

export default ProgressBreadcrumb;