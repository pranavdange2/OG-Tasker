import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = ({ isAuthenticated = false, planningContext = null }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const primaryNavItems = [
    { label: 'Dashboard', path: '/dashboard', icon: 'LayoutDashboard', requiresAuth: true },
    { label: 'New Plan', path: '/task-input-form', icon: 'Plus', requiresAuth: true },
    { label: 'Active Plans', path: '/agent-execution-dashboard', icon: 'Activity', requiresAuth: true },
    { label: 'Plan Library', path: '/plan-results-timeline', icon: 'Library', requiresAuth: true },
  ];

  const secondaryNavItems = [
    { label: 'Compare Plans', path: '/plan-comparison-re-planning', icon: 'GitCompare', requiresAuth: true },
    { label: 'Settings', path: '/settings', icon: 'Settings', requiresAuth: true },
    { label: 'Help', path: '/help', icon: 'HelpCircle', requiresAuth: true },
  ];

  const publicNavItems = [
    { label: 'Features', path: '/features', icon: 'Zap' },
    { label: 'Pricing', path: '/pricing', icon: 'IndianRupee' },
    { label: 'About', path: '/about', icon: 'Info' },
  ];

  const handleNavigation = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
    setIsMoreMenuOpen(false);
  };

  const handleAuth = () => {
    if (isAuthenticated) {
      // Handle logout
      navigate('/landing-page');
    } else {
      navigate('/user-authentication');
    }
    setIsMobileMenuOpen(false);
  };

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  const Logo = () => (
    <div className="flex items-center space-x-2 cursor-pointer" onClick={() => handleNavigation(isAuthenticated ? '/dashboard' : '/landing-page')}>
      <div className="w-8 h-8 rounded-lg flex items-center justify-center">
        <img src="/assets/images/logo.png" alt="OG Tasker" className="w-8 h-8 rounded-lg" />
      </div>
      <span className="text-xl font-heading font-semibold text-foreground">OG Tasker</span>
    </div>
  );

  const NavItem = ({ item, isMobile = false }) => (
    <button
      onClick={() => handleNavigation(item?.path)}
      className={`
        flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200
        ${isActivePath(item?.path) 
          ? 'bg-primary text-primary-foreground' 
          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
        }
        ${isMobile ? 'w-full justify-start' : ''}
      `}
    >
      <Icon name={item?.icon} size={16} />
      <span>{item?.label}</span>
    </button>
  );

  const PlanningContextHeader = () => {
    if (!planningContext) return null;

    return (
      <div className="border-t border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-12">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Icon name="FileText" size={16} className="text-muted-foreground" />
                <span className="text-sm font-medium text-foreground truncate max-w-xs">
                  {planningContext?.title || 'Untitled Plan'}
                </span>
              </div>
              <div className="hidden sm:flex items-center space-x-2 text-xs text-muted-foreground">
                <Icon name="Clock" size={12} />
                <span>Last saved: {planningContext?.lastSaved || 'Never'}</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" iconName="Save" iconPosition="left">
                Save
              </Button>
              <Button variant="ghost" size="sm" iconName="Share" iconPosition="left" className="hidden sm:flex">
                Share
              </Button>
              <Button variant="ghost" size="sm" iconName="Download" iconPosition="left" className="hidden sm:flex">
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <header className="nav-sticky bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Logo />

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {isAuthenticated ? (
              <>
                {primaryNavItems?.map((item) => (
                  <NavItem key={item?.path} item={item} />
                ))}
                
                {/* More Menu */}
                <div className="relative">
                  <button
                    onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
                    className="flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors duration-200"
                  >
                    <Icon name="MoreHorizontal" size={16} />
                    <span>More</span>
                  </button>
                  
                  {isMoreMenuOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-popover border border-border rounded-md shadow-floating z-50">
                      <div className="py-1">
                        {secondaryNavItems?.map((item) => (
                          <button
                            key={item?.path}
                            onClick={() => handleNavigation(item?.path)}
                            className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-colors duration-200"
                          >
                            <Icon name={item?.icon} size={16} />
                            <span>{item?.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              publicNavItems?.map((item) => (
                <NavItem key={item?.path} item={item} />
              ))
            )}
          </nav>

          {/* Auth Button */}
          <div className="hidden md:flex items-center space-x-4">
            <Button
              variant={isAuthenticated ? "ghost" : "default"}
              onClick={handleAuth}
              iconName={isAuthenticated ? "LogOut" : "LogIn"}
              iconPosition="left"
            >
              {isAuthenticated ? "Sign Out" : "Sign In"}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors duration-200"
          >
            <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={20} />
          </button>
        </div>
      </div>
      {/* Planning Context Header */}
      <PlanningContextHeader />
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-card">
          <div className="px-4 py-4 space-y-2">
            {isAuthenticated ? (
              <>
                {primaryNavItems?.map((item) => (
                  <NavItem key={item?.path} item={item} isMobile />
                ))}
                <div className="border-t border-border pt-2 mt-2">
                  {secondaryNavItems?.map((item) => (
                    <NavItem key={item?.path} item={item} isMobile />
                  ))}
                </div>
              </>
            ) : (
              publicNavItems?.map((item) => (
                <NavItem key={item?.path} item={item} isMobile />
              ))
            )}
            
            <div className="border-t border-border pt-2 mt-2">
              <Button
                variant={isAuthenticated ? "ghost" : "default"}
                onClick={handleAuth}
                iconName={isAuthenticated ? "LogOut" : "LogIn"}
                iconPosition="left"
                fullWidth
              >
                {isAuthenticated ? "Sign Out" : "Sign In"}
              </Button>
            </div>
          </div>
        </div>
      )}
      {/* Overlay for mobile menu */}
      {(isMobileMenuOpen || isMoreMenuOpen) && (
        <div
          className="fixed inset-0 bg-black bg-opacity-25 z-40"
          onClick={() => {
            setIsMobileMenuOpen(false);
            setIsMoreMenuOpen(false);
          }}
        />
      )}
    </header>
  );
};

export default Header;