import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HeroSection = () => {
  const navigate = useNavigate();
  const [animationStep, setAnimationStep] = useState(0);

  const animationSteps = [
    {
      title: "Plan a wedding reception",
      description: "Complex goal input",
      icon: "Target",
      color: "text-primary"
    },
    {
      title: "Breaking down into tasks...",
      description: "AI analysis in progress",
      icon: "Brain",
      color: "text-accent"
    },
    {
      title: "✓ Venue booking\n✓ Catering arrangements\n✓ Guest invitations\n✓ Entertainment setup",
      description: "Structured action plan",
      icon: "CheckCircle",
      color: "text-success"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationStep((prev) => (prev + 1) % animationSteps.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleStartPlanning = () => {
    navigate('/task-input-form');
  };

  const handleWatchDemo = () => {
    // Scroll to demo section or show modal
    document.getElementById('demo-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-gradient-to-br from-background via-muted/30 to-primary/5 py-16 sm:py-24 lg:py-32 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%239C92AC%22%20fill-opacity%3D%220.4%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Hero Content */}
          <div className="text-center lg:text-left">
            <div className="mb-6">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20">
                <Icon name="Sparkles" size={12} className="mr-1" />
                AI-Powered Planning
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-bold text-foreground mb-6 leading-tight">
              Turn Complex Goals into
              <span className="text-primary block">Actionable Plans</span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto lg:mx-0">
              Watch our AI agent break down your biggest challenges into step-by-step plans. 
              From event planning to project management, get intelligent task breakdown in seconds.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <Button
                variant="default"
                size="lg"
                onClick={handleStartPlanning}
                iconName="ArrowRight"
                iconPosition="right"
                className="text-base px-8 py-4"
              >
                Start Planning with AI
              </Button>
              
              <Button
                variant="outline"
                size="lg"
                onClick={handleWatchDemo}
                iconName="Play"
                iconPosition="left"
                className="text-base px-8 py-4"
              >
                Watch Demo
              </Button>
            </div>

            {/* Trust Signals */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Icon name="Shield" size={16} className="text-success" />
                <span>Enterprise Security</span>
              </div>
              <div className="flex items-center gap-2">
                <Icon name="Users" size={16} className="text-primary" />
                <span>10,000+ Active Planners</span>
              </div>
              <div className="flex items-center gap-2">
                <Icon name="Star" size={16} className="text-warning" />
                <span>4.9/5 Rating</span>
              </div>
            </div>
          </div>

          {/* Animation Demo */}
          <div className="relative">
            <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
              <div className="text-center mb-6">
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  AI Planning in Action
                </h3>
                <p className="text-sm text-muted-foreground">
                  See how complex goals become structured plans
                </p>
              </div>

              {/* Animation Container */}
              <div className="relative h-64 flex items-center justify-center">
                <div className="w-full max-w-sm">
                  {animationSteps.map((step, index) => (
                    <div
                      key={index}
                      className={`
                        absolute inset-0 transition-all duration-1000 transform
                        ${animationStep === index 
                          ? 'opacity-100 translate-y-0 scale-100' 
                          : animationStep === (index - 1 + animationSteps.length) % animationSteps.length
                          ? 'opacity-0 -translate-y-4 scale-95' 
                          : 'opacity-0 translate-y-4 scale-95'
                        }
                      `}
                    >
                      <div className="text-center">
                        <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center ${step.color}`}>
                          <Icon name={step.icon} size={24} />
                        </div>
                        <div className="space-y-2">
                          <div className="text-sm font-medium text-foreground whitespace-pre-line">
                            {step.title}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {step.description}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Progress Indicators */}
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 flex space-x-2">
                  {animationSteps.map((_, index) => (
                    <div
                      key={index}
                      className={`
                        w-2 h-2 rounded-full transition-all duration-300
                        ${animationStep === index ? 'bg-primary' : 'bg-border'}
                      `}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-8 h-8 bg-primary/20 rounded-full animate-pulse"></div>
            <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-accent/20 rounded-full animate-pulse delay-1000"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;