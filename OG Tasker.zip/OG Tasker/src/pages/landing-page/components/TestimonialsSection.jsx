import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const TestimonialsSection = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: "Sarah Chen",
      role: "Event Planner",
      company: "Elite Events Co.",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      content: "This AI planner transformed how I organize corporate events. What used to take hours of planning now happens in minutes, with better results and fewer oversights.",
      rating: 5,
      planType: "Corporate Event Planning"
    },
    {
      id: 2,
      name: "Marcus Rodriguez",
      role: "Project Manager",
      company: "TechFlow Solutions",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      content: "The real-time adaptation feature is incredible. When project requirements change, the AI instantly shows me how to adjust the timeline and resources. It's like having a planning expert on my team 24/7.",
      rating: 5,
      planType: "Software Development Projects"
    },
    {
      id: 3,
      name: "Emily Watson",
      role: "Small Business Owner",
      company: "Bloom Catering",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      content: "As a small business owner, I wear many hats. This tool helps me plan everything from marketing campaigns to catering logistics with professional-level detail and organization.",
      rating: 5,
      planType: "Business Operations"
    },
    {
      id: 4,
      name: "David Park",
      role: "Wedding Coordinator",
      company: "Perfect Day Weddings",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      content: "Planning weddings involves coordinating dozens of vendors and timelines. The AI breaks everything down perfectly and even suggests contingency plans I wouldn't have thought of.",
      rating: 5,
      planType: "Wedding Planning"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials?.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [testimonials?.length]);

  const handlePrevious = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials?.length) % testimonials?.length);
  };

  const handleNext = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials?.length);
  };

  const StarRating = ({ rating }) => (
    <div className="flex items-center space-x-1">
      {[...Array(5)]?.map((_, index) => (
        <Icon
          key={index}
          name="Star"
          size={16}
          className={index < rating ? "text-warning fill-current" : "text-border"}
        />
      ))}
    </div>
  );

  return (
    <section className="py-16 sm:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="mb-4">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-success/10 text-success border border-success/20">
              <Icon name="MessageSquare" size={12} className="mr-1" />
              Customer Success Stories
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-bold text-foreground mb-6">
            Trusted by
            <span className="text-primary block sm:inline"> Planning Professionals</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            See how professionals across industries are transforming their planning workflows with AI-powered intelligence.
          </p>
        </div>

        {/* Testimonial Carousel */}
        <div className="relative max-w-4xl mx-auto">
          <div className="bg-card border border-border rounded-2xl p-8 sm:p-12 shadow-lg">
            <div className="text-center mb-8">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full overflow-hidden border-4 border-primary/20">
                <Image
                  src={testimonials?.[currentTestimonial]?.avatar}
                  alt={testimonials?.[currentTestimonial]?.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <StarRating rating={testimonials?.[currentTestimonial]?.rating} />
            </div>

            <blockquote className="text-lg sm:text-xl text-center text-foreground mb-8 leading-relaxed font-medium">
              "{testimonials?.[currentTestimonial]?.content}"
            </blockquote>

            <div className="text-center">
              <div className="font-semibold text-foreground text-lg mb-1">
                {testimonials?.[currentTestimonial]?.name}
              </div>
              <div className="text-muted-foreground text-sm mb-2">
                {testimonials?.[currentTestimonial]?.role} at {testimonials?.[currentTestimonial]?.company}
              </div>
              <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-accent/10 text-accent border border-accent/20">
                <Icon name="Briefcase" size={12} className="mr-1" />
                {testimonials?.[currentTestimonial]?.planType}
              </div>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={handlePrevious}
              className="w-12 h-12 rounded-full bg-card border border-border hover:bg-muted transition-colors duration-200 flex items-center justify-center"
              aria-label="Previous testimonial"
            >
              <Icon name="ChevronLeft" size={20} className="text-muted-foreground" />
            </button>

            {/* Indicators */}
            <div className="flex space-x-2">
              {testimonials?.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`
                    w-3 h-3 rounded-full transition-all duration-300
                    ${currentTestimonial === index ? 'bg-primary' : 'bg-border hover:bg-muted-foreground'}
                  `}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <button
              onClick={handleNext}
              className="w-12 h-12 rounded-full bg-card border border-border hover:bg-muted transition-colors duration-200 flex items-center justify-center"
              aria-label="Next testimonial"
            >
              <Icon name="ChevronRight" size={20} className="text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { label: "Active Users", value: "10,000+", icon: "Users" },
            { label: "Plans Created", value: "50,000+", icon: "FileText" },
            { label: "Success Rate", value: "98.5%", icon: "TrendingUp" },
            { label: "Time Saved", value: "2M+ Hours", icon: "Clock" }
          ]?.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name={stat?.icon} size={20} className="text-primary" />
              </div>
              <div className="text-2xl font-bold text-foreground mb-1">{stat?.value}</div>
              <div className="text-sm text-muted-foreground">{stat?.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;