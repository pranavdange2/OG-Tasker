import React from 'react';
import Icon from '../../../components/AppIcon';

const BenefitsSection = () => {
  const benefits = [
    {
      id: 1,
      icon: "Brain",
      title: "Intelligent Task Breakdown",
      description: "Our AI agent analyzes your goals and creates detailed, actionable step-by-step plans with smart prioritization and resource allocation.",
      features: ["Smart goal analysis", "Automated task sequencing", "Resource optimization", "Priority ranking"]
    },
    {
      id: 2,
      icon: "Zap",
      title: "Real-Time Adaptation",
      description: "Plans automatically adjust when conditions change. Get instant re-planning with clear explanations of what changed and why.",
      features: ["Dynamic re-planning", "Change impact analysis", "Real-time updates", "Contextual explanations"]
    },
    {
      id: 3,
      icon: "Target",
      title: "Goal-Oriented Results",
      description: "Every plan is designed to achieve your specific objectives with measurable milestones and clear success criteria.",
      features: ["Milestone tracking", "Success metrics", "Progress visualization", "Outcome prediction"]
    }
  ];

  const BenefitCard = ({ benefit }) => (
    <div className="bg-card border border-border rounded-xl p-6 hover:shadow-md transition-all duration-300 hover:-translate-y-1">
      <div className="flex items-center mb-4">
        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mr-4">
          <Icon name={benefit?.icon} size={24} className="text-primary" />
        </div>
        <h3 className="text-xl font-semibold text-foreground">{benefit?.title}</h3>
      </div>
      
      <p className="text-muted-foreground mb-6 leading-relaxed">
        {benefit?.description}
      </p>
      
      <ul className="space-y-2">
        {benefit?.features?.map((feature, index) => (
          <li key={index} className="flex items-center text-sm text-muted-foreground">
            <Icon name="Check" size={16} className="text-success mr-2 flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <section className="py-16 sm:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="mb-4">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-accent/10 text-accent border border-accent/20">
              <Icon name="Lightbulb" size={12} className="mr-1" />
              Why Choose AI Planning
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-bold text-foreground mb-6">
            Planning Made
            <span className="text-primary block sm:inline"> Effortless</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Experience the power of AI-driven planning that adapts to your needs, 
            learns from your preferences, and delivers results that exceed expectations.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits?.map((benefit) => (
            <BenefitCard key={benefit?.id} benefit={benefit} />
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold text-foreground mb-4">
              Ready to Transform Your Planning?
            </h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Join thousands of professionals who have revolutionized their workflow with AI-powered planning.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="flex items-center justify-center text-sm text-muted-foreground">
                <Icon name="Clock" size={16} className="mr-2" />
                <span>Setup in under 2 minutes</span>
              </div>
              <div className="flex items-center justify-center text-sm text-muted-foreground">
                <Icon name="CreditCard" size={16} className="mr-2" />
                <span>No credit card required</span>
              </div>
              <div className="flex items-center justify-center text-sm text-muted-foreground">
                <Icon name="Shield" size={16} className="mr-2" />
                <span>Enterprise-grade security</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;