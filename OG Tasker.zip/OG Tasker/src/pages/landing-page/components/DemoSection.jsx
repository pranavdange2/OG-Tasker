import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DemoSection = () => {
  const [activeDemo, setActiveDemo] = useState('wedding');

  const demoScenarios = {
    wedding: {
      title: "Wedding Reception Planning",
      input: "Plan a wedding reception for 150 guests with $15,000 budget in downtown venue",
      steps: [
        { id: 1, title: "Venue Research & Booking", duration: "2-3 weeks", status: "completed", description: "Research downtown venues, compare pricing, book preferred location" },
        { id: 2, title: "Catering Arrangements", duration: "1-2 weeks", status: "completed", description: "Menu selection, dietary accommodations, service staff coordination" },
        { id: 3, title: "Guest Management", duration: "3-4 weeks", status: "in-progress", description: "Send invitations, track RSVPs, seating arrangements" },
        { id: 4, title: "Entertainment & Music", duration: "1 week", status: "pending", description: "DJ/band booking, sound system setup, playlist preparation" },
        { id: 5, title: "Decorations & Flowers", duration: "1 week", status: "pending", description: "Theme coordination, floral arrangements, table settings" }
      ],
      insights: ["Budget allocation: 40% venue, 35% catering, 25% other", "Peak season pricing considered", "Backup plans for weather contingencies"]
    },
    project: {
      title: "Software Development Project",
      input: "Launch a mobile app MVP in 3 months with team of 5 developers and $50,000 budget",
      steps: [
        { id: 1, title: "Requirements & Planning", duration: "1 week", status: "completed", description: "Stakeholder interviews, feature prioritization, technical architecture" },
        { id: 2, title: "UI/UX Design Phase", duration: "2 weeks", status: "completed", description: "Wireframes, prototypes, user testing, design system creation" },
        { id: 3, title: "Backend Development", duration: "4 weeks", status: "in-progress", description: "API development, database design, authentication system" },
        { id: 4, title: "Frontend Development", duration: "4 weeks", status: "pending", description: "Mobile app development, API integration, responsive design" },
        { id: 5, title: "Testing & Deployment", duration: "2 weeks", status: "pending", description: "QA testing, bug fixes, app store submission, launch preparation" }
      ],
      insights: ["Agile methodology recommended", "Weekly sprint reviews scheduled", "Risk mitigation for technical dependencies"]
    },
    event: {
      title: "Corporate Conference",
      input: "Organize a 2-day tech conference for 300 attendees with keynote speakers and networking",
      steps: [
        { id: 1, title: "Venue & Logistics", duration: "3-4 weeks", status: "completed", description: "Conference center booking, AV equipment, registration setup" },
        { id: 2, title: "Speaker Coordination", duration: "4-6 weeks", status: "in-progress", description: "Keynote invitations, session planning, travel arrangements" },
        { id: 3, title: "Marketing & Registration", duration: "6-8 weeks", status: "in-progress", description: "Website creation, social media campaign, early bird pricing" },
        { id: 4, title: "Catering & Hospitality", duration: "2 weeks", status: "pending", description: "Meal planning, coffee breaks, welcome reception, dietary needs" },
        { id: 5, title: "Event Execution", duration: "2 days", status: "pending", description: "Day-of coordination, attendee check-in, session management" }
      ],
      insights: ["Hybrid attendance option recommended", "Networking app integration suggested", "Post-event survey and follow-up planned"]
    }
  };

  const currentDemo = demoScenarios?.[activeDemo];

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-success bg-success/10 border-success/20';
      case 'in-progress': return 'text-primary bg-primary/10 border-primary/20';
      case 'pending': return 'text-muted-foreground bg-muted border-border';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return 'CheckCircle';
      case 'in-progress': return 'Clock';
      case 'pending': return 'Circle';
      default: return 'Circle';
    }
  };

  return (
    <section id="demo-section" className="py-16 sm:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="mb-4">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20">
              <Icon name="Play" size={12} className="mr-1" />
              Interactive Demo
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-bold text-foreground mb-6">
            See AI Planning
            <span className="text-primary block sm:inline"> In Action</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Explore how our AI agent transforms complex goals into detailed, actionable plans across different scenarios.
          </p>
        </div>

        {/* Demo Selector */}
        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
          {Object.entries(demoScenarios)?.map(([key, scenario]) => (
            <button
              key={key}
              onClick={() => setActiveDemo(key)}
              className={`
                px-6 py-3 rounded-lg text-sm font-medium transition-all duration-200
                ${activeDemo === key 
                  ? 'bg-primary text-primary-foreground shadow-sm' 
                  : 'bg-card text-muted-foreground hover:text-foreground hover:bg-muted border border-border'
                }
              `}
            >
              {scenario?.title}
            </button>
          ))}
        </div>

        {/* Demo Content */}
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Input Section */}
          <div className="space-y-6">
            <div className="bg-card border border-border rounded-xl p-6">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center mr-3">
                  <Icon name="MessageSquare" size={20} className="text-accent" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Goal Input</h3>
              </div>
              <div className="bg-muted/50 rounded-lg p-4 border-l-4 border-accent">
                <p className="text-foreground font-medium">"{currentDemo?.input}"</p>
              </div>
            </div>

            {/* AI Insights */}
            <div className="bg-card border border-border rounded-xl p-6">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
                  <Icon name="Brain" size={20} className="text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">AI Insights</h3>
              </div>
              <ul className="space-y-2">
                {currentDemo?.insights?.map((insight, index) => (
                  <li key={index} className="flex items-start">
                    <Icon name="Lightbulb" size={16} className="text-warning mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Plan Output */}
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center mr-3">
                  <Icon name="CheckCircle" size={20} className="text-success" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Generated Plan</h3>
              </div>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                {currentDemo?.steps?.length} Tasks
              </span>
            </div>

            <div className="space-y-4">
              {currentDemo?.steps?.map((step, index) => (
                <div key={step?.id} className="relative">
                  {index < currentDemo?.steps?.length - 1 && (
                    <div className="absolute left-5 top-12 w-0.5 h-8 bg-border"></div>
                  )}
                  
                  <div className="flex items-start space-x-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center border ${getStatusColor(step?.status)}`}>
                      <Icon name={getStatusIcon(step?.status)} size={16} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium text-foreground">{step?.title}</h4>
                        <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                          {step?.duration}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {step?.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="mt-6 pt-6 border-t border-border flex flex-col sm:flex-row gap-3">
              <Button variant="outline" size="sm" iconName="Download" iconPosition="left" className="flex-1">
                Export Plan
              </Button>
              <Button variant="outline" size="sm" iconName="Share" iconPosition="left" className="flex-1">
                Share Plan
              </Button>
              <Button variant="default" size="sm" iconName="Edit" iconPosition="left" className="flex-1">
                Customize
              </Button>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5 rounded-2xl p-8 border border-primary/10">
            <h3 className="text-2xl font-semibold text-foreground mb-4">
              Ready to Create Your Own Plan?
            </h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Experience the power of AI planning with your own goals and requirements.
            </p>
            <Button
              variant="default"
              size="lg"
              iconName="ArrowRight"
              iconPosition="right"
              className="px-8 py-4"
            >
              Start Your Free Plan
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DemoSection;