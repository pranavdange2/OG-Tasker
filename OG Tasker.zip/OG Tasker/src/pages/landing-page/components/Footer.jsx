import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const Footer = () => {
  const navigate = useNavigate();
  const currentYear = new Date()?.getFullYear();

  const handleNavigation = (path) => {
    navigate(path);
  };

  const footerSections = [
    {
      title: "Product",
      links: [
        { label: "Features", path: "/features" },
        { label: "Pricing", path: "/pricing" },
        { label: "AI Planning Demo", path: "/landing-page#demo-section" },
        { label: "API Documentation", path: "/api-docs" }
      ]
    },
    {
      title: "Use Cases",
      links: [
        { label: "Event Planning", path: "/use-cases/events" },
        { label: "Project Management", path: "/use-cases/projects" },
        { label: "Business Operations", path: "/use-cases/business" },
        { label: "Personal Planning", path: "/use-cases/personal" }
      ]
    },
    {
      title: "Resources",
      links: [
        { label: "Help Center", path: "/help" },
        { label: "Planning Templates", path: "/templates" },
        { label: "Best Practices", path: "/best-practices" },
        { label: "Community Forum", path: "/community" }
      ]
    },
    {
      title: "Company",
      links: [
        { label: "About Us", path: "/about" },
        { label: "Careers", path: "/careers" },
        { label: "Press Kit", path: "/press" },
        { label: "Contact", path: "/contact" }
      ]
    }
  ];

  const socialLinks = [
    { name: "Twitter", icon: "Twitter", url: "https://twitter.com/aitaskplanner" },
    { name: "LinkedIn", icon: "Linkedin", url: "https://linkedin.com/company/aitaskplanner" },
    { name: "GitHub", icon: "Github", url: "https://github.com/aitaskplanner" },
    { name: "Discord", icon: "MessageCircle", url: "https://discord.gg/aitaskplanner" }
  ];

  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
            {/* Brand Section */}
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="Brain" size={20} color="white" />
                </div>
                <span className="text-xl font-heading font-semibold text-foreground">AI Task Planner</span>
              </div>
              
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Transform complex goals into actionable plans with AI-powered intelligence. 
                Trusted by thousands of professionals worldwide.
              </p>

              {/* Newsletter Signup */}
              <div className="space-y-3">
                <h4 className="text-sm font-semibold text-foreground">Stay Updated</h4>
                <div className="flex space-x-2">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="flex-1 px-3 py-2 text-sm bg-background border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <button className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors duration-200">
                    Subscribe
                  </button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Get planning tips and product updates. No spam, unsubscribe anytime.
                </p>
              </div>
            </div>

            {/* Footer Links */}
            {footerSections?.map((section, index) => (
              <div key={index} className="lg:col-span-1">
                <h4 className="text-sm font-semibold text-foreground mb-4">{section?.title}</h4>
                <ul className="space-y-3">
                  {section?.links?.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <button
                        onClick={() => handleNavigation(link?.path)}
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
                      >
                        {link?.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="py-8 border-t border-border">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            {/* Copyright */}
            <div className="text-sm text-muted-foreground">
              © {currentYear} AI Task Planner. All rights reserved.
            </div>

            {/* Legal Links */}
            <div className="flex items-center space-x-6">
              <button
                onClick={() => handleNavigation('/privacy')}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => handleNavigation('/terms')}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
              >
                Terms of Service
              </button>
              <button
                onClick={() => handleNavigation('/cookies')}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
              >
                Cookie Policy
              </button>
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-4">
              {socialLinks?.map((social, index) => (
                <a
                  key={index}
                  href={social?.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-muted hover:bg-primary rounded-md flex items-center justify-center transition-colors duration-200 group"
                  aria-label={`Follow us on ${social?.name}`}
                >
                  <Icon 
                    name={social?.icon} 
                    size={16} 
                    className="text-muted-foreground group-hover:text-primary-foreground transition-colors duration-200" 
                  />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="py-6 border-t border-border">
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-8">
            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <Icon name="Shield" size={16} className="text-success" />
              <span>SOC 2 Compliant</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <Icon name="Lock" size={16} className="text-success" />
              <span>256-bit SSL Encryption</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <Icon name="Award" size={16} className="text-warning" />
              <span>GDPR Compliant</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <Icon name="CheckCircle" size={16} className="text-primary" />
              <span>99.9% Uptime SLA</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;