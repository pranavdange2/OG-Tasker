import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CTASection = () => {
  const navigate = useNavigate();

  const handleStartPlanning = () => {
    navigate('/task-input-form');
  };

  const handleSignUp = () => {
    navigate('/user-authentication');
  };

  const features = [
    { icon: "Zap", text: "Instant AI-powered planning" },
    { icon: "Shield", text: "Enterprise-grade security" },
    { icon: "Clock", text: "24/7 plan adaptation" },
    { icon: "Users", text: "Collaborative planning tools" }
  ];

  return (
    <section className="py-16 sm:py-24 bg-gradient-to-br from-primary/5 via-accent/5 to-primary/10 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent rounded-full blur-3xl transform -translate-x-1/2 translate-y-1/2"></div>
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Main CTA Content */}
          <div className="mb-12">
            <div className="mb-6">
              <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-primary text-primary-foreground">
                <Icon name="Sparkles" size={16} className="mr-2" />
                Start Your AI Planning Journey
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-6xl font-heading font-bold text-foreground mb-6 leading-tight">
              Transform Your Goals Into
              <span className="text-primary block">Actionable Success</span>
            </h2>

            <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              Join thousands of professionals who have revolutionized their planning process. 
              Get started in minutes and experience the future of intelligent task management.
            </p>

            {/* Primary CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                variant="default"
                size="xl"
                onClick={handleStartPlanning}
                iconName="ArrowRight"
                iconPosition="right"
                className="text-lg px-10 py-5 shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Plan with AI Now
              </Button>
              
              <Button
                variant="outline"
                size="xl"
                onClick={handleSignUp}
                iconName="UserPlus"
                iconPosition="left"
                className="text-lg px-10 py-5 border-2 hover:bg-card"
              >
                Create Free Account
              </Button>
            </div>

            {/* Feature Highlights */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
              {features?.map((feature, index) => (
                <div key={index} className="flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-card border border-border rounded-xl flex items-center justify-center mb-3 shadow-sm">
                    <Icon name={feature?.icon} size={20} className="text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{feature?.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Trust Signals */}
          <div className="bg-card/80 backdrop-blur-sm border border-border rounded-2xl p-8 shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
              {/* Left: Security */}
              <div className="text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start mb-3">
                  <Icon name="Shield" size={24} className="text-success mr-2" />
                  <span className="font-semibold text-foreground">Secure & Private</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Your data is encrypted and protected with enterprise-grade security standards.
                </p>
              </div>

              {/* Center: Stats */}
              <div className="text-center">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-2xl font-bold text-primary">10K+</div>
                    <div className="text-xs text-muted-foreground">Active Users</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-success">98.5%</div>
                    <div className="text-xs text-muted-foreground">Success Rate</div>
                  </div>
                </div>
              </div>

              {/* Right: Support */}
              <div className="text-center md:text-right">
                <div className="flex items-center justify-center md:justify-end mb-3">
                  <span className="font-semibold text-foreground mr-2">24/7 Support</span>
                  <Icon name="HeadphonesIcon" size={24} className="text-accent" />
                </div>
                <p className="text-sm text-muted-foreground">
                  Get help whenever you need it with our dedicated support team.
                </p>
              </div>
            </div>

            {/* Bottom guarantees */}
            <div className="mt-8 pt-8 border-t border-border">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Icon name="Check" size={16} className="text-success mr-2" />
                  <span>No credit card required</span>
                </div>
                <div className="flex items-center">
                  <Icon name="Check" size={16} className="text-success mr-2" />
                  <span>Free 14-day trial</span>
                </div>
                <div className="flex items-center">
                  <Icon name="Check" size={16} className="text-success mr-2" />
                  <span>Cancel anytime</span>
                </div>
              </div>
            </div>
          </div>

          {/* Final encouragement */}
          <div className="mt-8">
            <p className="text-sm text-muted-foreground">
              Ready to experience the future of planning? 
              <span className="text-primary font-medium"> Your first AI-generated plan is just one click away.</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;