import React from 'react';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const Features = () => {
  const features = [
    {
      icon: 'Brain',
      title: 'AI-Powered Planning',
      description: 'Advanced AI algorithms create comprehensive task plans tailored to your specific goals and requirements.'
    },
    {
      icon: 'Calendar',
      title: 'Smart Scheduling',
      description: 'Intelligent timeline management with automatic conflict detection and resource optimization.'
    },
    {
      icon: 'Users',
      title: 'Team Collaboration',
      description: 'Real-time collaboration tools for seamless team coordination and task management.'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={false} />
      
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Powerful Features
          </h1>
          <p className="text-xl text-muted-foreground">
            Discover our AI-powered task planning capabilities.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-card p-6 rounded-lg border border-border">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Icon name={feature.icon} size={24} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">
                {feature.title}
              </h3>
              <p className="text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;