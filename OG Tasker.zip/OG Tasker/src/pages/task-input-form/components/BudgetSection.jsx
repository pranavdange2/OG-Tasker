import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const BudgetSection = ({ 
  budget, 
  onBudgetChange, 
  budgetType, 
  onBudgetTypeChange,
  className = '' 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [sliderValue, setSliderValue] = useState(budget || 1000);

  const budgetRanges = [
    { label: 'Under ₹40,000', min: 0, max: 40000 },
    { label: '₹40,000 - ₹1,60,000', min: 40000, max: 160000 },
    { label: '₹1,60,000 - ₹8,00,000', min: 160000, max: 800000 },
    { label: '₹8,00,000 - ₹40,00,000', min: 800000, max: 4000000 },
    { label: '₹40,00,000+', min: 4000000, max: 8000000 },
    { label: 'No Budget Limit', min: null, max: null }
  ];

  const handleRangeClick = (range) => {
    if (range?.min !== null) {
      const midpoint = (range?.min + range?.max) / 2;
      onBudgetChange(midpoint);
      setSliderValue(midpoint);
      onBudgetTypeChange(range?.label);
    } else {
      onBudgetChange(0);
      onBudgetTypeChange('No Budget Limit');
    }
  };

  const handleSliderChange = (e) => {
    const value = parseInt(e?.target?.value);
    setSliderValue(value);
    onBudgetChange(value);
    
    // Update budget type based on slider value
    const matchingRange = budgetRanges?.find(range => 
      range?.min !== null && value >= range?.min && value <= range?.max
    );
    if (matchingRange) {
      onBudgetTypeChange(matchingRange?.label);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })?.format(amount);
  };

  const getBudgetImpact = () => {
    if (!budget || budget === 0) return null;
    
    if (budget < 80000) return { level: 'Basic', color: 'text-warning', description: 'Simple planning with essential features' };
    if (budget < 400000) return { level: 'Standard', color: 'text-primary', description: 'Comprehensive planning with good options' };
    if (budget < 2000000) return { level: 'Premium', color: 'text-success', description: 'Extensive planning with premium features' };
    return { level: 'Luxury', color: 'text-accent', description: 'Full-service planning with unlimited options' };
  };

  const impact = getBudgetImpact();

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-200"
      >
        <div className="flex items-center space-x-3">
          <Icon name="IndianRupee" size={20} className="text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">Budget</h3>
            <p className="text-sm text-muted-foreground">
              {budget ? formatCurrency(budget) : 'What\'s your budget range?'}
            </p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>
      {isExpanded && (
        <div className="px-6 pb-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {budgetRanges?.map((range) => (
              <Button
                key={range?.label}
                variant={budgetType === range?.label ? "default" : "outline"}
                size="sm"
                onClick={() => handleRangeClick(range)}
                className="text-xs"
              >
                {range?.label}
              </Button>
            ))}
          </div>

          {budgetType !== 'No Budget Limit' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Specific Amount: {formatCurrency(sliderValue)}
                </label>
                <input
                  type="range"
                  min="8000"
                  max="8000000"
                  step="8000"
                  value={sliderValue}
                  onChange={handleSliderChange}
                  className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>₹8,000</span>
                  <span>₹80,00,000+</span>
                </div>
              </div>

              <Input
                label="Exact Budget (Optional)"
                type="number"
                placeholder="Enter exact amount"
                value={budget || ''}
                onChange={(e) => {
                  const value = parseInt(e?.target?.value) || 0;
                  onBudgetChange(value);
                  setSliderValue(value);
                }}
                min="0"
                step="8000"
              />
            </div>
          )}

          {impact && (
            <div className="bg-muted/50 rounded-md p-3">
              <div className="flex items-center space-x-2 mb-1">
                <Icon name="TrendingUp" size={16} className={impact?.color} />
                <span className={`text-sm font-medium ${impact?.color}`}>
                  {impact?.level} Planning Level
                </span>
              </div>
              <p className="text-xs text-muted-foreground">{impact?.description}</p>
            </div>
          )}

          <div className="text-xs text-muted-foreground">
            <Icon name="Info" size={12} className="inline mr-1" />
            Budget helps the AI suggest appropriate vendors, venues, and options
          </div>
        </div>
      )}
    </div>
  );
};

export default BudgetSection;