import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';

const LocationSection = ({ 
  location, 
  onLocationChange, 
  coordinates, 
  onCoordinatesChange,
  className = '' 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [showMap, setShowMap] = useState(false);

  const locationSuggestions = [
    { name: "New York, NY", lat: 40.7128, lng: -74.0060 },
    { name: "Los Angeles, CA", lat: 34.0522, lng: -118.2437 },
    { name: "Chicago, IL", lat: 41.8781, lng: -87.6298 },
    { name: "Houston, TX", lat: 29.7604, lng: -95.3698 },
    { name: "Phoenix, AZ", lat: 33.4484, lng: -112.0740 },
    { name: "Philadelphia, PA", lat: 39.9526, lng: -75.1652 },
    { name: "San Antonio, TX", lat: 29.4241, lng: -98.4936 },
    { name: "San Diego, CA", lat: 32.7157, lng: -117.1611 },
    { name: "Dallas, TX", lat: 32.7767, lng: -96.7970 },
    { name: "San Jose, CA", lat: 37.3382, lng: -121.8863 }
  ];

  useEffect(() => {
    if (location && location?.length > 2) {
      const filtered = locationSuggestions?.filter(suggestion =>
        suggestion?.name?.toLowerCase()?.includes(location?.toLowerCase())
      );
      setSuggestions(filtered?.slice(0, 5));
    } else {
      setSuggestions([]);
    }
  }, [location]);

  const handleLocationSelect = (suggestion) => {
    onLocationChange(suggestion?.name);
    onCoordinatesChange({ lat: suggestion?.lat, lng: suggestion?.lng });
    setSuggestions([]);
    setShowMap(true);
  };

  const handleLocationChange = (value) => {
    onLocationChange(value);
    if (!value) {
      setShowMap(false);
      onCoordinatesChange(null);
    }
  };

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-200"
      >
        <div className="flex items-center space-x-3">
          <Icon name="MapPin" size={20} className="text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">Location</h3>
            <p className="text-sm text-muted-foreground">
              {location || 'Where will this take place?'}
            </p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>
      {isExpanded && (
        <div className="px-6 pb-6 space-y-4">
          <div className="relative">
            <Input
              label="Location"
              type="text"
              placeholder="Enter city, venue, or address..."
              value={location}
              onChange={(e) => handleLocationChange(e?.target?.value)}
              description="Be specific to get better local recommendations"
            />
            
            {suggestions?.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-popover border border-border rounded-md shadow-lg">
                {suggestions?.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleLocationSelect(suggestion)}
                    className="w-full text-left px-4 py-2 hover:bg-muted transition-colors duration-200 first:rounded-t-md last:rounded-b-md"
                  >
                    <div className="flex items-center space-x-2">
                      <Icon name="MapPin" size={14} className="text-muted-foreground" />
                      <span className="text-sm text-foreground">{suggestion?.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {coordinates && showMap && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">Location Preview</span>
                <button
                  onClick={() => setShowMap(!showMap)}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
                >
                  {showMap ? 'Hide Map' : 'Show Map'}
                </button>
              </div>
              
              {showMap && (
                <div className="w-full h-48 rounded-md overflow-hidden border border-border">
                  <iframe
                    width="100%"
                    height="100%"
                    loading="lazy"
                    title={location}
                    referrerPolicy="no-referrer-when-downgrade"
                    src={`https://www.google.com/maps?q=${coordinates?.lat},${coordinates?.lng}&z=14&output=embed`}
                    className="border-0"
                  />
                </div>
              )}
            </div>
          )}

          <div className="bg-muted/50 rounded-md p-3">
            <div className="flex items-start space-x-2">
              <Icon name="Lightbulb" size={16} className="text-warning mt-0.5" />
              <div className="text-xs text-muted-foreground">
                <p className="font-medium text-foreground mb-1">Location Tips:</p>
                <ul className="space-y-1">
                  <li>• Include city and state for better vendor matching</li>
                  <li>• Mention specific venues if you have preferences</li>
                  <li>• Consider nearby areas for more options</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LocationSection;