import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import { useOpenAI } from '../../../hooks/useOpenAI';

const GoalInputSection = ({ 
  goalTitle, 
  onGoalTitleChange, 
  goalDescription, 
  onGoalDescriptionChange,
  className = '' 
}) => {
  const [charCount, setCharCount] = useState(0);
  const [showExamples, setShowExamples] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const maxChars = 200;

  const { getSuggestions, isLoading: isLoadingSuggestions } = useOpenAI();

  const exampleGoals = [
    "Plan a corporate team building retreat for 50 employees",
    "Organize a wedding reception for 150 guests in downtown area",
    "Launch a new product marketing campaign within 3 months",
    "Plan a charity fundraising gala with $50,000 budget",
    "Organize a tech conference for 500 attendees",
    "Plan a family reunion weekend for 30 people"
  ];

  useEffect(() => {
    setCharCount(goalTitle?.length || 0);
  }, [goalTitle]);

  const handleGoalTitleChange = (e) => {
    const value = e?.target?.value;
    if (value?.length <= maxChars) {
      onGoalTitleChange(value);
      setCharCount(value?.length);
    }
  };

  const handleExampleClick = (example) => {
    onGoalTitleChange(example);
    setShowExamples(false);
  };

  // Generate AI-powered task suggestions
  const handleGetAISuggestions = async () => {
    if (!goalDescription?.trim() && !goalTitle?.trim()) {
      alert('Please enter a goal title or description first to get AI suggestions.');
      return;
    }

    try {
      const context = goalDescription?.trim() || goalTitle?.trim();
      const result = await getSuggestions(context);
      
      if (result?.suggestions && Array.isArray(result.suggestions) && result.suggestions.length > 0) {
        setAiSuggestions(result.suggestions);
        setShowSuggestions(true);
      } else {
        // Fallback suggestions if API doesn't return proper format
        const fallbackSuggestions = [
          {
            title: "Research and Planning",
            description: "Conduct thorough research and create detailed plan",
            priority: "high",
            estimatedDuration: "2-3 days"
          },
          {
            title: "Resource Preparation",
            description: "Gather and prepare all necessary resources",
            priority: "high",
            estimatedDuration: "1-2 days"
          },
          {
            title: "Implementation",
            description: "Execute the main tasks according to plan",
            priority: "high",
            estimatedDuration: "1-2 weeks"
          },
          {
            title: "Review and Optimization",
            description: "Review progress and optimize as needed",
            priority: "medium",
            estimatedDuration: "1-2 days"
          }
        ];
        setAiSuggestions(fallbackSuggestions);
        setShowSuggestions(true);
      }
    } catch (error) {
      console.error('Failed to get AI suggestions:', error);
      
      // Show fallback suggestions even on error
      const fallbackSuggestions = [
        {
          title: "Initial Planning",
          description: "Start with basic planning and goal setting",
          priority: "high",
          estimatedDuration: "1-2 days"
        },
        {
          title: "Resource Assessment",
          description: "Evaluate available resources and requirements",
          priority: "high",
          estimatedDuration: "1 day"
        },
        {
          title: "Action Plan Development",
          description: "Create detailed action plan with timelines",
          priority: "high",
          estimatedDuration: "2-3 days"
        },
        {
          title: "Execution Phase",
          description: "Implement the plan step by step",
          priority: "high",
          estimatedDuration: "1-3 weeks"
        }
      ];
      
      setAiSuggestions(fallbackSuggestions);
      setShowSuggestions(true);
      
      // Still show error but don't prevent functionality
      console.warn('Using fallback suggestions due to API error:', error.message);
    }
  };

  const handleSuggestionApply = (suggestion) => {
    // Enhance the description with the selected suggestion
    const currentDescription = goalDescription || '';
    const enhancedDescription = currentDescription 
      ? `${currentDescription}\n\nKey task: ${suggestion?.title} - ${suggestion?.description}`
      : `${suggestion?.title} - ${suggestion?.description}`;
    
    onGoalDescriptionChange(enhancedDescription);
    setShowSuggestions(false);
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-6 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Target" size={20} className="text-primary" />
          <h2 className="text-lg font-semibold text-foreground">What do you want to plan?</h2>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowExamples(!showExamples)}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
          >
            <Icon name="HelpCircle" size={16} />
          </button>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="relative">
          <Input
            label="Goal Title"
            type="text"
            placeholder="Describe your planning goal in a few words..."
            value={goalTitle}
            onChange={handleGoalTitleChange}
            required
            className="text-lg"
          />
          <div className="flex justify-between items-center mt-2">
            <div className="text-xs text-muted-foreground">
              Be specific about what you want to achieve
            </div>
            <div className={`text-xs ${charCount > maxChars * 0.8 ? 'text-warning' : 'text-muted-foreground'}`}>
              {charCount}/{maxChars}
            </div>
          </div>
        </div>

        {showExamples && (
          <div className="bg-muted/50 rounded-md p-4">
            <div className="text-sm font-medium text-foreground mb-3">Example goals:</div>
            <div className="grid gap-2">
              {exampleGoals?.map((example, index) => (
                <button
                  key={index}
                  onClick={() => handleExampleClick(example)}
                  className="text-left text-sm text-muted-foreground hover:text-foreground hover:bg-background rounded px-2 py-1 transition-colors duration-200"
                >
                  {example}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-foreground">Additional Details (Optional)</label>
            <Button
              variant="outline"
              size="sm"
              onClick={handleGetAISuggestions}
              iconName="Sparkles"
              iconPosition="left"
              disabled={isLoadingSuggestions || (!goalTitle?.trim() && !goalDescription?.trim())}
              loading={isLoadingSuggestions}
            >
              {isLoadingSuggestions ? 'Getting AI Suggestions...' : 'Get AI Suggestions'}
            </Button>
          </div>
          
          <Input
            type="textarea"
            placeholder="Provide any additional context, requirements, or constraints that might help the AI create a better plan..."
            value={goalDescription}
            onChange={(e) => onGoalDescriptionChange(e?.target?.value)}
            description="The more details you provide, the more personalized your plan will be"
            rows={4}
          />
        </div>

        {/* AI Suggestions Panel */}
        {showSuggestions && aiSuggestions?.length > 0 && (
          <div className="bg-primary/5 border border-primary/20 rounded-md p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Icon name="Sparkles" size={16} className="text-primary" />
                <span className="text-sm font-medium text-foreground">AI-Powered Task Suggestions</span>
              </div>
              <button
                onClick={() => setShowSuggestions(false)}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                <Icon name="X" size={14} />
              </button>
            </div>
            
            <div className="space-y-2">
              {aiSuggestions?.map((suggestion, index) => (
                <div 
                  key={index}
                  className="bg-background rounded p-3 border border-border/50"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-sm font-medium text-foreground">{suggestion?.title}</span>
                        <span className={`text-xs px-1.5 py-0.5 rounded ${
                          suggestion?.priority === 'high' ? 'bg-destructive/10 text-destructive' :
                          suggestion?.priority === 'medium'? 'bg-warning/10 text-warning' : 'bg-muted/50 text-muted-foreground'
                        }`}>
                          {suggestion?.priority}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">{suggestion?.description}</p>
                      <div className="text-xs text-muted-foreground">
                        Est. Duration: {suggestion?.estimatedDuration}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSuggestionApply(suggestion)}
                      className="ml-2"
                    >
                      Apply
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-3 pt-3 border-t border-border/20">
              <p className="text-xs text-muted-foreground">
                <Icon name="Info" size={12} className="inline mr-1" />
                These suggestions are generated by AI based on your goal. Click "Apply" to add them to your plan details.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GoalInputSection;