import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const AdvancedOptionsSection = ({ 
  teamCollaboration, 
  onTeamCollaborationChange,
  notifications,
  onNotificationsChange,
  template,
  onTemplateChange,
  className = '' 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const templateOptions = [
    { value: 'wedding', label: 'Wedding Planning', description: 'Complete wedding organization template' },
    { value: 'corporate', label: 'Corporate Event', description: 'Business meeting and conference template' },
    { value: 'birthday', label: 'Birthday Party', description: 'Personal celebration template' },
    { value: 'conference', label: 'Conference/Summit', description: 'Large-scale professional event template' },
    { value: 'fundraiser', label: 'Fundraising Event', description: 'Charity and fundraising template' },
    { value: 'product-launch', label: 'Product Launch', description: 'Marketing and launch event template' },
    { value: 'custom', label: 'Custom Template', description: 'Start from scratch with no template' }
  ];

  const notificationOptions = [
    { id: 'email', label: 'Email Updates', description: 'Receive progress updates via email' },
    { id: 'sms', label: 'SMS Notifications', description: 'Get text messages for important milestones' },
    { id: 'push', label: 'Push Notifications', description: 'Browser notifications for real-time updates' },
    { id: 'daily', label: 'Daily Summary', description: 'Daily digest of planning progress' },
    { id: 'weekly', label: 'Weekly Report', description: 'Comprehensive weekly progress report' }
  ];

  const handleNotificationChange = (notificationId, checked) => {
    const updatedNotifications = checked
      ? [...(notifications || []), notificationId]
      : (notifications || [])?.filter(id => id !== notificationId);
    onNotificationsChange(updatedNotifications);
  };

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-200"
      >
        <div className="flex items-center space-x-3">
          <Icon name="Settings2" size={20} className="text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">Advanced Options</h3>
            <p className="text-sm text-muted-foreground">
              Team collaboration, templates, and notification settings
            </p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>
      {isExpanded && (
        <div className="px-6 pb-6 space-y-6">
          {/* Template Selection */}
          <div>
            <Select
              label="Planning Template"
              description="Start with a pre-built template or create from scratch"
              options={templateOptions}
              value={template}
              onChange={onTemplateChange}
              placeholder="Choose a template..."
              searchable
            />
          </div>

          {/* Team Collaboration */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Icon name="Users" size={18} className="text-primary" />
              <h4 className="text-base font-medium text-foreground">Team Collaboration</h4>
            </div>
            
            <Checkbox
              label="Enable Team Collaboration"
              description="Allow others to view and contribute to this plan"
              checked={teamCollaboration?.enabled || false}
              onChange={(e) => onTeamCollaborationChange({
                ...teamCollaboration,
                enabled: e?.target?.checked
              })}
            />

            {teamCollaboration?.enabled && (
              <div className="ml-6 space-y-3">
                <Input
                  label="Team Members (Email Addresses)"
                  type="text"
                  placeholder="Enter email addresses separated by commas"
                  value={teamCollaboration?.members || ''}
                  onChange={(e) => onTeamCollaborationChange({
                    ...teamCollaboration,
                    members: e?.target?.value
                  })}
                  description="Invite team members to collaborate on this plan"
                />
                
                <Select
                  label="Default Permission Level"
                  options={[
                    { value: 'view', label: 'View Only', description: 'Can view but not edit' },
                    { value: 'comment', label: 'Comment', description: 'Can view and add comments' },
                    { value: 'edit', label: 'Edit', description: 'Can view, comment, and edit' },
                    { value: 'admin', label: 'Admin', description: 'Full access including sharing' }
                  ]}
                  value={teamCollaboration?.permission || 'comment'}
                  onChange={(value) => onTeamCollaborationChange({
                    ...teamCollaboration,
                    permission: value
                  })}
                />
              </div>
            )}
          </div>

          {/* Notification Preferences */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Icon name="Bell" size={18} className="text-primary" />
              <h4 className="text-base font-medium text-foreground">Notification Preferences</h4>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {notificationOptions?.map((notification) => (
                <div key={notification?.id} className="bg-muted/30 rounded-md p-3">
                  <Checkbox
                    label={notification?.label}
                    description={notification?.description}
                    checked={(notifications || [])?.includes(notification?.id)}
                    onChange={(e) => handleNotificationChange(notification?.id, e?.target?.checked)}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Auto-save Settings */}
          <div className="bg-muted/50 rounded-md p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Save" size={16} className="text-success" />
              <span className="text-sm font-medium text-foreground">Auto-save Enabled</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Your progress is automatically saved every 30 seconds. You can also manually save using Ctrl+S.
            </p>
          </div>

          <div className="bg-primary/10 border border-primary/20 rounded-md p-3">
            <div className="flex items-start space-x-2">
              <Icon name="Zap" size={16} className="text-primary mt-0.5" />
              <div className="text-xs text-muted-foreground">
                <p className="font-medium text-foreground mb-1">Pro Tip:</p>
                <p>Using templates can speed up your planning process by 60%. Templates include pre-configured tasks, timelines, and best practices for your event type.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedOptionsSection;