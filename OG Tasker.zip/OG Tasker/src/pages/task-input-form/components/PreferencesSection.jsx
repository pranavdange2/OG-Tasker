import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';

const PreferencesSection = ({ 
  priorities, 
  onPrioritiesChange, 
  constraints, 
  onConstraintsChange,
  style,
  onStyleChange,
  className = '' 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const priorityOptions = [
    { id: 'cost', label: 'Cost Efficiency', description: 'Minimize expenses while maintaining quality' },
    { id: 'time', label: 'Time Optimization', description: 'Complete tasks as quickly as possible' },
    { id: 'quality', label: 'High Quality', description: 'Premium results regardless of cost' },
    { id: 'convenience', label: 'Convenience', description: 'Easy execution with minimal effort' },
    { id: 'sustainability', label: 'Sustainability', description: 'Environmentally conscious choices' },
    { id: 'innovation', label: 'Innovation', description: 'Creative and unique approaches' }
  ];

  const constraintOptions = [
    { id: 'dietary', label: 'Dietary Restrictions', description: 'Food allergies or preferences' },
    { id: 'accessibility', label: 'Accessibility Needs', description: 'Wheelchair access, hearing assistance' },
    { id: 'weather', label: 'Weather Dependent', description: 'Indoor alternatives needed' },
    { id: 'permits', label: 'Permits Required', description: 'Legal permissions needed' },
    { id: 'noise', label: 'Noise Restrictions', description: 'Quiet hours or sound limits' },
    { id: 'parking', label: 'Parking Requirements', description: 'Adequate parking space needed' }
  ];

  const styleOptions = [
    { value: 'formal', label: 'Formal & Professional' },
    { value: 'casual', label: 'Casual & Relaxed' },
    { value: 'elegant', label: 'Elegant & Sophisticated' },
    { value: 'modern', label: 'Modern & Contemporary' },
    { value: 'traditional', label: 'Traditional & Classic' },
    { value: 'creative', label: 'Creative & Artistic' },
    { value: 'minimalist', label: 'Minimalist & Simple' },
    { value: 'luxurious', label: 'Luxurious & Premium' }
  ];

  const handlePriorityChange = (priorityId, checked) => {
    const updatedPriorities = checked
      ? [...(priorities || []), priorityId]
      : (priorities || [])?.filter(id => id !== priorityId);
    onPrioritiesChange(updatedPriorities);
  };

  const handleConstraintChange = (constraintId, checked) => {
    const updatedConstraints = checked
      ? [...(constraints || []), constraintId]
      : (constraints || [])?.filter(id => id !== constraintId);
    onConstraintsChange(updatedConstraints);
  };

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-200"
      >
        <div className="flex items-center space-x-3">
          <Icon name="Settings" size={20} className="text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">Preferences</h3>
            <p className="text-sm text-muted-foreground">
              {priorities?.length || constraints?.length || style 
                ? `${(priorities?.length || 0) + (constraints?.length || 0)} preferences selected`
                : 'Customize your planning preferences'
              }
            </p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>
      {isExpanded && (
        <div className="px-6 pb-6 space-y-6">
          {/* Priorities Section */}
          <div>
            <div className="mb-4">
              <h4 className="text-sm font-medium text-foreground mb-1">Planning Priorities</h4>
              <p className="text-xs text-muted-foreground">What matters most to you? (Select up to 3)</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {priorityOptions?.map((priority) => (
                <div key={priority?.id} className="bg-muted/30 rounded-md p-3">
                  <Checkbox
                    label={priority?.label}
                    description={priority?.description}
                    checked={(priorities || [])?.includes(priority?.id)}
                    onChange={(e) => handlePriorityChange(priority?.id, e?.target?.checked)}
                    disabled={(priorities || [])?.length >= 3 && !(priorities || [])?.includes(priority?.id)}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Style Selection */}
          <div>
            <Select
              label="Event Style"
              description="Choose the overall style and atmosphere"
              options={styleOptions}
              value={style}
              onChange={onStyleChange}
              placeholder="Select a style..."
              searchable
            />
          </div>

          {/* Constraints Section */}
          <div>
            <div className="mb-4">
              <h4 className="text-sm font-medium text-foreground mb-1">Special Considerations</h4>
              <p className="text-xs text-muted-foreground">Any constraints or special requirements?</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {constraintOptions?.map((constraint) => (
                <div key={constraint?.id} className="bg-muted/30 rounded-md p-3">
                  <Checkbox
                    label={constraint?.label}
                    description={constraint?.description}
                    checked={(constraints || [])?.includes(constraint?.id)}
                    onChange={(e) => handleConstraintChange(constraint?.id, e?.target?.checked)}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-accent/10 border border-accent/20 rounded-md p-3">
            <div className="flex items-start space-x-2">
              <Icon name="Sparkles" size={16} className="text-accent mt-0.5" />
              <div className="text-xs text-muted-foreground">
                <p className="font-medium text-foreground mb-1">AI Personalization:</p>
                <p>These preferences help our AI create a plan that matches your specific needs and style. The more you share, the better your personalized plan will be.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PreferencesSection;