import React from 'react';
import Icon from '../../../components/AppIcon';

const PlanPreviewPanel = ({ 
  goalTitle, 
  startDate, 
  endDate, 
  budget, 
  location, 
  priorities,
  className = '' 
}) => {
  const formatCurrency = (amount) => {
    if (!amount) return 'Not specified';
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })?.format(amount);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Not set';
    return new Date(dateString)?.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const calculateDuration = () => {
    if (!startDate || !endDate) return 'Not specified';
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return '1 day';
    if (diffDays < 7) return `${diffDays} days`;
    if (diffDays < 30) return `${Math.ceil(diffDays / 7)} weeks`;
    return `${Math.ceil(diffDays / 30)} months`;
  };

  const getCompletionPercentage = () => {
    let completed = 0;
    const total = 5;
    
    if (goalTitle) completed++;
    if (startDate && endDate) completed++;
    if (budget) completed++;
    if (location) completed++;
    if (priorities && priorities?.length > 0) completed++;
    
    return Math.round((completed / total) * 100);
  };

  const generatePreviewTasks = () => {
    if (!goalTitle) return [];
    
    const baseTasks = [
      'Initial planning and research',
      'Venue selection and booking',
      'Vendor coordination',
      'Timeline finalization',
      'Final preparations'
    ];
    
    return baseTasks?.map((task, index) => ({
      id: index + 1,
      title: task,
      status: index < 2 ? 'completed' : index === 2 ? 'in-progress' : 'pending'
    }));
  };

  const completionPercentage = getCompletionPercentage();
  const previewTasks = generatePreviewTasks();

  return (
    <div className={`bg-card border border-border rounded-lg p-6 ${className}`}>
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Eye" size={20} className="text-primary" />
        <h3 className="text-lg font-semibold text-foreground">Plan Preview</h3>
      </div>
      {/* Completion Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">Form Completion</span>
          <span className="text-sm text-muted-foreground">{completionPercentage}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-300"
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
      </div>
      {/* Plan Summary */}
      <div className="space-y-4">
        <div>
          <h4 className="text-base font-medium text-foreground mb-3">Plan Summary</h4>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <Icon name="Target" size={16} className="text-muted-foreground mt-0.5" />
              <div>
                <span className="text-sm font-medium text-foreground">Goal:</span>
                <p className="text-sm text-muted-foreground">
                  {goalTitle || 'No goal specified yet'}
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Icon name="Calendar" size={16} className="text-muted-foreground mt-0.5" />
              <div>
                <span className="text-sm font-medium text-foreground">Timeline:</span>
                <p className="text-sm text-muted-foreground">
                  {startDate && endDate 
                    ? `${formatDate(startDate)} - ${formatDate(endDate)} (${calculateDuration()})`
                    : 'Timeline not set'
                  }
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Icon name="IndianRupee" size={16} className="text-muted-foreground mt-0.5" />
              <div>
                <span className="text-sm font-medium text-foreground">Budget:</span>
                <p className="text-sm text-muted-foreground">
                  {formatCurrency(budget)}
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Icon name="MapPin" size={16} className="text-muted-foreground mt-0.5" />
              <div>
                <span className="text-sm font-medium text-foreground">Location:</span>
                <p className="text-sm text-muted-foreground">
                  {location || 'Location not specified'}
                </p>
              </div>
            </div>

            {priorities && priorities?.length > 0 && (
              <div className="flex items-start space-x-3">
                <Icon name="Star" size={16} className="text-muted-foreground mt-0.5" />
                <div>
                  <span className="text-sm font-medium text-foreground">Priorities:</span>
                  <p className="text-sm text-muted-foreground">
                    {priorities?.length} selected
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Preview Tasks */}
        {goalTitle && (
          <div>
            <h4 className="text-base font-medium text-foreground mb-3">Expected Tasks Preview</h4>
            <div className="space-y-2">
              {previewTasks?.map((task) => (
                <div key={task?.id} className="flex items-center space-x-3 p-2 bg-muted/30 rounded-md">
                  <div className={`w-2 h-2 rounded-full ${
                    task?.status === 'completed' ? 'bg-success' :
                    task?.status === 'in-progress' ? 'bg-warning' : 'bg-muted-foreground'
                  }`} />
                  <span className="text-sm text-foreground">{task?.title}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              * This is a preview. Actual tasks will be generated by AI based on your inputs.
            </p>
          </div>
        )}
      </div>
      {/* AI Insights */}
      {completionPercentage > 60 && (
        <div className="mt-6 bg-accent/10 border border-accent/20 rounded-md p-3">
          <div className="flex items-start space-x-2">
            <Icon name="Sparkles" size={16} className="text-accent mt-0.5" />
            <div className="text-xs text-muted-foreground">
              <p className="font-medium text-foreground mb-1">AI Insight:</p>
              <p>
                Based on your inputs, the AI will create a comprehensive plan with approximately 
                {budget > 10000 ? ' 15-25 ' : budget > 5000 ? ' 10-20 ' : ' 8-15 '}
                detailed tasks and milestones.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlanPreviewPanel;