import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const DurationSection = ({ 
  startDate, 
  onStartDateChange, 
  endDate, 
  onEndDateChange,
  durationType,
  onDurationTypeChange,
  className = '' 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const durationPresets = [
    { label: '1 Day', days: 1 },
    { label: '1 Week', days: 7 },
    { label: '2 Weeks', days: 14 },
    { label: '1 Month', days: 30 },
    { label: '3 Months', days: 90 },
    { label: 'Custom', days: null }
  ];

  const handlePresetClick = (preset) => {
    if (preset?.days) {
      const start = new Date();
      const end = new Date();
      end?.setDate(start?.getDate() + preset?.days);
      
      onStartDateChange(start?.toISOString()?.split('T')?.[0]);
      onEndDateChange(end?.toISOString()?.split('T')?.[0]);
      onDurationTypeChange(preset?.label);
    } else {
      onDurationTypeChange('Custom');
    }
  };

  const calculateDuration = () => {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const diffTime = Math.abs(end - start);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    }
    return 0;
  };

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-200"
      >
        <div className="flex items-center space-x-3">
          <Icon name="Calendar" size={20} className="text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">Timeline</h3>
            <p className="text-sm text-muted-foreground">
              {durationType || 'When do you need this completed?'}
            </p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>
      {isExpanded && (
        <div className="px-6 pb-6 space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {durationPresets?.map((preset) => (
              <Button
                key={preset?.label}
                variant={durationType === preset?.label ? "default" : "outline"}
                size="sm"
                onClick={() => handlePresetClick(preset)}
                className="text-xs"
              >
                {preset?.label}
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Start Date"
              type="date"
              value={startDate}
              onChange={(e) => onStartDateChange(e?.target?.value)}
              required
              min={new Date()?.toISOString()?.split('T')?.[0]}
            />
            <Input
              label="End Date"
              type="date"
              value={endDate}
              onChange={(e) => onEndDateChange(e?.target?.value)}
              required
              min={startDate || new Date()?.toISOString()?.split('T')?.[0]}
            />
          </div>

          {startDate && endDate && (
            <div className="bg-muted/50 rounded-md p-3">
              <div className="flex items-center space-x-2">
                <Icon name="Clock" size={16} className="text-muted-foreground" />
                <span className="text-sm text-foreground">
                  Duration: {calculateDuration()} days
                </span>
              </div>
            </div>
          )}

          <div className="text-xs text-muted-foreground">
            <Icon name="Info" size={12} className="inline mr-1" />
            The AI will create a timeline that fits within your specified dates
          </div>
        </div>
      )}
    </div>
  );
};

export default DurationSection;