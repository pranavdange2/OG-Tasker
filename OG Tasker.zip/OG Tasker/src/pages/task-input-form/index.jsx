import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import ProgressBreadcrumb from '../../components/ui/ProgressBreadcrumb';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import GoalInputSection from './components/GoalInputSection';
import DurationSection from './components/DurationSection';
import BudgetSection from './components/BudgetSection';
import LocationSection from './components/LocationSection';
import PreferencesSection from './components/PreferencesSection';
import AdvancedOptionsSection from './components/AdvancedOptionsSection';
import PlanPreviewPanel from './components/PlanPreviewPanel';
import { useOpenAI } from '../../hooks/useOpenAI';

const TaskInputForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isAuthenticated] = useState(true);
  const [lastSaved, setLastSaved] = useState(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  // Check if in edit mode
  const editMode = location?.state?.editMode;
  const existingData = location?.state?.existingData;
  
  // OpenAI Integration
  const { createPlanWithProgress, isLoading: isGeneratingPlan, error: planError, clearError } = useOpenAI();

  // Form state - initialize with existing data if in edit mode
  const [formData, setFormData] = useState(() => {
    if (editMode && existingData) {
      return {
        goalTitle: existingData.goalTitle || '',
        goalDescription: existingData.goalDescription || '',
        startDate: existingData.startDate || '',
        endDate: existingData.endDate || '',
        durationType: existingData.durationType || '',
        budget: existingData.budget || 0,
        budgetType: existingData.budgetType || '',
        location: existingData.location || '',
        coordinates: existingData.coordinates || null,
        priorities: existingData.priorities || [],
        constraints: existingData.constraints || [],
        style: existingData.style || '',
        teamCollaboration: existingData.teamCollaboration || {
          enabled: false,
          members: '',
          permission: 'comment'
        },
        notifications: existingData.notifications || ['email'],
        template: existingData.template || ''
      };
    }
    
    return {
      goalTitle: '',
      goalDescription: '',
      startDate: '',
      endDate: '',
      durationType: '',
      budget: 0,
      budgetType: '',
      location: '',
      coordinates: null,
      priorities: [],
      constraints: [],
      style: '',
      teamCollaboration: {
        enabled: false,
        members: '',
        permission: 'comment'
      },
      notifications: ['email'],
      template: ''
    };
  });

  // Auto-save functionality
  useEffect(() => {
    if (hasUnsavedChanges) {
      const autoSaveTimer = setTimeout(() => {
        handleAutoSave();
      }, 30000); // Auto-save every 30 seconds

      return () => clearTimeout(autoSaveTimer);
    }
  }, [formData, hasUnsavedChanges]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e?.ctrlKey || e?.metaKey) && e?.key === 's') {
        e?.preventDefault();
        handleSaveAsDraft();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleAutoSave = () => {
    // Mock auto-save functionality
    setLastSaved(new Date()?.toLocaleTimeString());
    setHasUnsavedChanges(false);
  };

  const handleSaveAsDraft = () => {
    // Mock save as draft functionality
    setLastSaved(new Date()?.toLocaleTimeString());
    setHasUnsavedChanges(false);
    
    // Show success message (in real app, this would be a toast notification)
    console.log('Draft saved successfully');
  };

  const validateForm = () => {
    const errors = [];
    
    if (!formData?.goalTitle?.trim()) {
      errors?.push('Goal title is required');
    }
    
    return errors;
  };

  const handleStartPlanning = async () => {
    const errors = validateForm();
    
    if (errors?.length > 0) {
      alert('Please fix the following errors:\n' + errors?.join('\n'));
      return;
    }

    clearError();

    try {
      // Always navigate to dashboard - it will handle the plan generation
      navigate('/agent-execution-dashboard', { 
        state: { 
          taskData: formData,
          isGenerating: true 
        } 
      });

    } catch (error) {
      console.error('Failed to start AI planning:', error);
      // Still navigate but show error in dashboard
      navigate('/agent-execution-dashboard', { 
        state: { 
          taskData: formData,
          isGenerating: true,
          error: error?.message 
        } 
      });
    }
  };

  const updateFormData = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    setHasUnsavedChanges(true);
  };

  const getCompletionPercentage = () => {
    let completed = 0;
    const total = 5;
    
    if (formData?.goalTitle) completed++;
    if (formData?.startDate && formData?.endDate) completed++;
    if (formData?.budget) completed++;
    if (formData?.location) completed++;
    if (formData?.priorities?.length > 0) completed++;
    
    return Math.round((completed / total) * 100);
  };

  const planningContext = {
    title: formData?.goalTitle || 'New Plan',
    lastSaved: lastSaved ? `${lastSaved}` : 'Never'
  };

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={isAuthenticated} planningContext={planningContext} />
      <ProgressBreadcrumb 
        currentPhase="input" 
        completedPhases={[]} 
        planTitle={formData?.goalTitle || 'New Plan'}
      />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header Section */}
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-foreground">
                    {editMode ? 'Edit Plan' : 'Create New Plan'}
                  </h1>
                  <p className="text-muted-foreground">
                    {editMode 
                      ? 'Modify your plan details and regenerate with AI'
                      : 'Tell us about your goal and we\'ll create a comprehensive plan using AI'
                    }
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  {hasUnsavedChanges && (
                    <div className="flex items-center space-x-1 text-warning">
                      <Icon name="AlertCircle" size={14} />
                      <span className="text-xs">Unsaved changes</span>
                    </div>
                  )}
                  {lastSaved && (
                    <div className="text-xs text-muted-foreground">
                      Last saved: {lastSaved}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Progress Indicator */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">Form Progress</span>
                  <span className="text-sm text-muted-foreground">{getCompletionPercentage()}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full transition-all duration-300"
                    style={{ width: `${getCompletionPercentage()}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Goal Input Section */}
            <GoalInputSection
              goalTitle={formData?.goalTitle}
              onGoalTitleChange={(value) => updateFormData('goalTitle', value)}
              goalDescription={formData?.goalDescription}
              onGoalDescriptionChange={(value) => updateFormData('goalDescription', value)}
            />

            {/* Duration Section */}
            <DurationSection
              startDate={formData?.startDate}
              onStartDateChange={(value) => updateFormData('startDate', value)}
              endDate={formData?.endDate}
              onEndDateChange={(value) => updateFormData('endDate', value)}
              durationType={formData?.durationType}
              onDurationTypeChange={(value) => updateFormData('durationType', value)}
            />

            {/* Budget Section */}
            <BudgetSection
              budget={formData?.budget}
              onBudgetChange={(value) => updateFormData('budget', value)}
              budgetType={formData?.budgetType}
              onBudgetTypeChange={(value) => updateFormData('budgetType', value)}
            />

            {/* Location Section */}
            <LocationSection
              location={formData?.location}
              onLocationChange={(value) => updateFormData('location', value)}
              coordinates={formData?.coordinates}
              onCoordinatesChange={(value) => updateFormData('coordinates', value)}
            />

            {/* Preferences Section */}
            <PreferencesSection
              priorities={formData?.priorities}
              onPrioritiesChange={(value) => updateFormData('priorities', value)}
              constraints={formData?.constraints}
              onConstraintsChange={(value) => updateFormData('constraints', value)}
              style={formData?.style}
              onStyleChange={(value) => updateFormData('style', value)}
            />

            {/* Advanced Options Section */}
            <AdvancedOptionsSection
              teamCollaboration={formData?.teamCollaboration}
              onTeamCollaborationChange={(value) => updateFormData('teamCollaboration', value)}
              notifications={formData?.notifications}
              onNotificationsChange={(value) => updateFormData('notifications', value)}
              template={formData?.template}
              onTemplateChange={(value) => updateFormData('template', value)}
            />

            {/* Action Buttons */}
            <div className="bg-card border border-border rounded-lg p-6">
              {planError && (
                <div className="mb-4 p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                  <div className="flex items-center space-x-2">
                    <Icon name="AlertTriangle" size={16} className="text-destructive" />
                    <span className="text-sm text-destructive">{planError}</span>
                  </div>
                </div>
              )}
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  variant="default"
                  size="lg"
                  onClick={handleStartPlanning}
                  iconName={isGeneratingPlan ? "Loader2" : "Zap"}
                  iconPosition="left"
                  className="flex-1"
                  disabled={!formData?.goalTitle?.trim()}
                  loading={isGeneratingPlan}
                >
                  {isGeneratingPlan 
                    ? (editMode ? 'Regenerating Plan...' : 'Starting AI Planning...') 
                    : (editMode ? 'Regenerate Plan' : 'Start AI Planning')
                  }
                </Button>
                
                <Button
                  variant="outline"
                  size="lg"
                  onClick={handleSaveAsDraft}
                  iconName="Save"
                  iconPosition="left"
                  className="sm:w-auto"
                  disabled={isGeneratingPlan}
                >
                  Save as Draft
                </Button>
              </div>
              
              <div className="mt-4 text-xs text-muted-foreground">
                <Icon name="Info" size={12} className="inline mr-1" />
                Your plan will be generated using OpenAI GPT-4. This process typically takes 2-5 minutes.
              </div>
            </div>
          </div>

          {/* Preview Panel - Desktop Only */}
          <div className="hidden lg:block">
            <div className="sticky top-24">
              <PlanPreviewPanel
                goalTitle={formData?.goalTitle}
                startDate={formData?.startDate}
                endDate={formData?.endDate}
                budget={formData?.budget}
                location={formData?.location}
                priorities={formData?.priorities}
              />
            </div>
          </div>
        </div>

        {/* Mobile Preview Panel */}
        <div className="lg:hidden mt-8">
          <PlanPreviewPanel
            goalTitle={formData?.goalTitle}
            startDate={formData?.startDate}
            endDate={formData?.endDate}
            budget={formData?.budget}
            location={formData?.location}
            priorities={formData?.priorities}
          />
        </div>
      </main>
    </div>
  );
};

export default TaskInputForm;