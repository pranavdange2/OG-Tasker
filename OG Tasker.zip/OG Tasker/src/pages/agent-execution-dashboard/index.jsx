import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import ProgressBreadcrumb from '../../components/ui/ProgressBreadcrumb';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AgentExecutionDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  const taskData = location?.state?.taskData || {
    goalTitle: "Sample Plan",
    budget: 5000
  };

  const steps = [
    "Analyzing requirements",
    "Generating plan structure", 
    "Optimizing timeline",
    "Finalizing details"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          setIsComplete(true);
          clearInterval(interval);
          setTimeout(() => {
            const plan = {
              title: taskData.goalTitle || "Generated Plan",
              summary: "AI-generated comprehensive plan",
              phases: [
                {
                  id: 1,
                  title: "Planning Phase",
                  description: "Initial planning and preparation",
                  duration: 7,
                  budget: (taskData.budget || 5000) * 0.3,
                  tasks: [
                    {
                      id: 1,
                      title: "Research and Analysis",
                      description: "Conduct thorough research",
                      priority: "high",
                      estimatedTime: 3,
                      dependencies: []
                    }
                  ]
                },
                {
                  id: 2,
                  title: "Execution Phase", 
                  description: "Main implementation",
                  duration: 14,
                  budget: (taskData.budget || 5000) * 0.5,
                  tasks: [
                    {
                      id: 2,
                      title: "Implementation",
                      description: "Execute main tasks",
                      priority: "high",
                      estimatedTime: 10,
                      dependencies: [1]
                    }
                  ]
                },
                {
                  id: 3,
                  title: "Completion Phase",
                  description: "Final review",
                  duration: 5,
                  budget: (taskData.budget || 5000) * 0.2,
                  tasks: [
                    {
                      id: 3,
                      title: "Final Review",
                      description: "Review and finalize",
                      priority: "medium", 
                      estimatedTime: 3,
                      dependencies: [2]
                    }
                  ]
                }
              ],
              totalBudget: taskData.budget || 5000,
              totalDuration: 26,
              risks: [
                {
                  title: "Timeline Risk",
                  impact: "medium",
                  mitigation: "Build buffer time"
                }
              ],
              recommendations: [
                "Regular progress reviews",
                "Clear communication",
                "Flexible approach"
              ]
            };

            navigate('/plan-results-timeline', {
              state: {
                generatedPlan: plan,
                taskData: taskData
              }
            });
          }, 2000);
          return 100;
        }
        
        const newProgress = prev + 2;
        setCurrentStep(Math.floor(newProgress / 25));
        return newProgress;
      });
    }, 100);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={true} />
      <ProgressBreadcrumb 
        currentPhase="execution" 
        completedPhases={['input']}
        planTitle={taskData.goalTitle}
      />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-card border border-border rounded-lg p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="Zap" size={24} className="text-white" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">
              AI Planning in Progress
            </h1>
            <p className="text-muted-foreground">
              Creating your comprehensive plan using AI
            </p>
          </div>

          <div className="space-y-6">
            <div className="w-full bg-muted rounded-full h-3">
              <div 
                className="bg-primary h-3 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">
                {progress}%
              </div>
              <div className="text-sm text-muted-foreground">
                {isComplete ? "Plan Generated Successfully!" : steps[currentStep] || "Processing..."}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
              <div className="bg-muted/50 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Target" size={16} className="text-primary" />
                  <span className="text-sm font-medium">Goal</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {taskData.goalTitle || "Sample Plan"}
                </p>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="DollarSign" size={16} className="text-primary" />
                  <span className="text-sm font-medium">Budget</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  ${(taskData.budget || 5000).toLocaleString()}
                </p>
              </div>
            </div>

            {isComplete && (
              <div className="text-center mt-6">
                <Button
                  onClick={() => navigate('/plan-results-timeline', {
                    state: { taskData }
                  })}
                  iconName="ArrowRight"
                  iconPosition="right"
                >
                  View Results
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AgentExecutionDashboard;