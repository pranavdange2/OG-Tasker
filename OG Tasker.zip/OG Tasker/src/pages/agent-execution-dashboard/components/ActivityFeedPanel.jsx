import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const ActivityFeedPanel = ({ activities, systemStatus }) => {
  const [filter, setFilter] = useState('all');
  const [autoScroll, setAutoScroll] = useState(true);

  const getActivityIcon = (type) => {
    switch (type) {
      case 'step_completed': return 'CheckCircle';
      case 'api_call': return 'Zap';
      case 'error': return 'AlertCircle';
      case 'warning': return 'AlertTriangle';
      case 'info': return 'Info';
      case 'system': return 'Settings';
      default: return 'Circle';
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'step_completed': return 'text-success';
      case 'api_call': return 'text-primary';
      case 'error': return 'text-error';
      case 'warning': return 'text-warning';
      case 'info': return 'text-accent';
      case 'system': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const activityTime = new Date(timestamp);
    const diffInSeconds = Math.floor((now - activityTime) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return activityTime?.toLocaleDateString();
  };

  const filteredActivities = activities?.filter(activity => {
    if (filter === 'all') return true;
    return activity?.type === filter;
  });

  const ActivityItem = ({ activity }) => (
    <div className="flex items-start space-x-3 p-3 hover:bg-muted/50 rounded-md transition-colors duration-200">
      <div className={`flex-shrink-0 mt-0.5 ${getActivityColor(activity?.type)}`}>
        <Icon name={getActivityIcon(activity?.type)} size={16} />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <p className="text-sm font-medium text-foreground truncate">
            {activity?.title}
          </p>
          <span className="text-xs text-muted-foreground flex-shrink-0 ml-2">
            {formatTimestamp(activity?.timestamp)}
          </span>
        </div>
        
        <p className="text-sm text-muted-foreground leading-relaxed">
          {activity?.description}
        </p>
        
        {activity?.metadata && (
          <div className="mt-2 flex flex-wrap gap-2">
            {Object.entries(activity?.metadata)?.map(([key, value]) => (
              <span 
                key={key}
                className="px-2 py-1 bg-muted text-xs text-muted-foreground rounded-md"
              >
                {key}: {value}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const SystemStatusIndicator = () => (
    <div className="bg-muted/50 rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-foreground">System Status</h3>
        <div className={`flex items-center space-x-2 ${
          systemStatus?.status === 'healthy' ? 'text-success' : 
          systemStatus?.status === 'warning' ? 'text-warning' : 'text-error'
        }`}>
          <div className="w-2 h-2 rounded-full bg-current animate-pulse"></div>
          <span className="text-xs font-medium capitalize">{systemStatus?.status}</span>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 text-xs">
        <div>
          <div className="text-muted-foreground">CPU Usage</div>
          <div className="font-medium text-foreground">{systemStatus?.cpu}%</div>
        </div>
        <div>
          <div className="text-muted-foreground">Memory</div>
          <div className="font-medium text-foreground">{systemStatus?.memory}%</div>
        </div>
        <div>
          <div className="text-muted-foreground">API Latency</div>
          <div className="font-medium text-foreground">{systemStatus?.latency}ms</div>
        </div>
        <div>
          <div className="text-muted-foreground">Queue Size</div>
          <div className="font-medium text-foreground">{systemStatus?.queueSize}</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-card border border-border rounded-lg p-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">Live Activity</h2>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setAutoScroll(!autoScroll)}
            className={`p-1 rounded-md transition-colors duration-200 ${
              autoScroll ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:bg-muted'
            }`}
            title={autoScroll ? 'Disable auto-scroll' : 'Enable auto-scroll'}
          >
            <Icon name="ArrowDown" size={14} />
          </button>
          <button className="p-1 hover:bg-muted rounded-md transition-colors duration-200">
            <Icon name="MoreVertical" size={14} className="text-muted-foreground" />
          </button>
        </div>
      </div>
      {/* System Status */}
      <SystemStatusIndicator />
      {/* Activity Filters */}
      <div className="flex items-center space-x-2 mb-4 overflow-x-auto">
        {['all', 'step_completed', 'api_call', 'error', 'warning', 'info']?.map((filterType) => (
          <button
            key={filterType}
            onClick={() => setFilter(filterType)}
            className={`px-3 py-1 text-xs font-medium rounded-full whitespace-nowrap transition-colors duration-200 ${
              filter === filterType
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            {filterType === 'all' ? 'All' : filterType?.replace('_', ' ')?.replace(/\b\w/g, l => l?.toUpperCase())}
          </button>
        ))}
      </div>
      {/* Activity Feed */}
      <div className="flex-1 overflow-y-auto space-y-1">
        {filteredActivities?.length > 0 ? (
          filteredActivities?.map((activity) => (
            <ActivityItem key={activity?.id} activity={activity} />
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Icon name="Activity" size={32} className="text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No activities found</p>
            <p className="text-xs text-muted-foreground mt-1">
              {filter !== 'all' ? 'Try changing the filter' : 'Activities will appear here as they happen'}
            </p>
          </div>
        )}
      </div>
      {/* Activity Stats */}
      <div className="border-t border-border pt-4 mt-4">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-sm font-semibold text-foreground">
              {activities?.filter(a => a?.type === 'step_completed')?.length}
            </div>
            <div className="text-xs text-muted-foreground">Completed</div>
          </div>
          <div>
            <div className="text-sm font-semibold text-foreground">
              {activities?.filter(a => a?.type === 'api_call')?.length}
            </div>
            <div className="text-xs text-muted-foreground">API Calls</div>
          </div>
          <div>
            <div className="text-sm font-semibold text-foreground">
              {activities?.filter(a => a?.type === 'error')?.length}
            </div>
            <div className="text-xs text-muted-foreground">Errors</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActivityFeedPanel;