import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const ReasoningVisualization = ({ reasoningSteps, currentStep, onStepClick }) => {
  const [animatingConnections, setAnimatingConnections] = useState(new Set());
  const [hoveredStep, setHoveredStep] = useState(null);

  useEffect(() => {
    // Animate connections as they form
    if (currentStep > 0) {
      const newConnection = `${currentStep - 1}-${currentStep}`;
      setAnimatingConnections(prev => new Set([...prev, newConnection]));
      
      setTimeout(() => {
        setAnimatingConnections(prev => {
          const updated = new Set(prev);
          updated?.delete(newConnection);
          return updated;
        });
      }, 1000);
    }
  }, [currentStep]);

  const getStepStatus = (index) => {
    if (index < currentStep) return 'completed';
    if (index === currentStep) return 'active';
    return 'pending';
  };

  const getStepIcon = (step, status) => {
    if (status === 'completed') return 'CheckCircle';
    if (status === 'active') return step?.type === 'api' ? 'Zap' : 'Brain';
    return step?.type === 'api' ? 'Globe' : 'Circle';
  };

  const getStepColor = (status) => {
    switch (status) {
      case 'completed': return 'text-success bg-success/10 border-success/20';
      case 'active': return 'text-primary bg-primary/10 border-primary/20';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const StepNode = ({ step, index, status }) => (
    <div className="relative">
      <button
        onClick={() => onStepClick(step, index)}
        onMouseEnter={() => setHoveredStep(index)}
        onMouseLeave={() => setHoveredStep(null)}
        className={`
          relative w-16 h-16 rounded-full border-2 transition-all duration-300 hover:scale-110
          ${getStepColor(status)}
          ${status === 'active' ? 'animate-pulse' : ''}
        `}
      >
        <Icon 
          name={getStepIcon(step, status)} 
          size={20} 
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        />
        
        {/* Step number */}
        <div className="absolute -bottom-2 -right-2 w-6 h-6 bg-background border border-border rounded-full flex items-center justify-center">
          <span className="text-xs font-medium">{index + 1}</span>
        </div>

        {/* Loading indicator for active step */}
        {status === 'active' && (
          <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-primary animate-spin"></div>
        )}
      </button>

      {/* Hover tooltip */}
      {hoveredStep === index && (
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 z-10">
          <div className="bg-popover border border-border rounded-md shadow-lg p-3 min-w-48">
            <div className="text-sm font-medium text-popover-foreground mb-1">
              {step?.title}
            </div>
            <div className="text-xs text-muted-foreground">
              {step?.description}
            </div>
            {step?.duration && (
              <div className="text-xs text-muted-foreground mt-1">
                Duration: {step?.duration}ms
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );

  const ConnectionLine = ({ fromIndex, toIndex }) => {
    const isAnimating = animatingConnections?.has(`${fromIndex}-${toIndex}`);
    const isCompleted = toIndex <= currentStep;
    
    return (
      <div className="relative flex-1 h-0.5 mx-4 my-8">
        <div className={`
          absolute inset-0 rounded-full transition-all duration-300
          ${isCompleted ? 'bg-success' : 'bg-border'}
        `}></div>
        
        {isAnimating && (
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full animate-pulse"></div>
        )}
        
        {/* Flow indicator */}
        {isCompleted && (
          <div className="absolute right-0 top-1/2 transform -translate-y-1/2">
            <Icon name="ChevronRight" size={12} className="text-success" />
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 h-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-foreground">AI Reasoning Process</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
            <span className="text-xs text-primary font-medium">Processing</span>
          </div>
          <button className="p-1 hover:bg-muted rounded-md transition-colors duration-200">
            <Icon name="Maximize2" size={16} className="text-muted-foreground" />
          </button>
        </div>
      </div>
      {/* Reasoning Flow */}
      <div className="relative">
        <div className="flex flex-col space-y-6 max-h-96 overflow-y-auto">
          {reasoningSteps?.map((step, index) => {
            const status = getStepStatus(index);
            
            return (
              <div key={step?.id} className="flex items-center">
                <StepNode step={step} index={index} status={status} />
                <div className="flex-1 ml-4">
                  <div className="bg-muted/50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-medium text-foreground">
                        {step?.title}
                      </h3>
                      <div className="flex items-center space-x-2">
                        {step?.type === 'api' && (
                          <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-md">
                            API Call
                          </span>
                        )}
                        {status === 'completed' && step?.duration && (
                          <span className="text-xs text-muted-foreground">
                            {step?.duration}ms
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-2">
                      {step?.description}
                    </p>
                    
                    {step?.output && status === 'completed' && (
                      <div className="mt-3 p-3 bg-background border border-border rounded-md">
                        <div className="text-xs text-muted-foreground mb-1">Output:</div>
                        <div className="text-sm text-foreground font-mono">
                          {step?.output}
                        </div>
                      </div>
                    )}
                    
                    {status === 'active' && (
                      <div className="mt-3 flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                        <span className="text-sm text-primary">Processing...</span>
                      </div>
                    )}
                  </div>
                </div>
                {index < reasoningSteps?.length - 1 && (
                  <div className="absolute left-8 mt-20 w-0.5 h-6 bg-border"></div>
                )}
              </div>
            );
          })}
        </div>
      </div>
      {/* Controls */}
      <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
        <div className="flex items-center space-x-2">
          <button className="p-2 hover:bg-muted rounded-md transition-colors duration-200">
            <Icon name="Pause" size={16} className="text-muted-foreground" />
          </button>
          <button className="p-2 hover:bg-muted rounded-md transition-colors duration-200">
            <Icon name="SkipForward" size={16} className="text-muted-foreground" />
          </button>
        </div>
        
        <div className="text-xs text-muted-foreground">
          Step {currentStep + 1} of {reasoningSteps?.length}
        </div>
        
        <div className="flex items-center space-x-2">
          <button className="p-2 hover:bg-muted rounded-md transition-colors duration-200">
            <Icon name="ZoomIn" size={16} className="text-muted-foreground" />
          </button>
          <button className="p-2 hover:bg-muted rounded-md transition-colors duration-200">
            <Icon name="ZoomOut" size={16} className="text-muted-foreground" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReasoningVisualization;