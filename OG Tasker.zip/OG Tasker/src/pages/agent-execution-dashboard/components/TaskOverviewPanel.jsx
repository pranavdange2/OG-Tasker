import React from 'react';
import Icon from '../../../components/AppIcon';

const TaskOverviewPanel = ({ taskData, metrics }) => {
  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  const formatBudget = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })?.format(amount);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 h-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-foreground">Task Overview</h2>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
          <span className="text-xs text-success font-medium">Active</span>
        </div>
      </div>
      {/* Goal Summary */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-foreground mb-2">Current Goal</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {taskData?.title}
        </p>
      </div>
      {/* Key Details */}
      <div className="space-y-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Duration</span>
          </div>
          <span className="text-sm font-medium text-foreground">
            {formatDuration(taskData?.duration)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="DollarSign" size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Budget</span>
          </div>
          <span className="text-sm font-medium text-foreground">
            {formatBudget(taskData?.budget)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="MapPin" size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Location</span>
          </div>
          <span className="text-sm font-medium text-foreground">
            {taskData?.location}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Users" size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Attendees</span>
          </div>
          <span className="text-sm font-medium text-foreground">
            {taskData?.attendees}
          </span>
        </div>
      </div>
      {/* Progress Metrics */}
      <div className="border-t border-border pt-6">
        <h3 className="text-sm font-medium text-foreground mb-4">Progress Metrics</h3>
        
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Overall Progress</span>
              <span className="text-xs font-medium text-foreground">{metrics?.overallProgress}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${metrics?.overallProgress}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Steps Completed</span>
              <span className="text-xs font-medium text-foreground">
                {metrics?.completedSteps}/{metrics?.totalSteps}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-success h-2 rounded-full transition-all duration-300"
                style={{ width: `${(metrics?.completedSteps / metrics?.totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="text-center">
              <div className="text-lg font-semibold text-foreground">{metrics?.apiCalls}</div>
              <div className="text-xs text-muted-foreground">API Calls</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-foreground">{formatDuration(metrics?.timeElapsed)}</div>
              <div className="text-xs text-muted-foreground">Time Elapsed</div>
            </div>
          </div>
        </div>
      </div>
      {/* Estimated Completion */}
      <div className="border-t border-border pt-4 mt-6">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">Est. Completion</span>
          <span className="text-xs font-medium text-foreground">{metrics?.estimatedCompletion}</span>
        </div>
      </div>
    </div>
  );
};

export default TaskOverviewPanel;