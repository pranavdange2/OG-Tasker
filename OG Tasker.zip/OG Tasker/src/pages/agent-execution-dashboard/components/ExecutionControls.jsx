import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ExecutionControls = ({ 
  isRunning, 
  isPaused, 
  onPause, 
  onResume, 
  onStop, 
  onExport,
  executionSpeed = 1,
  onSpeedChange 
}) => {
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  const speedOptions = [
    { value: 0.5, label: '0.5x Slow' },
    { value: 1, label: '1x Normal' },
    { value: 2, label: '2x Fast' },
    { value: 4, label: '4x Very Fast' }
  ];

  const exportOptions = [
    { type: 'json', label: 'JSON Report', icon: 'FileText' },
    { type: 'pdf', label: 'PDF Summary', icon: 'FileDown' },
    { type: 'csv', label: 'CSV Data', icon: 'Table' }
  ];

  const handleSpeedChange = (speed) => {
    onSpeedChange(speed);
    setShowSpeedMenu(false);
  };

  const handleExport = (type) => {
    onExport(type);
    setShowExportMenu(false);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center justify-between">
        {/* Main Controls */}
        <div className="flex items-center space-x-3">
          {!isRunning ? (
            <Button
              variant="default"
              size="sm"
              iconName="Play"
              iconPosition="left"
              onClick={onResume}
            >
              Start
            </Button>
          ) : isPaused ? (
            <Button
              variant="default"
              size="sm"
              iconName="Play"
              iconPosition="left"
              onClick={onResume}
            >
              Resume
            </Button>
          ) : (
            <Button
              variant="outline"
              size="sm"
              iconName="Pause"
              iconPosition="left"
              onClick={onPause}
            >
              Pause
            </Button>
          )}

          <Button
            variant="outline"
            size="sm"
            iconName="Square"
            iconPosition="left"
            onClick={onStop}
            disabled={!isRunning}
          >
            Stop
          </Button>

          {/* Speed Control */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              iconName="Gauge"
              iconPosition="left"
              onClick={() => setShowSpeedMenu(!showSpeedMenu)}
            >
              {executionSpeed}x
            </Button>

            {showSpeedMenu && (
              <div className="absolute top-full left-0 mt-2 bg-popover border border-border rounded-md shadow-lg z-50 min-w-32">
                <div className="py-1">
                  {speedOptions?.map((option) => (
                    <button
                      key={option?.value}
                      onClick={() => handleSpeedChange(option?.value)}
                      className={`w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors duration-200 ${
                        executionSpeed === option?.value ? 'bg-muted text-foreground' : 'text-muted-foreground'
                      }`}
                    >
                      {option?.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Secondary Controls */}
        <div className="flex items-center space-x-3">
          {/* Export Menu */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              iconName="Download"
              iconPosition="left"
              onClick={() => setShowExportMenu(!showExportMenu)}
            >
              Export
            </Button>

            {showExportMenu && (
              <div className="absolute top-full right-0 mt-2 bg-popover border border-border rounded-md shadow-lg z-50 min-w-40">
                <div className="py-1">
                  {exportOptions?.map((option) => (
                    <button
                      key={option?.type}
                      onClick={() => handleExport(option?.type)}
                      className="w-full px-3 py-2 text-left text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-colors duration-200 flex items-center space-x-2"
                    >
                      <Icon name={option?.icon} size={14} />
                      <span>{option?.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <Button
            variant="ghost"
            size="sm"
            iconName="Share"
            iconPosition="left"
          >
            Share
          </Button>

          <Button
            variant="ghost"
            size="sm"
            iconName="Settings"
            iconPosition="left"
          >
            Settings
          </Button>
        </div>
      </div>
      {/* Status Indicator */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${
            isRunning && !isPaused ? 'bg-success animate-pulse' : isPaused ?'bg-warning' : 'bg-muted-foreground'
          }`}></div>
          <span className="text-sm text-muted-foreground">
            {isRunning && !isPaused ? 'Running' : isPaused ? 'Paused' : 'Stopped'}
          </span>
        </div>

        <div className="text-xs text-muted-foreground">
          Speed: {executionSpeed}x
        </div>
      </div>
      {/* Overlay for menus */}
      {(showSpeedMenu || showExportMenu) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => {
            setShowSpeedMenu(false);
            setShowExportMenu(false);
          }}
        />
      )}
    </div>
  );
};

export default ExecutionControls;