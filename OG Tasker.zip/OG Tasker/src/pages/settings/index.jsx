import React from 'react';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';
import { useTheme } from '../../contexts/ThemeContext';

const Settings = () => {
  const { isDarkMode, toggleDarkMode } = useTheme();
  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={true} />
      
      <div className="max-w-4xl mx-auto px-4 py-16">
        <h1 className="text-3xl font-bold text-foreground mb-8">Settings</h1>
        
        <div className="space-y-6">
          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">Account Settings</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Email</label>
                <input className="w-full p-3 border border-border rounded-md bg-background" value="user@example.com" readOnly />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Name</label>
                <input className="w-full p-3 border border-border rounded-md bg-background" placeholder="Your Name" />
              </div>
            </div>
          </div>

          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">Preferences</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-foreground">Email Notifications</span>
                <input type="checkbox" className="toggle" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-foreground">Dark Mode</span>
                <input 
                  type="checkbox" 
                  className="toggle" 
                  checked={isDarkMode}
                  onChange={toggleDarkMode}
                />
              </div>
            </div>
          </div>

          <Button variant="default">Save Changes</Button>
        </div>
      </div>
    </div>
  );
};

export default Settings;