import React from 'react';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={false} />
      
      <div className="max-w-4xl mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            About AI Task Planner
          </h1>
          <p className="text-xl text-muted-foreground">
            Revolutionizing project management with artificial intelligence.
          </p>
        </div>

        <div className="space-y-12">
          <div className="bg-card p-8 rounded-lg border border-border">
            <h2 className="text-2xl font-bold text-foreground mb-4">Our Mission</h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              We believe that intelligent planning should be accessible to everyone. Our AI-powered task planner 
              helps individuals and teams create comprehensive, actionable plans that turn ambitious goals into 
              achievable milestones.
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg border border-border">
            <h2 className="text-2xl font-bold text-foreground mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Simply describe your goal, and our advanced AI algorithms analyze your requirements to generate 
              detailed task breakdowns, timelines, and resource allocations. Whether you're planning an event, 
              launching a product, or organizing a project, we make complex planning simple.
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg border border-border">
            <h2 className="text-2xl font-bold text-foreground mb-4">Why Choose Us</h2>
            <ul className="space-y-3 text-muted-foreground text-lg">
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mr-3 mt-3"></span>
                AI-powered intelligence that learns from millions of successful projects
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mr-3 mt-3"></span>
                Intuitive interface designed for both beginners and experts
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mr-3 mt-3"></span>
                Real-time collaboration and progress tracking
              </li>
            </ul>
          </div>
        </div>

        <div className="text-center mt-16">
          <Button variant="default" size="lg">
            Start Planning Today
          </Button>
        </div>
      </div>
    </div>
  );
};

export default About;