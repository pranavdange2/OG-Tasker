import React from 'react';

const FooterLinks = () => {
  const handleLinkClick = (type) => {
    // Mock link functionality
    alert(`${type} page would open here`);
  };

  return (
    <div className="text-center mt-8 pt-6 border-t border-border">
      <div className="flex flex-wrap justify-center items-center space-x-4 text-xs text-muted-foreground">
        <button
          onClick={() => handleLinkClick('Privacy Policy')}
          className="hover:text-foreground transition-colors duration-200"
        >
          Privacy Policy
        </button>
        <span>•</span>
        <button
          onClick={() => handleLinkClick('Terms of Service')}
          className="hover:text-foreground transition-colors duration-200"
        >
          Terms of Service
        </button>
        <span>•</span>
        <button
          onClick={() => handleLinkClick('Help Center')}
          className="hover:text-foreground transition-colors duration-200"
        >
          Help Center
        </button>
      </div>
      <div className="mt-2 text-xs text-muted-foreground">
        © {new Date()?.getFullYear()} AI Task Planner. All rights reserved.
      </div>
    </div>
  );
};

export default FooterLinks;