import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityBadge = () => {
  return (
    <div className="flex items-center justify-center space-x-2 text-xs text-muted-foreground mt-6">
      <Icon name="Shield" size={14} className="text-success" />
      <span>Secured with 256-bit SSL encryption</span>
    </div>
  );
};

export default SecurityBadge;