import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import AuthTabs from './components/AuthTabs';
import SocialAuthButtons from './components/SocialAuthButtons';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import SecurityBadge from './components/SecurityBadge';
import FooterLinks from './components/FooterLinks';
import Icon from '../../components/AppIcon';

const UserAuthentication = () => {
  const [activeTab, setActiveTab] = useState('login');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showWelcome, setShowWelcome] = useState(false);
  const navigate = useNavigate();

  // Mock credentials for demonstration
  const mockCredentials = {
    email: 'demo@aitaskplanner.com',
    password: 'Demo123!'
  };

  useEffect(() => {
    // Auto-focus first input field
    const firstInput = document.querySelector('input');
    if (firstInput) {
      firstInput?.focus();
    }
  }, [activeTab]);

  const handleSocialAuth = async (provider) => {
    setIsLoading(true);
    setError('');
    
    try {
      // Mock social authentication
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate successful authentication
      setShowWelcome(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    } catch (err) {
      setError(`Failed to authenticate with ${provider}. Please try again.`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (formData) => {
    setIsLoading(true);
    setError('');
    
    try {
      // Mock login validation
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (formData?.email === mockCredentials?.email && formData?.password === mockCredentials?.password) {
        // Successful login
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('userEmail', formData?.email);
        
        setShowWelcome(true);
        setTimeout(() => {
          navigate('/dashboard');
        }, 2000);
      } else {
        setError('Invalid email or password. Please try demo@aitaskplanner.com / Demo123!');
      }
    } catch (err) {
      setError('Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (formData) => {
    setIsLoading(true);
    setError('');
    
    try {
      // Mock registration
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate successful registration
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('userEmail', formData?.email);
      localStorage.setItem('userName', formData?.name);
      
      setShowWelcome(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    } catch (err) {
      setError('Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackToHome = () => {
    navigate('/landing-page');
  };

  if (showWelcome) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4 animate-fade-in">
          <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto">
            <Icon name="CheckCircle" size={32} color="white" />
          </div>
          <h2 className="text-2xl font-semibold text-foreground">Welcome to AI Task Planner!</h2>
          <p className="text-muted-foreground">Redirecting you to your dashboard...</p>
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={false} />
      
      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">
          {/* Back Navigation */}
          <button
            onClick={handleBackToHome}
            className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors duration-200 mb-6"
          >
            <Icon name="ArrowLeft" size={16} />
            <span className="text-sm">Back to Home</span>
          </button>

          {/* Main Auth Card */}
          <div className="bg-card border border-border rounded-lg shadow-card-elevation p-6">
            {/* Header */}
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
                <Icon name="Brain" size={24} color="white" />
              </div>
              <h1 className="text-2xl font-semibold text-foreground mb-2">
                {activeTab === 'login' ? 'Welcome Back' : 'Create Your Account'}
              </h1>
              <p className="text-muted-foreground text-sm">
                {activeTab === 'login' ?'Sign in to continue your AI-powered planning journey' :'Join thousands of users who trust AI Task Planner'
                }
              </p>
            </div>

            {/* Auth Tabs */}
            <AuthTabs activeTab={activeTab} onTabChange={setActiveTab} />

            {/* Social Auth Buttons */}
            <SocialAuthButtons onSocialAuth={handleSocialAuth} isLoading={isLoading} />

            {/* Auth Forms */}
            {activeTab === 'login' ? (
              <LoginForm 
                onSubmit={handleLogin} 
                isLoading={isLoading} 
                error={error}
              />
            ) : (
              <RegisterForm 
                onSubmit={handleRegister} 
                isLoading={isLoading} 
                error={error}
              />
            )}

            {/* Demo Credentials Info */}
            {activeTab === 'login' && (
              <div className="mt-4 p-3 bg-muted/50 rounded-md">
                <p className="text-xs text-muted-foreground text-center">
                  <strong>Demo Credentials:</strong><br />
                  Email: demo@aitaskplanner.com<br />
                  Password: Demo123!
                </p>
              </div>
            )}

            {/* Security Badge */}
            <SecurityBadge />
          </div>

          {/* Footer Links */}
          <FooterLinks />
        </div>
      </div>
    </div>
  );
};

export default UserAuthentication;