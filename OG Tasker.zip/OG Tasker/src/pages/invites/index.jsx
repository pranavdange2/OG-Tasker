import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const Invites = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { venue, bookingData, schedule } = location.state || {};
  
  const [inviteData, setInviteData] = useState({
    subject: `Invitation: Event at ${venue?.name || 'Venue'}`,
    message: `You're invited to our event at ${venue?.name || 'our venue'} on ${bookingData?.date || 'the scheduled date'}.`,
    template: 'professional'
  });

  const [contacts, setContacts] = useState([
    { id: 1, name: 'John Smith', email: 'john@example.com', status: 'pending', selected: true },
    { id: 2, name: 'Sarah Johnson', email: 'sarah@example.com', status: 'pending', selected: true },
    { id: 3, name: 'Mike Wilson', email: 'mike@example.com', status: 'pending', selected: false }
  ]);

  const [newContact, setNewContact] = useState({ name: '', email: '' });
  const [sentInvites, setSentInvites] = useState([]);

  const addContact = () => {
    if (!newContact.name || !newContact.email) {
      alert('Please fill in name and email');
      return;
    }

    const newId = Math.max(...contacts.map(c => c.id), 0) + 1;
    setContacts([...contacts, { 
      ...newContact, 
      id: newId, 
      status: 'pending', 
      selected: true 
    }]);
    setNewContact({ name: '', email: '' });
  };

  const toggleContact = (id) => {
    setContacts(contacts.map(c => 
      c.id === id ? { ...c, selected: !c.selected } : c
    ));
  };

  const removeContact = (id) => {
    setContacts(contacts.filter(c => c.id !== id));
  };

  const sendInvites = () => {
    const selectedContacts = contacts.filter(c => c.selected);
    
    if (selectedContacts.length === 0) {
      alert('Please select at least one contact');
      return;
    }

    // Simulate sending invites
    const newSentInvites = selectedContacts.map(contact => ({
      ...contact,
      sentAt: new Date().toLocaleString(),
      status: 'sent'
    }));

    setSentInvites([...sentInvites, ...newSentInvites]);
    
    // Update contact status
    setContacts(contacts.map(c => 
      c.selected ? { ...c, status: 'sent', selected: false } : c
    ));

    alert(`Successfully sent ${selectedContacts.length} invites!`);
  };

  const templates = {
    professional: `Dear [Name],

You are cordially invited to attend our event at ${venue?.name || 'our venue'}.

Event Details:
📅 Date: ${bookingData?.date || 'TBD'}
🕐 Time: ${bookingData?.time || 'TBD'}
📍 Location: ${venue?.location || 'TBD'}

We look forward to your presence.

Best regards,
Event Team`,
    
    casual: `Hi [Name]!

You're invited to join us for an awesome event!

When: ${bookingData?.date || 'TBD'} at ${bookingData?.time || 'TBD'}
Where: ${venue?.name || 'Our venue'}

Hope to see you there! 🎉

Cheers!`,
    
    formal: `Dear [Name],

We have the honor to invite you to our upcoming event.

Event Information:
Date: ${bookingData?.date || 'To be determined'}
Time: ${bookingData?.time || 'To be determined'}
Venue: ${venue?.name || 'To be determined'}
Address: ${venue?.location || 'To be determined'}

Your presence would be highly appreciated.

Sincerely,
The Organizing Committee`
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isAuthenticated={true} />
      
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Send Invites</h1>
          <p className="text-gray-600">Invite guests to your event</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Invite Composition */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-xl font-semibold mb-4">Compose Invitation</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={inviteData.subject}
                    onChange={(e) => setInviteData({...inviteData, subject: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Template
                  </label>
                  <select
                    value={inviteData.template}
                    onChange={(e) => setInviteData({
                      ...inviteData, 
                      template: e.target.value,
                      message: templates[e.target.value]
                    })}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="professional">Professional</option>
                    <option value="casual">Casual</option>
                    <option value="formal">Formal</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    value={inviteData.message}
                    onChange={(e) => setInviteData({...inviteData, message: e.target.value})}
                    rows={10}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>
              </div>
            </div>

            {/* Event Summary */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h3 className="font-semibold mb-3">Event Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Venue:</span>
                  <span>{venue?.name || 'Not selected'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Date:</span>
                  <span>{bookingData?.date || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Time:</span>
                  <span>{bookingData?.time || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Activities:</span>
                  <span>{schedule?.length || 0}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Management */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-xl font-semibold mb-4">Guest List</h2>
              
              {/* Add Contact */}
              <div className="mb-4 p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium mb-3">Add New Contact</h3>
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <input
                    type="text"
                    value={newContact.name}
                    onChange={(e) => setNewContact({...newContact, name: e.target.value})}
                    placeholder="Name"
                    className="p-2 border border-gray-300 rounded-md"
                  />
                  <input
                    type="email"
                    value={newContact.email}
                    onChange={(e) => setNewContact({...newContact, email: e.target.value})}
                    placeholder="Email"
                    className="p-2 border border-gray-300 rounded-md"
                  />
                </div>
                <Button
                  onClick={addContact}
                  size="sm"
                  iconName="Plus"
                  iconPosition="left"
                >
                  Add Contact
                </Button>
              </div>

              {/* Contact List */}
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {contacts.map((contact) => (
                  <div key={contact.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={contact.selected}
                        onChange={() => toggleContact(contact.id)}
                        className="w-4 h-4"
                      />
                      <div>
                        <div className="font-medium">{contact.name}</div>
                        <div className="text-sm text-gray-600">{contact.email}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        contact.status === 'sent' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {contact.status}
                      </span>
                      <button
                        onClick={() => removeContact(contact.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded"
                      >
                        <Icon name="Trash2" size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm text-gray-600">
                    {contacts.filter(c => c.selected).length} selected
                  </span>
                  <Button
                    onClick={sendInvites}
                    disabled={contacts.filter(c => c.selected).length === 0}
                    iconName="Send"
                    iconPosition="left"
                  >
                    Send Invites
                  </Button>
                </div>
              </div>
            </div>

            {/* Sent Invites */}
            {sentInvites.length > 0 && (
              <div className="bg-white rounded-lg border border-gray-200 p-6">
                <h3 className="font-semibold mb-3">Sent Invites ({sentInvites.length})</h3>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {sentInvites.map((invite, index) => (
                    <div key={index} className="flex justify-between items-center text-sm">
                      <span>{invite.name}</span>
                      <span className="text-gray-500">{invite.sentAt}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 text-center">
          <Button
            onClick={() => navigate('/plan-results-timeline')}
            variant="outline"
            iconName="ArrowLeft"
            iconPosition="left"
          >
            Back to Dashboard
          </Button>
        </div>
      </main>
    </div>
  );
};

export default Invites;