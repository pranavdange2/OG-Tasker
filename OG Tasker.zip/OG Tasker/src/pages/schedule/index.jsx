import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const Schedule = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { venue, bookingData } = location.state || {};
  
  const [schedule, setSchedule] = useState([
    { id: 1, time: '09:00', activity: 'Registration & Welcome', duration: 30, speaker: '' },
    { id: 2, time: '09:30', activity: 'Opening Keynote', duration: 60, speaker: '' },
    { id: 3, time: '10:30', activity: 'Coffee Break', duration: 15, speaker: '' },
    { id: 4, time: '10:45', activity: 'Panel Discussion', duration: 45, speaker: '' },
    { id: 5, time: '11:30', activity: 'Networking Session', duration: 30, speaker: '' }
  ]);

  const [newActivity, setNewActivity] = useState({
    time: '',
    activity: '',
    duration: '',
    speaker: ''
  });

  const addActivity = () => {
    if (!newActivity.time || !newActivity.activity) {
      alert('Please fill in time and activity');
      return;
    }

    const newId = Math.max(...schedule.map(s => s.id)) + 1;
    setSchedule([...schedule, { ...newActivity, id: newId, duration: parseInt(newActivity.duration) || 30 }]);
    setNewActivity({ time: '', activity: '', duration: '', speaker: '' });
  };

  const removeActivity = (id) => {
    setSchedule(schedule.filter(s => s.id !== id));
  };

  const updateActivity = (id, field, value) => {
    setSchedule(schedule.map(s => 
      s.id === id ? { ...s, [field]: value } : s
    ));
  };

  const proceedToInvites = () => {
    navigate('/invites', {
      state: {
        venue,
        bookingData,
        schedule
      }
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isAuthenticated={true} />
      
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Event Schedule</h1>
          <p className="text-gray-600">Plan your event timeline and activities</p>
        </div>

        {venue && (
          <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-lg">{venue.name}</h3>
                <p className="text-gray-600">{bookingData.date} at {bookingData.time}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Expected Guests</p>
                <p className="font-semibold">{bookingData.guests || 'Not specified'}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg border border-gray-200">
              <div className="p-4 border-b border-gray-200">
                <h2 className="text-xl font-semibold">Event Timeline</h2>
              </div>
              
              <div className="p-4">
                <div className="space-y-3">
                  {schedule.map((item) => (
                    <div key={item.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                      <div className="w-20">
                        <input
                          type="time"
                          value={item.time}
                          onChange={(e) => updateActivity(item.id, 'time', e.target.value)}
                          className="w-full text-sm p-1 border border-gray-300 rounded"
                        />
                      </div>
                      
                      <div className="flex-1">
                        <input
                          type="text"
                          value={item.activity}
                          onChange={(e) => updateActivity(item.id, 'activity', e.target.value)}
                          className="w-full p-2 border border-gray-300 rounded"
                          placeholder="Activity name"
                        />
                      </div>
                      
                      <div className="w-24">
                        <input
                          type="number"
                          value={item.duration}
                          onChange={(e) => updateActivity(item.id, 'duration', parseInt(e.target.value))}
                          className="w-full text-sm p-1 border border-gray-300 rounded"
                          placeholder="Min"
                        />
                      </div>
                      
                      <div className="w-32">
                        <input
                          type="text"
                          value={item.speaker}
                          onChange={(e) => updateActivity(item.id, 'speaker', e.target.value)}
                          className="w-full text-sm p-1 border border-gray-300 rounded"
                          placeholder="Speaker"
                        />
                      </div>
                      
                      <button
                        onClick={() => removeActivity(item.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded"
                      >
                        <Icon name="Trash2" size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border border-gray-200 p-6 sticky top-4">
              <h2 className="text-xl font-semibold mb-4">Add Activity</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Time
                  </label>
                  <input
                    type="time"
                    value={newActivity.time}
                    onChange={(e) => setNewActivity({...newActivity, time: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Activity
                  </label>
                  <input
                    type="text"
                    value={newActivity.activity}
                    onChange={(e) => setNewActivity({...newActivity, activity: e.target.value})}
                    placeholder="Activity name"
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Duration (minutes)
                  </label>
                  <input
                    type="number"
                    value={newActivity.duration}
                    onChange={(e) => setNewActivity({...newActivity, duration: e.target.value})}
                    placeholder="30"
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Speaker (optional)
                  </label>
                  <input
                    type="text"
                    value={newActivity.speaker}
                    onChange={(e) => setNewActivity({...newActivity, speaker: e.target.value})}
                    placeholder="Speaker name"
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <Button
                  onClick={addActivity}
                  className="w-full"
                  iconName="Plus"
                  iconPosition="left"
                >
                  Add Activity
                </Button>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="mb-4">
                  <h3 className="font-medium text-gray-900 mb-2">Schedule Summary</h3>
                  <div className="text-sm text-gray-600 space-y-1">
                    <div className="flex justify-between">
                      <span>Total Activities:</span>
                      <span>{schedule.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Duration:</span>
                      <span>{schedule.reduce((sum, item) => sum + (item.duration || 0), 0)} min</span>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={proceedToInvites}
                  className="w-full"
                  disabled={schedule.length === 0}
                >
                  Continue to Invites
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Schedule;