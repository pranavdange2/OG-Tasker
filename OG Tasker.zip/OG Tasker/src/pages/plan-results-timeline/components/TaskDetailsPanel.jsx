import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const TaskDetailsPanel = ({ 
  task = null, 
  isOpen = false, 
  onClose = () => {}, 
  onTaskUpdate = () => {},
  allTasks = []
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTask, setEditedTask] = useState(task || {});

  React.useEffect(() => {
    if (task) {
      setEditedTask(task);
      setIsEditing(false);
    }
  }, [task]);

  const handleSave = () => {
    if (editedTask && editedTask.id) {
      onTaskUpdate(editedTask);
      setIsEditing(false);
      // Show success feedback
      console.log('Task updated successfully:', editedTask.title);
    }
  };

  const handleCancel = () => {
    setEditedTask(task || {});
    setIsEditing(false);
  };

  const getDependentTasks = () => {
    return allTasks?.filter(t => t?.dependencies?.includes(task?.id));
  };

  const getDependencyTasks = () => {
    return allTasks?.filter(t => task?.dependencies?.includes(t?.id));
  };

  if (!isOpen || !task) {
    return (
      <div className="w-12 bg-card border-l border-border flex flex-col items-center py-4">
        <Icon name="PanelRight" size={20} className="text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="w-96 bg-card border-l border-border flex flex-col">
      {/* Panel Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <div className={`
            w-8 h-8 rounded-lg flex items-center justify-center
            ${task?.priority === 'high' ? 'bg-error/10 text-error' :
              task?.priority === 'medium'? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'}
          `}>
            <Icon name={task?.icon || 'Circle'} size={16} />
          </div>
          <h3 className="font-semibold text-foreground">Task Details</h3>
        </div>
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="sm"
            iconName={isEditing ? "Save" : "Edit3"}
            onClick={isEditing ? handleSave : () => setIsEditing(true)}
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="X"
            onClick={onClose}
          />
        </div>
      </div>
      {/* Panel Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Basic Information */}
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Task Name</label>
            {isEditing ? (
              <Input
                value={editedTask?.title || ''}
                onChange={(e) => setEditedTask({ ...editedTask, title: e?.target?.value })}
                placeholder="Enter task name"
              />
            ) : (
              <h2 className="text-lg font-semibold text-foreground">{task?.title}</h2>
            )}
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Description</label>
            {isEditing ? (
              <textarea
                className="w-full p-3 border border-border rounded-md bg-background text-foreground resize-none"
                rows={4}
                value={editedTask?.description || ''}
                onChange={(e) => setEditedTask({ ...editedTask, description: e?.target?.value })}
                placeholder="Enter task description"
              />
            ) : (
              <p className="text-muted-foreground">{task?.description || 'No description provided'}</p>
            )}
          </div>
        </div>

        {/* Status and Priority */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Priority</label>
            {isEditing ? (
              <select
                className="w-full p-2 border border-border rounded-md bg-background text-foreground"
                value={editedTask?.priority || 'low'}
                onChange={(e) => setEditedTask({ ...editedTask, priority: e?.target?.value })}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            ) : (
              <span className={`
                inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                ${task?.priority === 'high' ? 'bg-error/10 text-error' :
                  task?.priority === 'medium'? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'}
              `}>
                {task?.priority || 'low'}
              </span>
            )}
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Status</label>
            {isEditing ? (
              <select
                className="w-full p-2 border border-border rounded-md bg-background text-foreground"
                value={editedTask?.status || 'pending'}
                onChange={(e) => setEditedTask({ ...editedTask, status: e?.target?.value })}
              >
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="on-hold">On Hold</option>
              </select>
            ) : (
              <span className={`
                inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                ${task?.status === 'completed' ? 'bg-success/10 text-success' :
                  task?.status === 'in-progress'? 'bg-warning/10 text-warning' : 'bg-muted text-muted-foreground'}
              `}>
                {task?.status || 'pending'}
              </span>
            )}
          </div>
        </div>

        {/* Time and Cost */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Estimated Time</label>
            {isEditing ? (
              <Input
                value={editedTask?.estimatedTime || ''}
                onChange={(e) => setEditedTask({ ...editedTask, estimatedTime: e?.target?.value })}
                placeholder="e.g., 2h, 1d"
              />
            ) : (
              <div className="flex items-center space-x-2">
                <Icon name="Clock" size={16} className="text-muted-foreground" />
                <span className="text-foreground">{task?.estimatedTime || '2h'}</span>
              </div>
            )}
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Cost</label>
            {isEditing ? (
              <Input
                type="number"
                value={editedTask?.cost || ''}
                onChange={(e) => setEditedTask({ ...editedTask, cost: e?.target?.value })}
                placeholder="0"
              />
            ) : (
              <div className="flex items-center space-x-2">
                <Icon name="IndianRupee" size={16} className="text-muted-foreground" />
                <span className="text-foreground">₹{task?.cost || '0'}</span>
              </div>
            )}
          </div>
        </div>

        {/* Assignee */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Assignee</label>
          {isEditing ? (
            <Input
              value={editedTask?.assignee || ''}
              onChange={(e) => setEditedTask({ ...editedTask, assignee: e?.target?.value })}
              placeholder="Enter assignee name"
            />
          ) : task?.assignee ? (
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-sm text-primary-foreground font-medium">
                  {task?.assignee?.charAt(0)?.toUpperCase()}
                </span>
              </div>
              <span className="text-foreground">{task?.assignee}</span>
            </div>
          ) : (
            <span className="text-muted-foreground">Unassigned</span>
          )}
        </div>

        {/* Progress */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Progress</label>
          {isEditing ? (
            <Input
              type="number"
              min="0"
              max="100"
              value={editedTask?.progress || '0'}
              onChange={(e) => setEditedTask({ ...editedTask, progress: parseInt(e?.target?.value) || 0 })}
            />
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Completion</span>
                <span className="text-foreground font-medium">{task?.progress || 0}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${task?.progress || 0}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Requirements */}
        {task?.requirements && task?.requirements?.length > 0 && (
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Requirements</label>
            <ul className="space-y-2">
              {task?.requirements?.map((req, index) => (
                <li key={index} className="flex items-start space-x-2 text-sm">
                  <Icon name="CheckCircle2" size={14} className="mt-0.5 text-success flex-shrink-0" />
                  <span className="text-muted-foreground">{req}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Dependencies */}
        {getDependencyTasks()?.length > 0 && (
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Dependencies</label>
            <div className="space-y-2">
              {getDependencyTasks()?.map((depTask) => (
                <div key={depTask?.id} className="flex items-center space-x-2 p-2 bg-muted rounded-md">
                  <Icon name="ArrowRight" size={14} className="text-muted-foreground" />
                  <span className="text-sm text-foreground">{depTask?.title}</span>
                  <span className={`
                    ml-auto px-2 py-1 rounded-full text-xs
                    ${depTask?.status === 'completed' ? 'bg-success/10 text-success' :
                      'bg-warning/10 text-warning'}
                  `}>
                    {depTask?.status || 'pending'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Dependent Tasks */}
        {getDependentTasks()?.length > 0 && (
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Blocks These Tasks</label>
            <div className="space-y-2">
              {getDependentTasks()?.map((depTask) => (
                <div key={depTask?.id} className="flex items-center space-x-2 p-2 bg-muted rounded-md">
                  <Icon name="ArrowLeft" size={14} className="text-muted-foreground" />
                  <span className="text-sm text-foreground">{depTask?.title}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      {/* Panel Footer */}
      <div className="p-4 border-t border-border bg-muted/30">
        {isEditing ? (
          <div className="flex space-x-2">
            <Button
              variant="default"
              size="sm"
              fullWidth
              iconName="Save"
              onClick={handleSave}
              disabled={!editedTask?.title?.trim()}
            >
              Apply Changes
            </Button>
            <Button
              variant="outline"
              size="sm"
              fullWidth
              iconName="X"
              onClick={handleCancel}
            >
              Cancel
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            <Button
              variant="default"
              size="sm"
              fullWidth
              iconName="Edit3"
              onClick={() => setIsEditing(true)}
            >
              Edit Task
            </Button>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                fullWidth
                iconName="Copy"
                onClick={() => {
                  const newTask = {
                    ...task,
                    id: `task-${Date.now()}`,
                    title: `${task.title} (Copy)`,
                    status: 'pending',
                    progress: 0
                  };
                  onTaskUpdate(newTask);
                }}
              >
                Duplicate
              </Button>
              <Button
                variant="outline"
                size="sm"
                fullWidth
                iconName="Trash2"
                onClick={() => {
                  if (confirm('Are you sure you want to delete this task?')) {
                    onTaskUpdate({ ...task, deleted: true });
                    onClose();
                  }
                }}
              >
                Delete
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskDetailsPanel;