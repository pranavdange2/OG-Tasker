import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TimelineView = ({ 
  tasks = [], 
  onTaskSelect = () => {},
  onTaskUpdate = () => {},
  selectedTask = null,
  zoomLevel = 'week',
  onZoomChange = () => {}
}) => {
  const [hoveredTask, setHoveredTask] = useState(null);
  const [editingTask, setEditingTask] = useState(null);
  const [editedValues, setEditedValues] = useState({});

  const zoomLevels = [
    { id: 'week', label: 'Week' },
    { id: 'month', label: 'Month' },
    { id: 'quarter', label: 'Quarter' }
  ];

  const generateTimeLabels = () => {
    const labels = [];
    const startDate = new Date();
    
    for (let i = 0; i < 12; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + (i * 7));
      
      labels.push({
        label: zoomLevel === 'week' 
          ? `Week ${i + 1}` 
          : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        position: (i / 12) * 100
      });
    }
    
    return labels;
  };

  const getTaskColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-500 text-white';
      case 'medium': return 'bg-yellow-500 text-white';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-blue-500 text-white';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 border-green-300';
      case 'in-progress': return 'bg-blue-100 border-blue-300';
      case 'pending': return 'bg-gray-100 border-gray-300';
      default: return 'bg-gray-100 border-gray-300';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Timeline View</h3>
        <div className="flex items-center space-x-2">
          {zoomLevels.map((zoom) => (
            <Button
              key={zoom.id}
              variant={zoomLevel === zoom.id ? "default" : "ghost"}
              size="sm"
              onClick={() => onZoomChange(zoom.id)}
            >
              {zoom.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Time Labels */}
      <div className="relative h-10 bg-gray-50 border-b border-gray-200">
        {generateTimeLabels().map((label, index) => (
          <div
            key={index}
            className="absolute top-0 h-full flex items-center px-3 text-xs font-medium text-gray-600"
            style={{ left: `${label.position}%` }}
          >
            {label.label}
          </div>
        ))}
      </div>

      {/* Timeline Content */}
      <div className="relative p-4" style={{ minHeight: '400px' }}>
        {/* Grid Lines */}
        {generateTimeLabels().map((label, index) => (
          <div
            key={index}
            className="absolute top-0 bottom-0 w-px bg-gray-200"
            style={{ left: `${label.position + 4}%` }}
          />
        ))}

        {/* Tasks */}
        <div className="space-y-3">
          {tasks.map((task, index) => (
            <div key={task.id} className="relative">
              {/* Task Row */}
              <div className="flex items-center h-12">
                {/* Task Info */}
                <div className="w-64 pr-4 flex-shrink-0">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={task.icon || 'Circle'} 
                      size={16} 
                      className="text-gray-400" 
                    />
                    <div>
                      <div className="text-sm font-medium text-gray-900 truncate">
                        {task.title}
                      </div>
                      <div className="text-xs text-gray-500">
                        {task.assignee || 'Unassigned'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Timeline Bar */}
                <div className="flex-1 relative h-8">
                  <div
                    className={`
                      absolute h-6 rounded-md cursor-pointer transition-all duration-200
                      ${getStatusColor(task.status)}
                      ${selectedTask?.id === task.id ? 'ring-2 ring-blue-500' : ''}
                      ${hoveredTask === task.id ? 'shadow-md' : ''}
                    `}
                    style={{
                      left: `${(task.position || index * 8) % 80}%`,
                      width: `${Math.min(task.duration || 15, 25)}%`,
                      top: '1px'
                    }}
                    onClick={() => {
                      onTaskSelect(task);
                      setEditingTask(task.id);
                      setEditedValues({
                        title: task.title,
                        status: task.status,
                        priority: task.priority,
                        progress: task.progress || 0
                      });
                    }}
                    onMouseEnter={() => setHoveredTask(task.id)}
                    onMouseLeave={() => setHoveredTask(null)}
                  >
                    <div className="flex items-center h-full px-2">
                      <div className={`
                        w-2 h-2 rounded-full mr-2
                        ${getTaskColor(task.priority)}
                      `} />
                      <span className="text-xs font-medium text-gray-700 truncate">
                        {task.title}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  {task.progress > 0 && (
                    <div
                      className="absolute h-1 bg-blue-500 rounded-full"
                      style={{
                        left: `${(task.position || index * 8) % 80}%`,
                        width: `${((task.duration || 15) * (task.progress / 100))}%`,
                        bottom: '-2px'
                      }}
                    />
                  )}
                </div>

                {/* Task Status */}
                <div className="w-32 text-right flex-shrink-0">
                  {editingTask === task.id ? (
                    <select
                      className="text-xs px-2 py-1 border border-gray-300 rounded"
                      value={editedValues.status || task.status}
                      onChange={(e) => setEditedValues({...editedValues, status: e.target.value})}
                    >
                      <option value="pending">Pending</option>
                      <option value="in-progress">In Progress</option>
                      <option value="completed">Completed</option>
                    </select>
                  ) : (
                    <span className={`
                      inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                      ${task.status === 'completed' ? 'bg-green-100 text-green-800' :
                        task.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'}
                    `}>
                      {task.status || 'pending'}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Current Date Line */}
        <div 
          className="absolute top-0 bottom-0 w-0.5 bg-red-500 opacity-60"
          style={{ left: '20%' }}
        >
          <div className="absolute -top-1 -left-1 w-3 h-3 bg-red-500 rounded-full" />
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between p-4 border-t border-gray-200 bg-gray-50">
        <div className="flex items-center space-x-4 text-sm text-gray-600">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-red-500 rounded-full" />
            <span>High</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-yellow-500 rounded-full" />
            <span>Medium</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-green-500 rounded-full" />
            <span>Low</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          {editingTask && (
            <>
              <Button
                variant="default"
                size="sm"
                onClick={() => {
                  const taskToUpdate = tasks.find(t => t.id === editingTask);
                  if (taskToUpdate) {
                    onTaskUpdate({
                      ...taskToUpdate,
                      ...editedValues
                    });
                  }
                  setEditingTask(null);
                  setEditedValues({});
                }}
              >
                Apply
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setEditingTask(null);
                  setEditedValues({});
                }}
              >
                Cancel
              </Button>
            </>
          )}
          <div className="text-sm text-gray-600">
            {tasks.length} tasks • {tasks.filter(t => t.status === 'completed').length} completed
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimelineView;