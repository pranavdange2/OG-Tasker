import React, { useState, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ListView = ({ 
  tasks = [], 
  onTaskUpdate = () => {}, 
  onTaskSelect = () => {},
  selectedTask = null 
}) => {
  const [sortConfig, setSortConfig] = useState({ key: 'title', direction: 'asc' });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTasks, setSelectedTasks] = useState(new Set());

  const columns = [
    { key: 'title', label: 'Task Name', sortable: true, width: 'w-1/4' },
    { key: 'priority', label: 'Priority', sortable: true, width: 'w-20' },
    { key: 'status', label: 'Status', sortable: true, width: 'w-24' },
    { key: 'assignee', label: 'Assignee', sortable: true, width: 'w-32' },
    { key: 'estimatedTime', label: 'Duration', sortable: true, width: 'w-20' },
    { key: 'cost', label: 'Cost', sortable: true, width: 'w-20' },
    { key: 'progress', label: 'Progress', sortable: true, width: 'w-24' },
    { key: 'actions', label: 'Actions', sortable: false, width: 'w-32' }
  ];

  const filteredAndSortedTasks = useMemo(() => {
    let filtered = tasks?.filter(task =>
      task?.title?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
      task?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
      task?.assignee?.toLowerCase()?.includes(searchTerm?.toLowerCase())
    );

    if (sortConfig?.key) {
      filtered?.sort((a, b) => {
        let aValue = a?.[sortConfig?.key];
        let bValue = b?.[sortConfig?.key];

        // Handle special cases
        if (sortConfig?.key === 'cost') {
          aValue = parseFloat(aValue) || 0;
          bValue = parseFloat(bValue) || 0;
        } else if (sortConfig?.key === 'progress') {
          aValue = parseInt(aValue) || 0;
          bValue = parseInt(bValue) || 0;
        } else if (sortConfig?.key === 'priority') {
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          aValue = priorityOrder?.[aValue] || 0;
          bValue = priorityOrder?.[bValue] || 0;
        }

        if (aValue < bValue) return sortConfig?.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig?.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [tasks, searchTerm, sortConfig]);

  const handleSort = (key) => {
    setSortConfig(prevConfig => ({
      key,
      direction: prevConfig?.key === key && prevConfig?.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleTaskSelection = (taskId) => {
    const newSelected = new Set(selectedTasks);
    if (newSelected?.has(taskId)) {
      newSelected?.delete(taskId);
    } else {
      newSelected?.add(taskId);
    }
    setSelectedTasks(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedTasks?.size === filteredAndSortedTasks?.length) {
      setSelectedTasks(new Set());
    } else {
      setSelectedTasks(new Set(filteredAndSortedTasks.map(task => task.id)));
    }
  };

  const PriorityBadge = ({ priority }) => (
    <span className={`
      inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
      ${priority === 'high' ? 'bg-error/10 text-error' :
        priority === 'medium' ? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'}
    `}>
      {priority || 'low'}
    </span>
  );

  const StatusBadge = ({ status }) => (
    <span className={`
      inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
      ${status === 'completed' ? 'bg-success/10 text-success' :
        status === 'in-progress' ? 'bg-warning/10 text-warning' : 'bg-muted text-muted-foreground'}
    `}>
      {status || 'pending'}
    </span>
  );

  const ProgressBar = ({ progress }) => (
    <div className="w-full">
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="text-muted-foreground">{progress || 0}%</span>
      </div>
      <div className="w-full bg-muted rounded-full h-2">
        <div
          className="bg-primary h-2 rounded-full transition-all duration-300"
          style={{ width: `${progress || 0}%` }}
        />
      </div>
    </div>
  );

  const TableHeader = ({ column }) => (
    <th className={`px-4 py-3 text-left ${column?.width}`}>
      {column?.sortable ? (
        <button
          onClick={() => handleSort(column?.key)}
          className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors duration-200"
        >
          <span>{column?.label}</span>
          {sortConfig?.key === column?.key && (
            <Icon 
              name={sortConfig?.direction === 'asc' ? 'ChevronUp' : 'ChevronDown'} 
              size={14} 
            />
          )}
        </button>
      ) : (
        <span className="text-sm font-medium text-muted-foreground">{column?.label}</span>
      )}
    </th>
  );

  const TaskRow = ({ task }) => {
    const isSelected = selectedTasks?.has(task?.id);
    const isHighlighted = selectedTask?.id === task?.id;

    return (
      <tr
        className={`
          border-b border-border hover:bg-muted/50 cursor-pointer transition-colors duration-200
          ${isHighlighted ? 'bg-primary/5 border-primary/20' : ''}
        `}
        onClick={() => onTaskSelect(task)}
      >
        <td className="px-4 py-3">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={(e) => {
                e?.stopPropagation();
                handleTaskSelection(task?.id);
              }}
              className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary focus:ring-2"
            />
            <div className="flex items-center space-x-2">
              <div className={`
                w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0
                ${task?.priority === 'high' ? 'bg-error/10 text-error' :
                  task?.priority === 'medium' ? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'}
              `}>
                <Icon name={task?.icon || 'Circle'} size={14} />
              </div>
              <div>
                <div className="font-medium text-foreground">{task?.title}</div>
                <div className="text-sm text-muted-foreground truncate max-w-xs">
                  {task?.description}
                </div>
              </div>
            </div>
          </div>
        </td>
        <td className="px-4 py-3">
          <PriorityBadge priority={task?.priority} />
        </td>
        <td className="px-4 py-3">
          <StatusBadge status={task?.status} />
        </td>
        <td className="px-4 py-3">
          <div className="flex items-center space-x-2">
            {task?.assignee ? (
              <>
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-xs text-primary-foreground font-medium">
                    {task?.assignee?.charAt(0)?.toUpperCase()}
                  </span>
                </div>
                <span className="text-sm text-foreground">{task?.assignee}</span>
              </>
            ) : (
              <span className="text-sm text-muted-foreground">Unassigned</span>
            )}
          </div>
        </td>
        <td className="px-4 py-3">
          <span className="text-sm text-foreground">{task?.estimatedTime || '2h'}</span>
        </td>
        <td className="px-4 py-3">
          <span className="text-sm text-foreground">${task?.cost || '0'}</span>
        </td>
        <td className="px-4 py-3">
          <ProgressBar progress={task?.progress} />
        </td>
        <td className="px-4 py-3">
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              size="sm"
              iconName="Edit3"
              onClick={(e) => {
                e?.stopPropagation();
                // Handle edit
              }}
            />
            <Button
              variant="ghost"
              size="sm"
              iconName="MoreHorizontal"
              onClick={(e) => {
                e?.stopPropagation();
                // Handle more actions
              }}
            />
          </div>
        </td>
      </tr>
    );
  };

  return (
    <div className="bg-card rounded-lg border border-border">
      {/* List Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-4">
          <h3 className="text-lg font-semibold text-foreground">Task List</h3>
          <span className="text-sm text-muted-foreground">
            {filteredAndSortedTasks?.length} of {tasks?.length} tasks
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <Input
            type="search"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-64"
          />
          <Button variant="ghost" size="sm" iconName="Filter">
            Filter
          </Button>
          <Button variant="ghost" size="sm" iconName="Download">
            Export
          </Button>
        </div>
      </div>
      {/* Bulk Actions */}
      {selectedTasks?.size > 0 && (
        <div className="flex items-center justify-between p-4 bg-primary/5 border-b border-border">
          <span className="text-sm text-foreground">
            {selectedTasks?.size} task{selectedTasks?.size !== 1 ? 's' : ''} selected
          </span>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" iconName="Edit3">
              Bulk Edit
            </Button>
            <Button variant="ghost" size="sm" iconName="Trash2">
              Delete
            </Button>
            <Button variant="ghost" size="sm" iconName="X" onClick={() => setSelectedTasks(new Set())}>
              Clear
            </Button>
          </div>
        </div>
      )}
      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/30">
            <tr>
              <th className="px-4 py-3 text-left w-1/4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={selectedTasks?.size === filteredAndSortedTasks?.length && filteredAndSortedTasks?.length > 0}
                    onChange={handleSelectAll}
                    className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary focus:ring-2"
                  />
                  <button
                    onClick={() => handleSort('title')}
                    className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors duration-200"
                  >
                    <span>Task Name</span>
                    {sortConfig?.key === 'title' && (
                      <Icon 
                        name={sortConfig?.direction === 'asc' ? 'ChevronUp' : 'ChevronDown'} 
                        size={14} 
                      />
                    )}
                  </button>
                </div>
              </th>
              {columns?.slice(1)?.map((column) => (
                <TableHeader key={column?.key} column={column} />
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredAndSortedTasks?.map((task) => (
              <TaskRow key={task?.id} task={task} />
            ))}
          </tbody>
        </table>
      </div>
      {/* Empty State */}
      {filteredAndSortedTasks?.length === 0 && (
        <div className="text-center py-12">
          <Icon name="Search" size={48} className="mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No Tasks Found</h3>
          <p className="text-muted-foreground">
            {searchTerm ? 'Try adjusting your search criteria.' : 'No tasks available to display.'}
          </p>
        </div>
      )}
      {/* Table Footer */}
      <div className="flex items-center justify-between p-4 border-t border-border bg-muted/30">
        <div className="text-sm text-muted-foreground">
          Showing {filteredAndSortedTasks?.length} of {tasks?.length} tasks
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" iconName="ChevronLeft" disabled>
            Previous
          </Button>
          <Button variant="ghost" size="sm" iconName="ChevronRight" disabled>
            Next
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ListView;