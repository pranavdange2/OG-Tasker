import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const FilterSidebar = ({ 
  isOpen = true, 
  onToggle = () => {}, 
  filters = {}, 
  onFiltersChange = () => {},
  tasks = []
}) => {
  const [localFilters, setLocalFilters] = useState({
    dateRange: { start: '', end: '' },
    priorities: [],
    statuses: [],
    categories: [],
    assignees: [],
    costRange: { min: '', max: '' },
    ...filters
  });

  const priorities = ['high', 'medium', 'low'];
  const statuses = ['pending', 'in-progress', 'completed', 'on-hold'];
  
  // Extract unique values from tasks
  const categories = [...new Set(tasks.map(task => task.category).filter(Boolean))];
  const assignees = [...new Set(tasks.map(task => task.assignee).filter(Boolean))];

  const handleFilterChange = (filterType, value, checked = null) => {
    let newFilters = { ...localFilters };
    
    if (filterType === 'dateRange' || filterType === 'costRange') {
      newFilters[filterType] = { ...newFilters?.[filterType], ...value };
    } else if (Array.isArray(newFilters?.[filterType])) {
      if (checked) {
        newFilters[filterType] = [...newFilters?.[filterType], value];
      } else {
        newFilters[filterType] = newFilters?.[filterType]?.filter(item => item !== value);
      }
    }
    
    setLocalFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearAllFilters = () => {
    const clearedFilters = {
      dateRange: { start: '', end: '' },
      priorities: [],
      statuses: [],
      categories: [],
      assignees: [],
      costRange: { min: '', max: '' }
    };
    setLocalFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (localFilters?.dateRange?.start || localFilters?.dateRange?.end) count++;
    if (localFilters?.priorities?.length > 0) count++;
    if (localFilters?.statuses?.length > 0) count++;
    if (localFilters?.categories?.length > 0) count++;
    if (localFilters?.assignees?.length > 0) count++;
    if (localFilters?.costRange?.min || localFilters?.costRange?.max) count++;
    return count;
  };

  const FilterSection = ({ title, children, isCollapsible = true }) => {
    const [isExpanded, setIsExpanded] = useState(true);
    
    return (
      <div className="border-b border-border pb-4 mb-4 last:border-b-0 last:pb-0 last:mb-0">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-medium text-foreground">{title}</h4>
          {isCollapsible && (
            <Button
              variant="ghost"
              size="sm"
              iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
              onClick={() => setIsExpanded(!isExpanded)}
            />
          )}
        </div>
        {isExpanded && children}
      </div>
    );
  };

  const CheckboxGroup = ({ items, selectedItems, filterType, getDisplayName = (item) => item }) => (
    <div className="space-y-2">
      {items?.map((item) => (
        <Checkbox
          key={item}
          label={getDisplayName(item)}
          checked={selectedItems?.includes(item)}
          onChange={(e) => handleFilterChange(filterType, item, e?.target?.checked)}
        />
      ))}
    </div>
  );

  if (!isOpen) {
    return (
      <div className="w-12 bg-card border-r border-border flex flex-col items-center py-4">
        <Button
          variant="ghost"
          size="sm"
          iconName="SlidersHorizontal"
          onClick={onToggle}
          className="rotate-90"
        />
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-r border-border flex flex-col">
      {/* Sidebar Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="SlidersHorizontal" size={20} className="text-primary" />
          <h3 className="font-semibold text-foreground">Filters</h3>
          {getActiveFilterCount() > 0 && (
            <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
              {getActiveFilterCount()}
            </span>
          )}
        </div>
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAllFilters}
            disabled={getActiveFilterCount() === 0}
          >
            Clear
          </Button>
          <Button
            variant="ghost"
            size="sm"
            iconName="X"
            onClick={onToggle}
          />
        </div>
      </div>
      {/* Filter Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Date Range Filter */}
        <FilterSection title="Date Range">
          <div className="space-y-3">
            <Input
              label="Start Date"
              type="date"
              value={localFilters?.dateRange?.start}
              onChange={(e) => handleFilterChange('dateRange', { start: e?.target?.value })}
            />
            <Input
              label="End Date"
              type="date"
              value={localFilters?.dateRange?.end}
              onChange={(e) => handleFilterChange('dateRange', { end: e?.target?.value })}
            />
          </div>
        </FilterSection>

        {/* Priority Filter */}
        <FilterSection title="Priority">
          <CheckboxGroup
            items={priorities}
            selectedItems={localFilters?.priorities}
            filterType="priorities"
            getDisplayName={(priority) => priority?.charAt(0)?.toUpperCase() + priority?.slice(1)}
          />
        </FilterSection>

        {/* Status Filter */}
        <FilterSection title="Status">
          <CheckboxGroup
            items={statuses}
            selectedItems={localFilters?.statuses}
            filterType="statuses"
            getDisplayName={(status) => status?.split('-')?.map(word => 
              word?.charAt(0)?.toUpperCase() + word?.slice(1)
            )?.join(' ')}
          />
        </FilterSection>

        {/* Category Filter */}
        {categories?.length > 0 && (
          <FilterSection title="Category">
            <CheckboxGroup
              items={categories}
              selectedItems={localFilters?.categories}
              filterType="categories"
              getDisplayName={(category) => category?.charAt(0)?.toUpperCase() + category?.slice(1)}
            />
          </FilterSection>
        )}

        {/* Assignee Filter */}
        {assignees?.length > 0 && (
          <FilterSection title="Assignee">
            <CheckboxGroup
              items={assignees}
              selectedItems={localFilters?.assignees}
              filterType="assignees"
            />
          </FilterSection>
        )}

        {/* Cost Range Filter */}
        <FilterSection title="Cost Range">
          <div className="space-y-3">
            <Input
              label="Minimum Cost"
              type="number"
              placeholder="$0"
              value={localFilters?.costRange?.min}
              onChange={(e) => handleFilterChange('costRange', { min: e?.target?.value })}
            />
            <Input
              label="Maximum Cost"
              type="number"
              placeholder="$1000"
              value={localFilters?.costRange?.max}
              onChange={(e) => handleFilterChange('costRange', { max: e?.target?.value })}
            />
          </div>
        </FilterSection>
      </div>
      {/* Sidebar Footer */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="text-sm text-muted-foreground mb-3">
          {tasks?.length} total tasks
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            fullWidth
            onClick={clearAllFilters}
            disabled={getActiveFilterCount() === 0}
          >
            Reset All
          </Button>
          <Button
            variant="default"
            size="sm"
            fullWidth
            iconName="Search"
          >
            Apply
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;