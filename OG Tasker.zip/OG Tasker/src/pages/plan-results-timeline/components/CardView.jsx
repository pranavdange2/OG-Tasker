import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CardView = ({ 
  tasks = [], 
  onTaskUpdate = () => {}, 
  onTaskSelect = () => {},
  selectedTask = null,
  groupBy = 'priority'
}) => {
  const [expandedCards, setExpandedCards] = useState(new Set());

  const toggleCardExpansion = (taskId) => {
    const newExpanded = new Set(expandedCards);
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId);
    } else {
      newExpanded.add(taskId);
    }
    setExpandedCards(newExpanded);
  };

  const handleMarkComplete = (task, e) => {
    e.stopPropagation();
    
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    const newProgress = task.status === 'completed' ? 0 : 100;
    
    onTaskUpdate({
      ...task,
      status: newStatus,
      progress: newProgress
    });
  };

  const groupTasks = () => {
    const groups = {};
    
    tasks.forEach(task => {
      let groupKey;
      switch (groupBy) {
        case 'priority':
          groupKey = task.priority || 'low';
          break;
        case 'status':
          groupKey = task.status || 'pending';
          break;
        case 'category':
          groupKey = task.category || 'general';
          break;
        case 'assignee':
          groupKey = task.assignee || 'unassigned';
          break;
        default:
          groupKey = 'all';
      }
      
      if (!groups[groupKey]) {
        groups[groupKey] = [];
      }
      groups[groupKey].push(task);
    });
    
    return groups;
  };

  const getGroupTitle = (groupKey) => {
    switch (groupBy) {
      case 'priority':
        return groupKey.charAt(0).toUpperCase() + groupKey.slice(1) + ' Priority';
      case 'status':
        return groupKey.charAt(0).toUpperCase() + groupKey.slice(1);
      case 'category':
        return groupKey.charAt(0).toUpperCase() + groupKey.slice(1);
      case 'assignee':
        return groupKey === 'unassigned' ? 'Unassigned' : groupKey;
      default:
        return 'All Tasks';
    }
  };

  const TaskCard = ({ task }) => {
    const isSelected = selectedTask?.id === task?.id;
    const isExpanded = expandedCards.has(task.id);
    
    return (
      <div
        className={`bg-white border rounded-lg p-4 cursor-pointer transition-all duration-200 hover:shadow-md ${
          isSelected ? 'ring-2 ring-blue-500' : 'border-gray-200'
        }`}
        onClick={() => onTaskSelect(task)}
      >
        {/* Card Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-start space-x-3 flex-1">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
              task.priority === 'high' ? 'bg-red-100 text-red-600' : 
              task.priority === 'medium' ? 'bg-yellow-100 text-yellow-600' : 
              'bg-green-100 text-green-600'
            }`}>
              <Icon name={task.icon || 'Circle'} size={20} />
            </div>
            
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-gray-900 truncate">{task.title}</h4>
              <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                {task.description}
              </p>
            </div>
          </div>
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleCardExpansion(task.id);
            }}
            className="p-1 hover:bg-gray-100 rounded"
          >
            <Icon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={16} />
          </button>
        </div>

        {/* Card Metadata */}
        <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Icon name="Clock" size={12} />
              <span>{task.estimatedTime || '2h'}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="DollarSign" size={12} />
              <span>${task.cost || '0'}</span>
            </div>
            {task.assignee && (
              <div className="flex items-center space-x-1">
                <Icon name="User" size={12} />
                <span>{task.assignee}</span>
              </div>
            )}
          </div>
          
          <div className={`px-2 py-1 rounded-full text-xs font-medium ${
            task.status === 'completed' ? 'bg-green-100 text-green-800' :
            task.status === 'in-progress' ? 'bg-blue-100 text-blue-800' : 
            'bg-gray-100 text-gray-800'
          }`}>
            {task.status || 'pending'}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
            <span>Progress</span>
            <span>{task.progress || 0}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${
                task.status === 'completed' ? 'bg-green-500' :
                task.status === 'in-progress' ? 'bg-blue-500' : 'bg-gray-400'
              }`}
              style={{ width: `${task.progress || 0}%` }}
            />
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end">
          <button
            onClick={(e) => handleMarkComplete(task, e)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              task.status === 'completed' 
                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' 
                : 'bg-blue-500 text-white hover:bg-blue-600'
            }`}
          >
            {task.status === 'completed' ? 'Mark Pending' : 'Mark Complete'}
          </button>
        </div>

        {/* Expanded Content */}
        {isExpanded && (
          <div className="border-t border-gray-200 pt-3 mt-3 space-y-3">
            {task.requirements && (
              <div>
                <h5 className="text-sm font-medium text-gray-900 mb-1">Requirements</h5>
                <ul className="text-sm text-gray-600 space-y-1">
                  {task.requirements.map((req, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <Icon name="CheckCircle2" size={12} className="mt-0.5 flex-shrink-0" />
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  const groupedTasks = groupTasks();

  return (
    <div className="space-y-6">
      {Object.entries(groupedTasks).map(([groupKey, groupTasks]) => (
        <div key={groupKey} className="space-y-4">
          <div className="border-l-4 border-blue-500 pl-4">
            <h3 className="text-lg font-semibold text-gray-900">
              {getGroupTitle(groupKey)}
            </h3>
            <p className="text-sm text-gray-600">
              {groupTasks.length} task{groupTasks.length !== 1 ? 's' : ''}
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {groupTasks.map((task) => (
              <TaskCard key={task.id} task={task} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default CardView;