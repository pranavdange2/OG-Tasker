import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import ProgressBreadcrumb from '../../components/ui/ProgressBreadcrumb';
import WorkflowNavigationTabs from '../../components/ui/WorkflowNavigationTabs';
import ComparisonModeToggle from '../../components/ui/ComparisonModeToggle';
import Button from '../../components/ui/Button';


// Import components
import TimelineView from './components/TimelineView';
import CardView from './components/CardView';
import ListView from './components/ListView';
import FilterSidebar from './components/FilterSidebar';
import TaskDetailsPanel from './components/TaskDetailsPanel';
import PlanMetadata from './components/PlanMetadata';

const PlanResultsTimeline = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeView, setActiveView] = useState('timeline');
  const [isComparisonMode, setIsComparisonMode] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [isFilterSidebarOpen, setIsFilterSidebarOpen] = useState(true);
  const [isDetailsPanelOpen, setIsDetailsPanelOpen] = useState(false);
  const [filters, setFilters] = useState({});
  const [zoomLevel, setZoomLevel] = useState('week');
  const [cardGroupBy, setCardGroupBy] = useState('priority');


  // Get plan data from navigation state or use fallback
  const generatedPlan = location?.state?.generatedPlan;
  const taskData = location?.state?.taskData;
  
  const planData = generatedPlan || {
    title: taskData?.goalTitle || "Generated Plan",
    summary: "AI-generated comprehensive plan",
    phases: [],
    totalBudget: taskData?.budget || 5000,
    totalDuration: 30
  };
  
  const mockPlan = {
    id: "plan-001",
    title: planData?.title,
    description: planData?.summary,
    duration: `${planData?.totalDuration} days`,
    budget: planData?.totalBudget?.toString(),
    location: taskData?.location || "Not specified",
    createdAt: new Date().toLocaleDateString(),
    status: "generated"
  };

  // Convert plan phases to tasks or use mock data
  const convertPlanToTasks = (plan) => {
    if (!plan?.phases || plan.phases.length === 0) {
      return mockTasksData;
    }
    
    const tasks = [];
    let taskId = 1;
    
    plan.phases.forEach((phase, phaseIndex) => {
      // Add phase as a milestone
      tasks.push({
        id: `milestone-${phaseIndex + 1}`,
        title: phase.title,
        description: phase.description,
        type: "milestone",
        status: "pending",
        position: phaseIndex * 20 + 10,
        icon: "Flag",
        category: "milestone"
      });
      
      // Add phase tasks
      if (phase.tasks) {
        phase.tasks.forEach((task, taskIndex) => {
          tasks.push({
            id: `task-${taskId++}`,
            title: task.title,
            description: task.description,
            priority: task.priority || "medium",
            status: "pending",
            assignee: "Team Member",
            estimatedTime: `${task.estimatedTime || 8}h`,
            cost: Math.floor(phase.budget / (phase.tasks?.length || 1)).toString(),
            progress: 0,
            position: phaseIndex * 20 + taskIndex * 5 + 15,
            duration: task.estimatedTime || 8,
            icon: "CheckSquare",
            category: "task",
            requirements: [task.description],
            dependencies: task.dependencies || []
          });
        });
      }
    });
    
    return tasks;
  };
  
  const mockTasksData = [
    {
      id: "task-001",
      title: "Venue Research & Booking",
      description: "Research and book suitable venue for 500+ attendees with AV capabilities and catering facilities.",
      priority: "high",
      status: "completed",
      assignee: "Sarah Johnson",
      estimatedTime: "16h",
      cost: "8000",
      progress: 100,
      position: 5,
      duration: 12,
      icon: "MapPin",
      category: "logistics",
      requirements: [
        "Capacity for 500+ people",
        "Professional AV equipment",
        "Catering kitchen facilities",
        "Parking availability"
      ],
      dependencies: []
    },
    {
      id: "task-002",
      title: "Keynote Speaker Coordination",
      description: "Identify, contact, and confirm keynote speakers for the main conference sessions.",
      priority: "high",
      status: "in-progress",
      assignee: "Michael Chen",
      estimatedTime: "24h",
      cost: "5000",
      progress: 65,
      position: 20,
      duration: 18,
      icon: "Mic",
      category: "content",
      requirements: [
        "Industry expertise verification",
        "Speaker availability confirmation",
        "Contract negotiation",
        "Travel arrangement coordination"
      ],
      dependencies: ["task-001"]
    },
    {
      id: "task-003",
      title: "Marketing & Promotion Campaign",
      description: "Develop and execute comprehensive marketing strategy including social media, email campaigns, and promotional materials.",
      priority: "medium",
      status: "pending",
      assignee: "Emily Rodriguez",
      estimatedTime: "32h",
      cost: "3500",
      progress: 0,
      position: 35,
      duration: 25,
      icon: "Megaphone",
      category: "marketing",
      requirements: [
        "Brand guideline compliance",
        "Multi-channel campaign strategy",
        "Content creation and approval",
        "Performance tracking setup"
      ],
      dependencies: ["task-002"]
    },
    {
      id: "task-004",
      title: "Registration System Setup",
      description: "Configure online registration platform with payment processing and attendee management features.",
      priority: "high",
      status: "in-progress",
      assignee: "David Kim",
      estimatedTime: "20h",
      cost: "1200",
      progress: 40,
      position: 15,
      duration: 15,
      icon: "UserPlus",
      category: "technology",
      requirements: [
        "Payment gateway integration",
        "Attendee data management",
        "Confirmation email automation",
        "Mobile-responsive design"
      ],
      dependencies: []
    },
    {
      id: "task-005",
      title: "Catering Menu Planning",
      description: "Plan and coordinate catering services including dietary restrictions, menu selection, and service logistics.",
      priority: "medium",
      status: "pending",
      assignee: "Lisa Thompson",
      estimatedTime: "12h",
      cost: "4500",
      progress: 0,
      position: 45,
      duration: 10,
      icon: "Coffee",
      category: "logistics",
      requirements: [
        "Dietary restriction accommodation",
        "Menu variety and quality",
        "Service timing coordination",
        "Equipment and setup requirements"
      ],
      dependencies: ["task-001"]
    },
    {
      id: "task-006",
      title: "Audio/Visual Equipment Setup",
      description: "Coordinate AV equipment rental, setup, and technical support for all conference sessions.",
      priority: "high",
      status: "pending",
      assignee: "Robert Wilson",
      estimatedTime: "18h",
      cost: "2800",
      progress: 0,
      position: 55,
      duration: 8,
      icon: "Monitor",
      category: "technology",
      requirements: [
        "Professional sound system",
        "Projection and display equipment",
        "Live streaming capabilities",
        "Technical support staff"
      ],
      dependencies: ["task-001", "task-002"]
    },
    {
      id: "milestone-001",
      title: "Venue Confirmed",
      description: "Venue booking completed and contracts signed",
      type: "milestone",
      status: "completed",
      position: 17,
      icon: "Flag",
      dependencies: ["task-001"]
    },
    {
      id: "milestone-002",
      title: "Speaker Lineup Finalized",
      description: "All keynote speakers confirmed and scheduled",
      type: "milestone",
      status: "pending",
      position: 38,
      icon: "Flag",
      dependencies: ["task-002"]
    }
  ];

  const [tasks, setTasks] = useState(() => convertPlanToTasks(planData));

  useEffect(() => {
    // Set initial selected task if none selected
    if (!selectedTask && tasks?.length > 0) {
      setSelectedTask(tasks?.[0]);
      setIsDetailsPanelOpen(true);
    }
  }, [tasks, selectedTask]);

  const handleTaskUpdate = (updatedTask) => {
    if (!updatedTask || !updatedTask.id) {
      console.error('Invalid task update:', updatedTask);
      return;
    }

    // Handle task deletion
    if (updatedTask.deleted) {
      setTasks(prevTasks => prevTasks.filter(task => task.id !== updatedTask.id));
      if (selectedTask?.id === updatedTask.id) {
        setSelectedTask(null);
        setIsDetailsPanelOpen(false);
      }
      return;
    }

    // Handle task update or creation
    setTasks(prevTasks => {
      const existingTaskIndex = prevTasks.findIndex(task => task.id === updatedTask.id);
      if (existingTaskIndex >= 0) {
        // Update existing task
        const newTasks = [...prevTasks];
        newTasks[existingTaskIndex] = { ...prevTasks[existingTaskIndex], ...updatedTask };
        return newTasks;
      } else {
        // Add new task (for duplication)
        return [...prevTasks, updatedTask];
      }
    });
    
    // Update selected task if it's the same one being updated
    if (selectedTask?.id === updatedTask.id) {
      setSelectedTask(updatedTask);
    }

    console.log('Task updated successfully:', updatedTask.title);
  };

  const handleTaskSelect = (task) => {
    setSelectedTask(task);
    setIsDetailsPanelOpen(true);
  };

  const handleExport = (format = 'pdf') => {
    const planContent = {
      title: planData.title,
      summary: planData.summary,
      budget: planData.totalBudget,
      duration: planData.totalDuration,
      phases: planData.phases,
      tasks: tasks,
      createdAt: new Date().toISOString()
    };

    if (format === 'json') {
      const dataStr = JSON.stringify(planContent, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${planData.title.replace(/\s+/g, '_')}_plan.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } else if (format === 'csv') {
      const csvContent = [
        ['Task ID', 'Title', 'Description', 'Priority', 'Status', 'Assignee', 'Estimated Time', 'Cost'],
        ...tasks.map(task => [
          task.id,
          task.title,
          task.description,
          task.priority || 'N/A',
          task.status || 'N/A',
          task.assignee || 'N/A',
          task.estimatedTime || 'N/A',
          task.cost || 'N/A'
        ])
      ].map(row => row.map(field => `"${field}"`).join(',')).join('\n');
      
      const dataBlob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${planData.title.replace(/\s+/g, '_')}_tasks.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } else {
      // PDF format
      const pdfContent = `
${planData.title}
${'='.repeat(planData.title.length)}

Summary: ${planData.summary}
Budget: ₹${planData.totalBudget?.toLocaleString()}
Duration: ${planData.totalDuration} days
Created: ${new Date().toLocaleDateString()}

PHASES:
${planData.phases?.map(phase => `
${phase.title}
${'-'.repeat(phase.title.length)}
${phase.description}
Budget: ₹${phase.budget?.toLocaleString()}
Duration: ${phase.duration} days

Tasks:
${phase.tasks?.map(task => `- ${task.title}: ${task.description}`).join('\n') || 'No tasks'}`).join('\n\n') || 'No phases'}

ALL TASKS:
${tasks.map(task => `${task.title} (${task.status}) - ${task.description}`).join('\n')}
      `;
      
      const dataBlob = new Blob([pdfContent], { type: 'text/plain' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${planData.title.replace(/\s+/g, '_')}_plan.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  const handleShare = () => {
    // Mock share functionality
    console.log('Sharing plan');
    // In real implementation, this would open share dialog
  };

  const renderActiveView = () => {
    switch (activeView) {
      case 'timeline':
        return (
          <TimelineView
            tasks={tasks}
            onTaskUpdate={handleTaskUpdate}
            onTaskSelect={handleTaskSelect}
            selectedTask={selectedTask}
            zoomLevel={zoomLevel}
            onZoomChange={setZoomLevel}
          />
        );
      case 'cards':
        return (
          <CardView
            tasks={tasks}
            onTaskUpdate={handleTaskUpdate}
            onTaskSelect={handleTaskSelect}
            selectedTask={selectedTask}
            groupBy={cardGroupBy}
          />
        );
      case 'list':
        return (
          <ListView
            tasks={tasks}
            onTaskUpdate={handleTaskUpdate}
            onTaskSelect={handleTaskSelect}
            selectedTask={selectedTask}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={true} />
      <ProgressBreadcrumb
        currentPhase="results"
        completedPhases={['input', 'execution']}
        planTitle={mockPlan?.title}
      />
      <WorkflowNavigationTabs
        activeView={activeView}
        onViewChange={setActiveView}
        availableViews={['timeline', 'cards', 'list']}
      />
      {/* Main Content */}
      <div className="max-w-full mx-auto">
        <div className="flex">
          {/* Filter Sidebar */}
          <FilterSidebar
            isOpen={isFilterSidebarOpen}
            onToggle={() => setIsFilterSidebarOpen(!isFilterSidebarOpen)}
            filters={filters}
            onFiltersChange={setFilters}
            tasks={tasks}
          />

          {/* Main Content Area */}
          <div className={`flex-1 min-w-0 transition-all duration-300 ${isDetailsPanelOpen ? 'mr-80' : ''}`}>
            <div className="p-6 space-y-6">
              {/* Action Bar */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <h1 className="text-2xl font-bold text-foreground">Plan Results</h1>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                    <span className="text-sm text-muted-foreground">Live Updates</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Undo2"
                    disabled
                  >
                    Undo
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Redo2"
                    disabled
                  >
                    Redo
                  </Button>
                  <div className="w-px h-6 bg-border"></div>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Share"
                    onClick={handleShare}
                  >
                    Share
                  </Button>
                  <div className="relative group">
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="Download"
                      onClick={() => handleExport('pdf')}
                    >
                      Export
                    </Button>
                    <div className="absolute right-0 top-full mt-1 bg-card border border-border rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                      <div className="py-1">
                        <button
                          onClick={() => handleExport('json')}
                          className="w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors duration-200"
                        >
                          Export as JSON
                        </button>
                        <button
                          onClick={() => handleExport('csv')}
                          className="w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors duration-200"
                        >
                          Export as CSV
                        </button>
                        <button
                          onClick={() => handleExport('pdf')}
                          className="w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors duration-200"
                        >
                          Export as TXT
                        </button>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="default"
                    size="sm"
                    iconName="GitCompare"
                    onClick={() => navigate('/plan-comparison-re-planning', { 
                      state: { 
                        currentPlan: planData,
                        taskData: taskData 
                      } 
                    })}
                  >
                    Compare Plans
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Calendar"
                    onClick={() => navigate('/venue-booking')}
                  >
                    Book Venue
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Edit3"
                    onClick={() => navigate('/task-input-form', { 
                      state: { 
                        editMode: true,
                        existingData: taskData 
                      } 
                    })}
                  >
                    Edit Plan
                  </Button>
                </div>
              </div>

              {/* Comparison Mode Toggle */}
              <ComparisonModeToggle
                isComparisonMode={isComparisonMode}
                onToggle={setIsComparisonMode}
                planCount={2}
              />

              {/* View Controls */}
              {activeView === 'cards' && (
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium text-foreground">Group by:</span>
                  <div className="flex items-center space-x-2">
                    {['priority', 'status', 'category', 'assignee']?.map((groupOption) => (
                      <Button
                        key={groupOption}
                        variant={cardGroupBy === groupOption ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setCardGroupBy(groupOption)}
                      >
                        {groupOption?.charAt(0)?.toUpperCase() + groupOption?.slice(1)}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Main View */}
              {renderActiveView()}
            </div>
          </div>

          {/* Task Details Panel */}
          {isDetailsPanelOpen && (
            <div className="fixed right-0 top-0 h-full w-80 bg-card border-l border-border shadow-lg z-50 overflow-y-auto">
              <TaskDetailsPanel
                task={selectedTask}
                isOpen={isDetailsPanelOpen}
                onClose={() => {
                  setIsDetailsPanelOpen(false);
                  setSelectedTask(null);
                }}
                onTaskUpdate={handleTaskUpdate}
                allTasks={tasks}
              />
            </div>
          )}
        </div>

        {/* Plan Metadata Sidebar (Mobile Bottom Sheet / Desktop Right Panel) */}
        <div className="lg:hidden">
          <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-foreground">Plan Overview</h3>
              <Button variant="ghost" size="sm" iconName="ChevronUp">
                Expand
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-foreground">{tasks?.length}</div>
                <div className="text-xs text-muted-foreground">Total Tasks</div>
              </div>
              <div>
                <div className="text-lg font-bold text-success">
                  {tasks?.filter(t => t?.status === 'completed')?.length}
                </div>
                <div className="text-xs text-muted-foreground">Completed</div>
              </div>
              <div>
                <div className="text-lg font-bold text-primary">
                  {Math.round((tasks?.filter(t => t?.status === 'completed')?.length / tasks?.length) * 100)}%
                </div>
                <div className="text-xs text-muted-foreground">Progress</div>
              </div>
            </div>
          </div>
        </div>

        {/* Desktop Plan Metadata */}
        <div className="hidden lg:block fixed right-4 top-32 w-80 max-h-[calc(100vh-8rem)] overflow-y-auto">
          <PlanMetadata plan={mockPlan} tasks={tasks} />
        </div>
      </div>
      
      

    </div>
  );
};

export default PlanResultsTimeline;