import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import ProgressBreadcrumb from '../../components/ui/ProgressBreadcrumb';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const PlanComparisonRePlanning = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedChanges, setSelectedChanges] = useState(new Set());
  const [isOptimizing, setIsOptimizing] = useState(false);

  const currentPlan = location?.state?.currentPlan || {
    title: "Original Plan",
    totalBudget: 5000,
    totalDuration: 26,
    phases: []
  };

  const taskData = location?.state?.taskData || {};

  // Generate optimized plan
  const optimizedPlan = {
    title: currentPlan.title + " - Optimized",
    totalBudget: Math.floor(currentPlan.totalBudget * 0.85), // 15% cost reduction
    totalDuration: Math.floor(currentPlan.totalDuration * 0.9), // 10% time reduction
    phases: currentPlan.phases?.map(phase => ({
      ...phase,
      budget: Math.floor(phase.budget * 0.85),
      duration: Math.floor(phase.duration * 0.9)
    })) || []
  };

  const changes = [
    {
      id: 1,
      type: "Budget Optimization",
      description: `Reduced total budget from $${currentPlan.totalBudget?.toLocaleString()} to $${optimizedPlan.totalBudget?.toLocaleString()}`,
      impact: "15% cost savings",
      selected: true
    },
    {
      id: 2,
      type: "Timeline Optimization", 
      description: `Reduced duration from ${currentPlan.totalDuration} to ${optimizedPlan.totalDuration} days`,
      impact: "10% faster completion",
      selected: true
    },
    {
      id: 3,
      type: "Resource Efficiency",
      description: "Optimized resource allocation across phases",
      impact: "Better resource utilization",
      selected: true
    }
  ];

  useEffect(() => {
    setSelectedChanges(new Set([1, 2, 3]));
  }, []);

  const handleChangeToggle = (changeId) => {
    const newSelected = new Set(selectedChanges);
    if (newSelected.has(changeId)) {
      newSelected.delete(changeId);
    } else {
      newSelected.add(changeId);
    }
    setSelectedChanges(newSelected);
  };

  const handleApproveAll = async () => {
    setIsOptimizing(true);
    
    try {
      // Apply selected changes to create final optimized plan
      const finalPlan = {
        ...optimizedPlan,
        title: optimizedPlan.title + " (Optimized)",
        isOptimized: true,
        appliedChanges: Array.from(selectedChanges)
      };
      
      // Simulate optimization process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      navigate('/plan-results-timeline', {
        state: {
          generatedPlan: finalPlan,
          taskData: taskData,
          isOptimized: true
        }
      });
    } catch (error) {
      console.error('Error applying changes:', error);
      setIsOptimizing(false);
    }
  };

  const handleRejectAll = () => {
    navigate('/plan-results-timeline', {
      state: {
        generatedPlan: currentPlan,
        taskData: taskData
      }
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={true} />
      <ProgressBreadcrumb
        currentPhase="comparison"
        completedPhases={['input', 'execution', 'results']}
        planTitle={currentPlan.title}
      />
      
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground mb-2">Plan Comparison</h1>
          <p className="text-muted-foreground">
            Review AI-optimized improvements to your plan
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Budget</span>
              <Icon name="DollarSign" size={16} className="text-green-500" />
            </div>
            <div className="space-y-1">
              <div className="text-lg font-bold text-foreground">
                ${optimizedPlan.totalBudget?.toLocaleString()}
              </div>
              <div className="text-xs text-green-500">
                -${(currentPlan.totalBudget - optimizedPlan.totalBudget)?.toLocaleString()} saved
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Duration</span>
              <Icon name="Clock" size={16} className="text-blue-500" />
            </div>
            <div className="space-y-1">
              <div className="text-lg font-bold text-foreground">
                {optimizedPlan.totalDuration} days
              </div>
              <div className="text-xs text-blue-500">
                -{currentPlan.totalDuration - optimizedPlan.totalDuration} days faster
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Changes</span>
              <Icon name="TrendingUp" size={16} className="text-primary" />
            </div>
            <div className="space-y-1">
              <div className="text-lg font-bold text-foreground">
                {selectedChanges.size}
              </div>
              <div className="text-xs text-muted-foreground">
                optimizations selected
              </div>
            </div>
          </div>
        </div>

        {/* Plan Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Original Plan */}
          <div className="bg-card border border-border rounded-lg">
            <div className="p-4 border-b border-border">
              <h3 className="font-semibold text-foreground">Original Plan</h3>
            </div>
            <div className="p-4 space-y-4">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Budget:</span>
                <span className="text-sm font-medium">${currentPlan.totalBudget?.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Duration:</span>
                <span className="text-sm font-medium">{currentPlan.totalDuration} days</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Phases:</span>
                <span className="text-sm font-medium">{currentPlan.phases?.length || 0}</span>
              </div>
            </div>
          </div>

          {/* Optimized Plan */}
          <div className="bg-card border border-green-200 rounded-lg">
            <div className="p-4 border-b border-border bg-green-50">
              <h3 className="font-semibold text-foreground flex items-center">
                <Icon name="Sparkles" size={16} className="text-green-500 mr-2" />
                Optimized Plan
              </h3>
            </div>
            <div className="p-4 space-y-4">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Budget:</span>
                <span className="text-sm font-medium text-green-600">${optimizedPlan.totalBudget?.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Duration:</span>
                <span className="text-sm font-medium text-blue-600">{optimizedPlan.totalDuration} days</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Phases:</span>
                <span className="text-sm font-medium">{optimizedPlan.phases?.length || 0}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Changes List */}
        <div className="bg-card border border-border rounded-lg mb-8">
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground">Proposed Changes</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setSelectedChanges(new Set([1, 2, 3]))}
                  className="text-xs text-primary hover:underline"
                >
                  Select All
                </button>
                <span className="text-xs text-muted-foreground">|</span>
                <button
                  onClick={() => setSelectedChanges(new Set())}
                  className="text-xs text-primary hover:underline"
                >
                  Clear All
                </button>
              </div>
            </div>
          </div>
          <div className="p-4 space-y-4">
            {changes.map((change) => (
              <div 
                key={change.id} 
                className={`flex items-start space-x-3 p-4 rounded-lg border transition-all duration-200 ${
                  selectedChanges.has(change.id) 
                    ? 'bg-primary/5 border-primary/20' 
                    : 'bg-muted/30 border-border hover:border-muted-foreground'
                }`}
              >
                <input
                  type="checkbox"
                  checked={selectedChanges.has(change.id)}
                  onChange={() => handleChangeToggle(change.id)}
                  className="mt-1 w-4 h-4 text-primary border-border rounded focus:ring-primary"
                />
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="font-medium text-foreground">{change.type}</div>
                    <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                      {change.impact}
                    </span>
                  </div>
                  <div className="text-sm text-muted-foreground mb-2">{change.description}</div>
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <span>✓ Recommended by AI</span>
                    <span>• High confidence</span>
                  </div>
                </div>
                <div className="flex items-center space-x-1">
                  <button className="p-1 text-green-600 hover:bg-green-50 rounded">
                    <Icon name="Check" size={14} />
                  </button>
                  <button className="p-1 text-red-600 hover:bg-red-50 rounded">
                    <Icon name="X" size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-foreground">Review Summary</h3>
              <p className="text-sm text-muted-foreground">
                {selectedChanges.size} of {changes.length} changes selected
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium text-green-600">
                Estimated savings: ${(currentPlan.totalBudget - optimizedPlan.totalBudget)?.toLocaleString()}
              </div>
              <div className="text-xs text-muted-foreground">
                Time saved: {currentPlan.totalDuration - optimizedPlan.totalDuration} days
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="outline"
              onClick={handleRejectAll}
              iconName="ArrowLeft"
              iconPosition="left"
              disabled={isOptimizing}
              className="flex-1 sm:flex-none"
            >
              Keep Original Plan
            </Button>
            
            <Button
              onClick={handleApproveAll}
              iconName={isOptimizing ? "Loader2" : "Check"}
              iconPosition="left"
              loading={isOptimizing}
              disabled={selectedChanges.size === 0}
              className="flex-1 sm:flex-none"
            >
              {isOptimizing ? "Applying Changes..." : `Apply ${selectedChanges.size} Changes`}
            </Button>
          </div>
        </div>

        {isOptimizing && (
          <div className="mt-6 text-center">
            <div className="inline-flex items-center space-x-2 text-sm text-muted-foreground">
              <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              <span>Optimizing your plan...</span>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default PlanComparisonRePlanning;