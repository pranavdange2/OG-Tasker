import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReasoningSection = ({ 
  reasoning = [], 
  isExpanded = false, 
  onToggle 
}) => {
  const getReasoningTypeIcon = (type) => {
    switch (type) {
      case 'optimization': return 'Zap';
      case 'constraint': return 'AlertTriangle';
      case 'dependency': return 'Link';
      default: return 'Brain';
    }
  };

  const getReasoningTypeColor = (type) => {
    switch (type) {
      case 'optimization': return 'text-blue-600 bg-blue-50';
      case 'constraint': return 'text-yellow-600 bg-yellow-50';
      case 'dependency': return 'text-purple-600 bg-purple-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getConfidenceColor = (confidence) => {
    if (confidence >= 80) return 'text-green-600';
    if (confidence >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Brain" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">AI Reasoning</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
            iconPosition="right"
          >
            {isExpanded ? 'Hide Details' : 'Show Details'}
          </Button>
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 space-y-4">
          {reasoning.map((item, index) => (
            <div key={index} className="border border-border rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <div className={`p-2 rounded-md ${getReasoningTypeColor(item.type)}`}>
                  <Icon 
                    name={getReasoningTypeIcon(item.type)} 
                    size={16} 
                  />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-foreground">
                      {item.title}
                    </h4>
                    <div className="flex items-center space-x-2">
                      <span className={`text-xs font-medium ${getConfidenceColor(item.confidence)}`}>
                        {item.confidence}% confidence
                      </span>
                      <span className="text-xs px-2 py-1 bg-muted rounded-full">
                        {item.impact} impact
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-3">
                    {item.description}
                  </p>
                  
                  {item.factors && (
                    <div className="mb-3">
                      <h5 className="text-xs font-medium text-foreground mb-2">
                        Key Factors:
                      </h5>
                      <ul className="space-y-1">
                        {item.factors.map((factor, factorIndex) => (
                          <li key={factorIndex} className="flex items-start space-x-2">
                            <Icon name="Check" size={12} className="text-green-500 mt-0.5" />
                            <span className="text-xs text-muted-foreground">
                              {factor}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {item.alternatives && (
                    <div>
                      <h5 className="text-xs font-medium text-foreground mb-2">
                        Alternatives Considered:
                      </h5>
                      <div className="space-y-2">
                        {item.alternatives.map((alt, altIndex) => (
                          <div key={altIndex} className="p-2 bg-muted/50 rounded-md">
                            <div className="text-xs font-medium text-foreground">
                              {alt.option}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {alt.description}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ReasoningSection;