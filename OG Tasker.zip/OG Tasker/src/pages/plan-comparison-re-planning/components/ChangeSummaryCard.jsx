import React from 'react';
import Icon from '../../../components/AppIcon';

const ChangeSummaryCard = ({ 
  title, 
  originalValue, 
  newValue, 
  changeType, 
  impact, 
  icon 
}) => {
  const getChangeColor = () => {
    switch (changeType) {
      case 'increase': return 'text-red-600';
      case 'decrease': return 'text-green-600';
      default: return 'text-blue-600';
    }
  };

  const getChangeIcon = () => {
    switch (changeType) {
      case 'increase': return 'TrendingUp';
      case 'decrease': return 'TrendingDown';
      default: return 'ArrowRight';
    }
  };

  const formatValue = (value) => {
    if (typeof value === 'number') {
      return value.toLocaleString();
    }
    return value;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon name={icon || 'BarChart'} size={16} className="text-muted-foreground" />
          <h3 className="text-sm font-medium text-foreground">{title}</h3>
        </div>
        <Icon 
          name={getChangeIcon()} 
          size={16} 
          className={getChangeColor()} 
        />
      </div>
      
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Original:</span>
          <span className="font-medium">{formatValue(originalValue)}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">New:</span>
          <span className={`font-medium ${getChangeColor()}`}>
            {formatValue(newValue)}
          </span>
        </div>
      </div>
      
      <div className="mt-3 pt-3 border-t border-border">
        <p className="text-xs text-muted-foreground">{impact}</p>
      </div>
    </div>
  );
};

export default ChangeSummaryCard;