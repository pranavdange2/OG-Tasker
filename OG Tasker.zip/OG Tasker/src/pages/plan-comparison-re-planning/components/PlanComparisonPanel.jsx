import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PlanComparisonPanel = ({ 
  originalPlan, 
  updatedPlan, 
  changes = [], 
  onApproveChange, 
  onRejectChange,
  className = '' 
}) => {
  const [selectedChanges, setSelectedChanges] = useState(new Set());
  const [expandedSections, setExpandedSections] = useState(new Set());

  const toggleChangeSelection = (changeId) => {
    const newSelection = new Set(selectedChanges);
    if (newSelection?.has(changeId)) {
      newSelection?.delete(changeId);
    } else {
      newSelection?.add(changeId);
    }
    setSelectedChanges(newSelection);
  };

  const toggleSection = (sectionId) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded?.has(sectionId)) {
      newExpanded?.delete(sectionId);
    } else {
      newExpanded?.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };

  const getChangeTypeColor = (type) => {
    switch (type) {
      case 'added':
        return 'bg-success/10 border-success/20 text-success';
      case 'modified':
        return 'bg-warning/10 border-warning/20 text-warning';
      case 'removed':
        return 'bg-error/10 border-error/20 text-error';
      default:
        return 'bg-muted/10 border-border text-muted-foreground';
    }
  };

  const getChangeTypeIcon = (type) => {
    switch (type) {
      case 'added':
        return 'Plus';
      case 'modified':
        return 'Edit';
      case 'removed':
        return 'Minus';
      default:
        return 'Circle';
    }
  };

  const PlanSection = ({ title, items, isOriginal = false }) => {
    const sectionId = `${title}-${isOriginal ? 'original' : 'updated'}`;
    const isExpanded = expandedSections?.has(sectionId);

    return (
      <div className="mb-4">
        <button
          onClick={() => toggleSection(sectionId)}
          className="flex items-center justify-between w-full p-3 bg-muted/50 rounded-md hover:bg-muted transition-colors duration-200"
        >
          <h4 className="text-sm font-medium text-foreground">{title}</h4>
          <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
        </button>
        {isExpanded && (
          <div className="mt-2 space-y-2">
            {items?.map((item, index) => (
              <div key={index} className="p-3 bg-card border border-border rounded-md">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h5 className="text-sm font-medium text-foreground mb-1">{item?.title}</h5>
                    <p className="text-xs text-muted-foreground mb-2">{item?.description}</p>
                    <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                      <span>Duration: {item?.duration}</span>
                      <span>Budget: ${item?.budget}</span>
                    </div>
                  </div>
                  {item?.changeType && (
                    <div className={`px-2 py-1 rounded-md text-xs font-medium border ${getChangeTypeColor(item?.changeType)}`}>
                      <div className="flex items-center space-x-1">
                        <Icon name={getChangeTypeIcon(item?.changeType)} size={12} />
                        <span>{item?.changeType}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`grid grid-cols-1 lg:grid-cols-2 gap-6 ${className}`}>
      {/* Original Plan */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-4">
          <div className="w-8 h-8 bg-muted rounded-md flex items-center justify-center">
            <Icon name="FileText" size={16} className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold text-foreground">Original Plan</h3>
        </div>
        
        <div className="space-y-4">
          {originalPlan?.sections?.map((section, index) => (
            <PlanSection
              key={`original-${index}`}
              title={section?.title}
              items={section?.items}
              isOriginal={true}
            />
          ))}
        </div>
      </div>
      {/* Updated Plan */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-4">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <Icon name="Sparkles" size={16} color="white" />
          </div>
          <h3 className="text-lg font-semibold text-foreground">Updated Plan</h3>
        </div>
        
        <div className="space-y-4">
          {updatedPlan?.sections?.map((section, index) => (
            <PlanSection
              key={`updated-${index}`}
              title={section?.title}
              items={section?.items}
              isOriginal={false}
            />
          ))}
        </div>
      </div>
      {/* Changes Panel */}
      <div className="lg:col-span-2 bg-card border border-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Detected Changes</h3>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedChanges(new Set(changes.map(c => c.id)))}
              iconName="CheckSquare"
              iconPosition="left"
            >
              Select All
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedChanges(new Set())}
              iconName="Square"
              iconPosition="left"
            >
              Clear All
            </Button>
          </div>
        </div>

        <div className="space-y-3">
          {changes?.map((change) => (
            <div
              key={change?.id}
              className={`p-4 border rounded-lg transition-all duration-200 ${
                selectedChanges?.has(change?.id) 
                  ? 'border-primary bg-primary/5' :'border-border hover:border-muted-foreground'
              }`}
            >
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  checked={selectedChanges?.has(change?.id)}
                  onChange={() => toggleChangeSelection(change?.id)}
                  className="mt-1 w-4 h-4 text-primary border-border rounded focus:ring-primary"
                />
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className={`px-2 py-1 rounded-md text-xs font-medium border ${getChangeTypeColor(change?.type)}`}>
                      <div className="flex items-center space-x-1">
                        <Icon name={getChangeTypeIcon(change?.type)} size={12} />
                        <span>{change?.type}</span>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-foreground">{change?.title}</span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-2">{change?.description}</p>
                  
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <span>Impact: {change?.impact}</span>
                    <span>Confidence: {change?.confidence}%</span>
                  </div>
                  
                  {change?.reasoning && (
                    <div className="mt-2 p-2 bg-muted/50 rounded-md">
                      <p className="text-xs text-muted-foreground">
                        <strong>AI Reasoning:</strong> {change?.reasoning}
                      </p>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onApproveChange(change?.id)}
                    iconName="Check"
                    className="text-success hover:bg-success/10"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRejectChange(change?.id)}
                    iconName="X"
                    className="text-error hover:bg-error/10"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {selectedChanges?.size > 0 && (
          <div className="mt-4 flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg">
            <span className="text-sm text-primary">
              {selectedChanges?.size} change{selectedChanges?.size !== 1 ? 's' : ''} selected
            </span>
            <div className="flex items-center space-x-2">
              <Button
                variant="default"
                size="sm"
                iconName="Check"
                iconPosition="left"
              >
                Approve Selected
              </Button>
              <Button
                variant="outline"
                size="sm"
                iconName="X"
                iconPosition="left"
              >
                Reject Selected
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlanComparisonPanel;