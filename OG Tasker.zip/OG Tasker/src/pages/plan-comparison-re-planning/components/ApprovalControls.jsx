import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ApprovalControls = ({ 
  pendingChanges = 0,
  onApproveAll,
  onRejectAll,
  onSaveDraft,
  onExportComparison,
  onRequestReview
}) => {
  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Review Actions</h3>
          <p className="text-sm text-muted-foreground">
            {pendingChanges} changes pending review
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-warning rounded-full animate-pulse" />
          <span className="text-xs text-warning font-medium">Pending Review</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Primary Actions */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground">Primary Actions</h4>
          <div className="space-y-2">
            <Button
              onClick={onApproveAll}
              iconName="Check"
              iconPosition="left"
              className="w-full"
              disabled={pendingChanges === 0}
            >
              Approve All Changes
            </Button>
            <Button
              variant="outline"
              onClick={onRejectAll}
              iconName="X"
              iconPosition="left"
              className="w-full"
              disabled={pendingChanges === 0}
            >
              Reject All Changes
            </Button>
          </div>
        </div>

        {/* Secondary Actions */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground">Save & Export</h4>
          <div className="space-y-2">
            <Button
              variant="ghost"
              onClick={onSaveDraft}
              iconName="Save"
              iconPosition="left"
              className="w-full"
            >
              Save as Draft
            </Button>
            <Button
              variant="ghost"
              onClick={onExportComparison}
              iconName="Download"
              iconPosition="left"
              className="w-full"
            >
              Export Comparison
            </Button>
          </div>
        </div>

        {/* Collaboration */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground">Collaboration</h4>
          <div className="space-y-2">
            <Button
              variant="ghost"
              onClick={onRequestReview}
              iconName="Users"
              iconPosition="left"
              className="w-full"
            >
              Request Review
            </Button>
            <Button
              variant="ghost"
              iconName="MessageSquare"
              iconPosition="left"
              className="w-full"
            >
              Add Comment
            </Button>
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4 text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="Clock" size={12} />
              <span>Last updated: 2 minutes ago</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="User" size={12} />
              <span>Modified by: AI Assistant</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full" />
            <span className="text-success font-medium">Auto-saved</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApprovalControls;