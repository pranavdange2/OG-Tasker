import React from 'react';
import Icon from '../../../components/AppIcon';

const TimelineVisualization = ({ 
  originalTimeline = [], 
  updatedTimeline = [], 
  showComparison = true 
}) => {
  const getChangeTypeColor = (changeType) => {
    switch (changeType) {
      case 'added': return 'bg-green-100 border-green-300 text-green-800';
      case 'modified': return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      case 'removed': return 'bg-red-100 border-red-300 text-red-800';
      default: return 'bg-gray-100 border-gray-300 text-gray-800';
    }
  };

  const TimelineItem = ({ task, isOriginal = false }) => (
    <div className="flex items-center space-x-4 p-3 bg-card border border-border rounded-lg">
      <div className="flex-shrink-0">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
          task.status === 'completed' ? 'bg-green-100 text-green-600' :
          task.status === 'in-progress' ? 'bg-blue-100 text-blue-600' :
          'bg-gray-100 text-gray-600'
        }`}>
          <Icon name="CheckCircle" size={16} />
        </div>
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center space-x-2 mb-1">
          <h4 className="text-sm font-medium text-foreground truncate">
            {task.title}
          </h4>
          {task.changeType && (
            <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getChangeTypeColor(task.changeType)}`}>
              {task.changeType}
            </span>
          )}
        </div>
        <p className="text-xs text-muted-foreground mb-2">{task.description}</p>
        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
          <span>Duration: {task.duration}</span>
          <span>Budget: ${task.budget?.toLocaleString()}</span>
          <span>Assignee: {task.assignee}</span>
        </div>
        {task.changeReason && (
          <div className="mt-2 p-2 bg-muted/50 rounded-md">
            <p className="text-xs text-muted-foreground">
              <strong>Change Reason:</strong> {task.changeReason}
            </p>
          </div>
        )}
      </div>
      
      <div className="flex-shrink-0 text-right">
        <div className="text-xs text-muted-foreground">
          {new Date(task.startDate).toLocaleDateString()}
        </div>
        <div className={`text-xs font-medium ${
          task.status === 'completed' ? 'text-green-600' :
          task.status === 'in-progress' ? 'text-blue-600' :
          'text-gray-600'
        }`}>
          {task.status}
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Timeline Comparison</h3>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Icon name="Calendar" size={16} />
          <span>Project Timeline</span>
        </div>
      </div>

      {showComparison ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Original Timeline */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Icon name="Clock" size={16} className="text-muted-foreground" />
              <h4 className="text-md font-medium text-foreground">Original Timeline</h4>
            </div>
            <div className="space-y-3">
              {originalTimeline.map((task, index) => (
                <TimelineItem key={`original-${index}`} task={task} isOriginal={true} />
              ))}
            </div>
          </div>

          {/* Updated Timeline */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Icon name="Sparkles" size={16} className="text-primary" />
              <h4 className="text-md font-medium text-foreground">Optimized Timeline</h4>
            </div>
            <div className="space-y-3">
              {updatedTimeline.map((task, index) => (
                <TimelineItem key={`updated-${index}`} task={task} isOriginal={false} />
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {updatedTimeline.map((task, index) => (
            <TimelineItem key={index} task={task} />
          ))}
        </div>
      )}

      {/* Timeline Summary */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="text-lg font-bold text-foreground">
              {updatedTimeline.length}
            </div>
            <div className="text-xs text-muted-foreground">Total Tasks</div>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="text-lg font-bold text-green-600">
              {updatedTimeline.filter(t => t.changeType === 'added').length}
            </div>
            <div className="text-xs text-muted-foreground">Added Tasks</div>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="text-lg font-bold text-yellow-600">
              {updatedTimeline.filter(t => t.changeType === 'modified').length}
            </div>
            <div className="text-xs text-muted-foreground">Modified Tasks</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimelineVisualization;