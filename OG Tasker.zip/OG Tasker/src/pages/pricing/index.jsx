import React from 'react';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';

const Pricing = () => {
  const plans = [
    {
      name: 'Free',
      price: '₹0',
      period: '/month',
      features: ['5 AI-generated plans', 'Basic timeline view', 'Email support'],
      popular: false
    },
    {
      name: 'Pro',
      price: '₹1,599',
      period: '/month',
      features: ['Unlimited AI plans', 'Advanced analytics', 'Team collaboration', 'Priority support'],
      popular: true
    },
    {
      name: 'Enterprise',
      price: '₹4,099',
      period: '/month',
      features: ['Custom AI models', 'Advanced security', 'Dedicated support', 'API access'],
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={false} />
      
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Simple Pricing
          </h1>
          <p className="text-xl text-muted-foreground">
            Choose the plan that fits your needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div key={index} className={`bg-card p-8 rounded-lg border ${plan.popular ? 'border-primary' : 'border-border'} relative`}>
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm">
                    Most Popular
                  </span>
                </div>
              )}
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
                <div className="text-4xl font-bold text-foreground">
                  {plan.price}<span className="text-lg text-muted-foreground">{plan.period}</span>
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-muted-foreground">
                    <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                    {feature}
                  </li>
                ))}
              </ul>
              <Button variant={plan.popular ? "default" : "outline"} fullWidth>
                Get Started
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Pricing;