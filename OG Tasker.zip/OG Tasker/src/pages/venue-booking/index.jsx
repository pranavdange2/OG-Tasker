import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const VenueBooking = () => {
  const navigate = useNavigate();
  const [selectedVenue, setSelectedVenue] = useState(null);
  const [bookingData, setBookingData] = useState({
    date: '',
    time: '',
    duration: '',
    guests: '',
    requirements: ''
  });

  const venues = [
    {
      id: 1,
      name: "Grand Conference Hall",
      capacity: "500 people",
      price: "$2,500/day",
      location: "Downtown",
      features: ["AV Equipment", "Catering", "Parking", "WiFi"]
    },
    {
      id: 2,
      name: "Executive Meeting Room",
      capacity: "50 people", 
      price: "$500/day",
      location: "Business District",
      features: ["Projector", "Whiteboard", "Coffee Service", "WiFi"]
    },
    {
      id: 3,
      name: "Outdoor Event Space",
      capacity: "200 people",
      price: "$1,200/day", 
      location: "City Park",
      features: ["Garden Setting", "Tent Option", "Catering", "Parking"]
    }
  ];

  const handleBookVenue = () => {
    if (!selectedVenue || !bookingData.date || !bookingData.time) {
      alert('Please select a venue and fill in the required details');
      return;
    }

    navigate('/schedule', {
      state: {
        venue: selectedVenue,
        bookingData: bookingData
      }
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isAuthenticated={true} />
      
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Venue Booking</h1>
          <p className="text-gray-600">Choose the perfect venue for your event</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="text-xl font-semibold mb-4">Available Venues</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {venues.map((venue) => (
                <div
                  key={venue.id}
                  className={`bg-white rounded-lg border-2 cursor-pointer transition-all ${
                    selectedVenue?.id === venue.id 
                      ? 'border-blue-500 shadow-lg' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedVenue(venue)}
                >
                  <div className="h-48 bg-gray-200 rounded-t-lg flex items-center justify-center">
                    <Icon name="Building" size={48} className="text-gray-400" />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{venue.name}</h3>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Icon name="Users" size={16} className="mr-2" />
                        {venue.capacity}
                      </div>
                      <div className="flex items-center">
                        <Icon name="MapPin" size={16} className="mr-2" />
                        {venue.location}
                      </div>
                      <div className="flex items-center">
                        <Icon name="DollarSign" size={16} className="mr-2" />
                        {venue.price}
                      </div>
                    </div>
                    <div className="mt-3">
                      <div className="flex flex-wrap gap-1">
                        {venue.features.map((feature, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                          >
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border border-gray-200 p-6 sticky top-4">
              <h2 className="text-xl font-semibold mb-4">Booking Details</h2>
              
              {selectedVenue && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                  <h3 className="font-medium text-blue-900">{selectedVenue.name}</h3>
                  <p className="text-sm text-blue-700">{selectedVenue.price}</p>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Event Date *
                  </label>
                  <input
                    type="date"
                    value={bookingData.date}
                    onChange={(e) => setBookingData({...bookingData, date: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Start Time *
                  </label>
                  <input
                    type="time"
                    value={bookingData.time}
                    onChange={(e) => setBookingData({...bookingData, time: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Duration
                  </label>
                  <select
                    value={bookingData.duration}
                    onChange={(e) => setBookingData({...bookingData, duration: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="">Select duration</option>
                    <option value="2">2 hours</option>
                    <option value="4">4 hours</option>
                    <option value="8">Full day</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Expected Guests
                  </label>
                  <input
                    type="number"
                    value={bookingData.guests}
                    onChange={(e) => setBookingData({...bookingData, guests: e.target.value})}
                    placeholder="Number of guests"
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Special Requirements
                  </label>
                  <textarea
                    value={bookingData.requirements}
                    onChange={(e) => setBookingData({...bookingData, requirements: e.target.value})}
                    placeholder="Any special requirements..."
                    rows={3}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>
              </div>

              <Button
                onClick={handleBookVenue}
                className="w-full mt-6"
                disabled={!selectedVenue || !bookingData.date || !bookingData.time}
              >
                Continue to Schedule
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default VenueBooking;