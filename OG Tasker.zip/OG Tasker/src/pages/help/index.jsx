import React from 'react';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';

const Help = () => {
  const faqs = [
    {
      question: "How do I create a new task plan?",
      answer: "Click on 'Create New Plan' and describe your goal. Our AI will generate a comprehensive task breakdown for you."
    },
    {
      question: "Can I edit generated plans?",
      answer: "Yes, you can edit any task in the timeline view by clicking on it and using the task details panel."
    },
    {
      question: "How do I export my plans?",
      answer: "Use the Export button in the Plan Results page to download your plans in JSON, CSV, or TXT format."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={true} />
      
      <div className="max-w-4xl mx-auto px-4 py-16">
        <h1 className="text-3xl font-bold text-foreground mb-8">Help & Support</h1>
        
        <div className="space-y-8">
          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">Getting Started</h2>
            <p className="text-muted-foreground">
              Welcome to AI Task Planner! Start by describing your goal and let our AI create a detailed plan for you.
            </p>
          </div>

          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div key={index} className="border-b border-border pb-4 last:border-b-0">
                  <h3 className="font-medium text-foreground mb-2">{faq.question}</h3>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">Contact Support</h2>
            <div className="flex items-center space-x-2 text-muted-foreground">
              <Icon name="Mail" size={16} />
              <span>support@aitaskplanner.com</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Help;