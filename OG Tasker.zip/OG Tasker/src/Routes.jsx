import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import AgentExecutionDashboard from './pages/agent-execution-dashboard';
import LandingPage from './pages/landing-page';
import PlanResultsTimeline from './pages/plan-results-timeline';
import UserAuthentication from './pages/user-authentication';
import TaskInputForm from './pages/task-input-form';
import PlanComparisonRePlanning from './pages/plan-comparison-re-planning';
import VenueBooking from './pages/venue-booking';
import Schedule from './pages/schedule';
import Invites from './pages/invites';
import Features from './pages/features';
import Pricing from './pages/pricing';
import About from './pages/about';
import Settings from './pages/settings';
import Help from './pages/help';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<TaskInputForm />} />
        <Route path="/dashboard" element={<TaskInputForm />} />
        <Route path="/agent-execution-dashboard" element={<AgentExecutionDashboard />} />
        <Route path="/landing-page" element={<LandingPage />} />
        <Route path="/plan-results-timeline" element={<PlanResultsTimeline />} />
        <Route path="/user-authentication" element={<UserAuthentication />} />
        <Route path="/task-input-form" element={<TaskInputForm />} />
        <Route path="/plan-comparison-re-planning" element={<PlanComparisonRePlanning />} />
        <Route path="/venue-booking" element={<VenueBooking />} />
        <Route path="/schedule" element={<Schedule />} />
        <Route path="/invites" element={<Invites />} />
        <Route path="/features" element={<Features />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/about" element={<About />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/help" element={<Help />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
