import { useState, useCallback } from 'react';
import { generateTaskPlan, generateTaskPlanWithProgress, optimizePlan, generateTaskSuggestions } from '../services/openaiService';

/**
 * Custom hook for OpenAI operations
 * Provides state management and error handling for AI-powered features
 */
export const useOpenAI = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [progress, setProgress] = useState(null);

  // Clear any existing errors
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Generate a complete task plan
  const createPlan = useCallback(async (taskData) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await generateTaskPlan(taskData);
      return result;
    } catch (err) {
      setError(err?.message || 'Failed to generate plan');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Generate plan with streaming progress updates
  const createPlanWithProgress = useCallback(async (taskData, onProgressUpdate) => {
    setIsLoading(true);
    setError(null);
    setProgress(null);
    
    try {
      const result = await generateTaskPlanWithProgress(taskData, (chunk, fullContent) => {
        setProgress({ chunk, fullContent });
        onProgressUpdate?.(chunk, fullContent);
      });
      return result;
    } catch (err) {
      setError(err?.message || 'Failed to generate plan with progress');
      throw err;
    } finally {
      setIsLoading(false);
      setProgress(null);
    }
  }, []);

  // Optimize existing plan
  const optimizeExistingPlan = useCallback(async (currentPlan, constraints) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await optimizePlan(currentPlan, constraints);
      return result;
    } catch (err) {
      setError(err?.message || 'Failed to optimize plan');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Generate task suggestions
  const getSuggestions = useCallback(async (goalDescription) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await generateTaskSuggestions(goalDescription);
      return result;
    } catch (err) {
      setError(err?.message || 'Failed to generate suggestions');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    // State
    isLoading,
    error,
    progress,
    
    // Actions
    createPlan,
    createPlanWithProgress,
    optimizeExistingPlan,
    getSuggestions,
    clearError
  };
};

export default useOpenAI;