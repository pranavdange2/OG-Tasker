import OpenAI from 'openai';

/**
 * OpenAI Service for AI Task Planner
 * Handles all OpenAI API interactions for plan generation and optimization
 */

// Initialize OpenAI client with OpenRouter support
const apiKey = import.meta.env.VITE_OPENAI_API_KEY || import.meta.env.VITE_PERPLEXITY_API_KEY;
const isOpenRouter = apiKey?.startsWith('sk-or-v1-');

if (!apiKey) {
  console.error('No API key found. Please set VITE_OPENAI_API_KEY in your .env file');
}

const openai = apiKey ? new OpenAI({
  apiKey: apiKey,
  baseURL: isOpenRouter ? 'https://openrouter.ai/api/v1' : undefined,
  dangerouslyAllowBrowser: true,
  defaultHeaders: isOpenRouter ? {
    'HTTP-Referer': window.location.origin,
    'X-Title': 'AI Task Planner'
  } : undefined
}) : null;

// Test API connection
const testAPIConnection = async () => {
  if (!openai || !apiKey) return false;
  try {
    await openai.chat.completions.create({
      model: isOpenRouter ? 'openai/gpt-3.5-turbo' : 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: 'test' }],
      max_tokens: 5
    });
    return true;
  } catch (error) {
    console.error('API connection test failed:', error);
    return false;
  }
};

/**
 * Generates a comprehensive task plan using OpenAI GPT
 * @param {Object} taskData - User input data for task planning
 * @returns {Promise<Object>} Generated plan with structured response
 */
export async function generateTaskPlan(taskData) {
  try {
    if (!apiKey || !openai) {
      throw new Error('OpenAI API key is not configured. Please check your environment variables.');
    }
    
    const prompt = createPlanningPrompt(taskData);
    
    const response = await openai?.chat?.completions?.create({
      model: isOpenRouter ? 'openai/gpt-3.5-turbo' : 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are an expert AI task planning assistant. Generate comprehensive, actionable plans based on user requirements. Always provide structured, detailed responses with timelines, budgets, and specific action items. Respond in JSON format only.'
        },
        {
          role: 'user',
          content: prompt + '\n\nPlease respond with a JSON object in this exact format:\n{\n  "title": "Plan title",\n  "summary": "Brief summary",\n  "phases": [\n    {\n      "id": 1,\n      "title": "Phase name",\n      "description": "Phase description",\n      "duration": 7,\n      "budget": 1000,\n      "tasks": [\n        {\n          "id": 1,\n          "title": "Task name",\n          "description": "Task description",\n          "priority": "high",\n          "estimatedTime": 3,\n          "dependencies": []\n        }\n      ]\n    }\n  ],\n  "totalBudget": 5000,\n  "totalDuration": 21,\n  "risks": [\n    {\n      "title": "Risk name",\n      "impact": "medium",\n      "mitigation": "Mitigation strategy"\n    }\n  ],\n  "recommendations": ["Recommendation 1", "Recommendation 2"]\n}'
        }
      ],
      temperature: 0.7,
      max_tokens: 4000
    });

    const content = response?.choices?.[0]?.message?.content;
    if (!content) {
      throw new Error('No response content received');
    }

    try {
      return JSON.parse(content);
    } catch (parseError) {
      // Try to extract JSON from the response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      // Final fallback: return a structured plan based on input
      console.warn('Using fallback plan generation due to parsing error');
      return createFallbackPlan(taskData);
    }
  } catch (error) {
    console.error('Error generating task plan:', error);
    
    // Return fallback plan instead of throwing error
    console.warn('Using fallback plan generation due to API error');
    return createFallbackPlan(taskData);
  }
}

/**
 * Streams plan generation progress with real-time updates
 * @param {Object} taskData - User input data for task planning
 * @param {Function} onProgress - Callback for progress updates
 * @returns {Promise<Object>} Final generated plan
 */
export async function generateTaskPlanWithProgress(taskData, onProgress) {
  try {
    if (!apiKey || !openai) {
      throw new Error('OpenAI API key is not configured. Please check your environment variables.');
    }
    
    const prompt = createPlanningPrompt(taskData);
    let streamedContent = '';
    
    const stream = await openai?.chat?.completions?.create({
      model: isOpenRouter ? 'openai/gpt-4' : 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are an expert AI task planning assistant. Generate comprehensive, actionable plans based on user requirements. Provide structured responses with clear phases and actionable tasks.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      stream: true,
      temperature: 0.7,
      max_tokens: 4000
    });

    for await (const chunk of stream) {
      const content = chunk?.choices?.[0]?.delta?.content || '';
      if (content) {
        streamedContent += content;
        onProgress?.(content, streamedContent);
      }
    }

    // Parse the final streamed content into structured format
    return parseStreamedPlan(streamedContent, taskData);
  } catch (error) {
    console.error('Error in streaming plan generation:', error);
    
    // Return fallback plan instead of throwing error
    console.warn('Using fallback plan generation due to streaming error');
    return createFallbackPlan(taskData);
  }
}

/**
 * Optimizes an existing plan using OpenAI
 * @param {Object} currentPlan - Existing plan to optimize
 * @param {Object} constraints - New constraints or requirements
 * @returns {Promise<Object>} Optimized plan
 */
export async function optimizePlan(currentPlan, constraints) {
  try {
    if (!apiKey || !openai) {
      throw new Error('OpenAI API key is not configured. Please check your environment variables.');
    }
    
    const response = await openai?.chat?.completions?.create({
      model: isOpenRouter ? 'openai/gpt-3.5-turbo' : 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are an expert plan optimization assistant. Analyze existing plans and suggest improvements based on new constraints or requirements. Respond in JSON format only.'
        },
        {
          role: 'user',
          content: `Please optimize this plan:\n${JSON.stringify(currentPlan, null, 2)}\n\nNew constraints:\n${JSON.stringify(constraints, null, 2)}\n\nRespond with JSON in this format:\n{\n  "optimizedPlan": { "title": "", "phases": [], "totalBudget": 0, "totalDuration": 0 },\n  "changes": [{ "type": "", "description": "", "impact": "" }],\n  "reasoning": ""\n}`
        }
      ],
      temperature: 0.5
    });

    const content = response?.choices?.[0]?.message?.content;
    if (!content) {
      throw new Error('No response content received');
    }

    try {
      return JSON.parse(content);
    } catch (parseError) {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Invalid JSON response from AI');
    }
  } catch (error) {
    console.error('Error optimizing plan:', error);
    throw new Error(`Failed to optimize plan: ${error.message}`);
  }
}

/**
 * Generates intelligent task suggestions based on context
 * @param {string} goalDescription - User's goal description
 * @returns {Promise<Array>} Array of suggested tasks
 */
export async function generateTaskSuggestions(goalDescription) {
  try {
    if (!apiKey || !openai) {
      throw new Error('API key not configured. Please set VITE_OPENAI_API_KEY in your .env file.');
    }
    
    const response = await openai.chat.completions.create({
      model: isOpenRouter ? 'openai/gpt-3.5-turbo' : 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: 'Generate helpful task suggestions based on the user\'s goal description. Provide practical, actionable suggestions. Respond with a JSON object containing a "suggestions" array with objects having title, description, priority (high/medium/low), and estimatedDuration fields.'
        },
        {
          role: 'user',
          content: `Goal: ${goalDescription}\n\nSuggest 5-8 key tasks needed to achieve this goal. Format your response as JSON with this structure:\n{\n  "suggestions": [\n    {\n      "title": "Task title",\n      "description": "Task description",\n      "priority": "high|medium|low",\n      "estimatedDuration": "time estimate"\n    }\n  ]\n}`
        }
      ],
      temperature: 0.8,
      max_tokens: 1500
    });

    const content = response?.choices?.[0]?.message?.content;
    if (!content) {
      throw new Error('No response content received');
    }

    try {
      return JSON.parse(content);
    } catch (parseError) {
      // Fallback: try to extract JSON from the response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      // Final fallback: return mock suggestions
      return {
        suggestions: [
          {
            title: "Research and Planning",
            description: "Conduct thorough research and create initial plan",
            priority: "high",
            estimatedDuration: "2-3 days"
          },
          {
            title: "Resource Allocation",
            description: "Identify and allocate necessary resources",
            priority: "high",
            estimatedDuration: "1-2 days"
          },
          {
            title: "Implementation Phase",
            description: "Execute the main tasks according to plan",
            priority: "high",
            estimatedDuration: "1-2 weeks"
          },
          {
            title: "Quality Review",
            description: "Review progress and ensure quality standards",
            priority: "medium",
            estimatedDuration: "1-2 days"
          },
          {
            title: "Final Delivery",
            description: "Complete final deliverables and handover",
            priority: "high",
            estimatedDuration: "1-2 days"
          }
        ]
      };
    }
  } catch (error) {
    console.error('Error generating task suggestions:', error);
    throw new Error(`Failed to generate suggestions: ${error.message}`);
  }
}

/**
 * Creates a detailed planning prompt from user input
 * @param {Object} taskData - User input data
 * @returns {string} Formatted prompt for OpenAI
 */
function createPlanningPrompt(taskData) {
  const {
    goalTitle,
    goalDescription,
    startDate,
    endDate,
    budget,
    budgetType,
    location,
    priorities,
    constraints,
    style,
    teamCollaboration
  } = taskData;

  const timeframe = startDate && endDate 
    ? `from ${startDate} to ${endDate}` 
    : 'flexible timeframe';

  const budgetInfo = budget && budgetType 
    ? `${budgetType} budget of $${budget?.toLocaleString()}` 
    : 'flexible budget';

  return `
Create a comprehensive plan for: ${goalTitle}

Additional Details: ${goalDescription || 'Not provided'}

Key Parameters:
- Timeline: ${timeframe}
- Budget: ${budgetInfo}
- Location: ${location || 'Not specified'}
- Priorities: ${priorities?.join(', ') || 'Not specified'}
- Constraints: ${constraints?.join(', ') || 'None specified'}
- Style/Approach: ${style || 'Standard approach'}
- Team Collaboration: ${teamCollaboration?.enabled ? 'Required' : 'Not required'}

Please generate a detailed plan that includes:
1. Clear phases with specific tasks
2. Realistic timelines for each phase
3. Budget allocation across phases
4. Risk assessment and mitigation strategies
5. Actionable recommendations

Make the plan practical and achievable within the given constraints.
  `?.trim();
}

/**
 * Parses streamed content into structured plan format
 * @param {string} streamedContent - Raw streamed text
 * @param {Object} taskData - Original task data
 * @returns {Object} Structured plan object
 */
function parseStreamedPlan(streamedContent, taskData) {
  // Try to parse JSON from streamed content
  try {
    const jsonMatch = streamedContent?.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed?.title && parsed?.phases) {
        return parsed;
      }
    }
  } catch (parseError) {
    console.warn('Could not parse streamed content as JSON');
  }
  
  // Fallback to generated plan
  return createFallbackPlan(taskData);
}

/**
 * Creates a fallback plan when API fails
 * @param {Object} taskData - Original task data
 * @returns {Object} Structured fallback plan
 */
function createFallbackPlan(taskData) {
  const startDate = taskData?.startDate ? new Date(taskData.startDate) : new Date();
  const endDate = taskData?.endDate ? new Date(taskData.endDate) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  const totalDays = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)) || 30;
  const budget = taskData?.budget || 5000;
  
  return {
    title: taskData?.goalTitle || 'Generated Plan',
    summary: `Comprehensive plan for ${taskData?.goalTitle || 'your goal'} with ${Math.ceil(totalDays / 7)} phases over ${totalDays} days.`,
    phases: [
      {
        id: 1,
        title: 'Planning & Research Phase',
        description: 'Initial planning, research, and resource preparation',
        duration: Math.ceil(totalDays * 0.25),
        budget: Math.ceil(budget * 0.2),
        tasks: [
          {
            id: 1,
            title: 'Goal Analysis & Requirements',
            description: 'Analyze objectives and define detailed requirements',
            priority: 'high',
            estimatedTime: Math.ceil(totalDays * 0.1),
            dependencies: []
          },
          {
            id: 2,
            title: 'Research & Information Gathering',
            description: 'Conduct thorough research and gather necessary information',
            priority: 'high',
            estimatedTime: Math.ceil(totalDays * 0.15),
            dependencies: [1]
          }
        ]
      },
      {
        id: 2,
        title: 'Implementation Phase',
        description: 'Main execution and implementation of the plan',
        duration: Math.ceil(totalDays * 0.5),
        budget: Math.ceil(budget * 0.6),
        tasks: [
          {
            id: 3,
            title: 'Core Implementation',
            description: 'Execute the main components of the plan',
            priority: 'high',
            estimatedTime: Math.ceil(totalDays * 0.3),
            dependencies: [2]
          },
          {
            id: 4,
            title: 'Quality Assurance & Testing',
            description: 'Review progress and ensure quality standards',
            priority: 'medium',
            estimatedTime: Math.ceil(totalDays * 0.2),
            dependencies: [3]
          }
        ]
      },
      {
        id: 3,
        title: 'Completion & Review Phase',
        description: 'Final review, optimization, and project completion',
        duration: Math.ceil(totalDays * 0.25),
        budget: Math.ceil(budget * 0.2),
        tasks: [
          {
            id: 5,
            title: 'Final Review & Optimization',
            description: 'Comprehensive review and final optimizations',
            priority: 'medium',
            estimatedTime: Math.ceil(totalDays * 0.15),
            dependencies: [4]
          },
          {
            id: 6,
            title: 'Delivery & Documentation',
            description: 'Final delivery and comprehensive documentation',
            priority: 'high',
            estimatedTime: Math.ceil(totalDays * 0.1),
            dependencies: [5]
          }
        ]
      }
    ],
    totalBudget: budget,
    totalDuration: totalDays,
    risks: [
      {
        title: 'Timeline Risk',
        impact: 'medium',
        mitigation: 'Build buffer time into schedule and monitor progress regularly'
      },
      {
        title: 'Budget Overrun',
        impact: 'medium',
        mitigation: 'Track expenses closely and have contingency funds available'
      },
      {
        title: 'Resource Availability',
        impact: 'low',
        mitigation: 'Identify backup resources and maintain flexible scheduling'
      }
    ],
    recommendations: [
      'Conduct regular progress reviews and adjust timeline as needed',
      'Maintain clear communication channels with all stakeholders',
      'Document all decisions and changes for future reference',
      'Build in flexibility to accommodate unexpected changes',
      'Set up milestone checkpoints to track progress effectively'
    ]
  };
}

export default {
  generateTaskPlan,
  generateTaskPlanWithProgress,
  optimizePlan,
  generateTaskSuggestions,
  testAPIConnection
};

export { testAPIConnection };